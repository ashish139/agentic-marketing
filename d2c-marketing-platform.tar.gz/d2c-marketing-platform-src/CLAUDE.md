# D2C Marketing Platform

AI-powered D2C marketing platform with multi-agent orchestration, real-time streaming chat, and campaign management across ad platforms.

## Monorepo Layout

```
apps/
  web/          # React 19 + Vite frontend (port 5173)
  gateway/      # Fastify 5 API gateway (port 3001)
  agents/       # Python FastAPI + LangGraph agent service (port 8000)
packages/
  shared-types/ # TypeScript type definitions shared by web & gateway
supabase/       # Supabase config and migrations
```

## Tech Stack

| Layer     | Tech                                                     |
| --------- | -------------------------------------------------------- |
| Frontend  | React 19, Vite 6, Tailwind CSS, Zustand, React Router 7 |
| Gateway   | Fastify 5, Zod, Supabase Admin SDK                      |
| Agents    | Python 3.12, FastAPI, LangGraph 0.2, LangChain          |
| Database  | Supabase (Postgres + Auth)                               |
| LLMs      | Claude Sonnet 4 (reasoning/routing), GPT-4o (creative)  |
| Streaming | SSE (Server-Sent Events) end-to-end                     |
| Build     | pnpm workspaces, Turborepo, Docker Compose               |

## Setup & Running

```bash
# Install JS dependencies
pnpm install

# Copy env and fill in keys (Supabase, Anthropic, OpenAI)
cp .env.example .env

# Run all services (web + gateway + agents)
pnpm dev

# Or via Docker
docker compose up
```

### Individual services

```bash
# Web (port 5173)
cd apps/web && pnpm dev

# Gateway (port 3001)
cd apps/gateway && pnpm dev

# Agents (port 8000)
cd apps/agents && uvicorn app.main:app --reload
```

## Architecture

### Request Flow

```
Browser → Vite proxy (/api/*) → Gateway (Fastify) → Agent Service (FastAPI)
                                      ↓                     ↓
                                  Supabase DB         LLM providers
```

### Auth

- Frontend uses Supabase client-side auth (`useAuth` hook)
- Gateway extracts JWT from `Authorization: Bearer` header, verifies via Supabase admin, attaches `org_id` and `role` from `org_members`
- All resources are scoped to `org_id`

### Agent System

Multi-agent router pattern using LangGraph:

1. **Router agent** classifies user intent and routes to a specialist
2. **Specialist agents**: audience, campaign, journey, design, launch, analytics
3. Each agent has dedicated tools in `app/tools/`
4. Prompts live in `app/llm/prompts/*.txt`

LLM strategy:
- Claude Sonnet 4 (temp 0) for reasoning, analysis, routing
- GPT-4o (temp 0.7) for creative/marketing copy

### SSE Streaming

Gateway proxies the agent SSE stream to the browser. Event types:
`token`, `agent_switch`, `tool_start`, `tool_end`, `approval_request`, `done`

### Approval Workflow

Agents can request human approval (budget changes, campaign launches). Frontend renders `ApprovalCard` components; status persisted in `approvals` table.

## Key Patterns

- **Zustand slices** for frontend state (auth, UI)
- **Vite proxy**: `/api/*` routes to gateway at `localhost:3001`
- **Zod validation** for env config and request schemas in gateway
- **LangGraph StateGraph** for agent orchestration with typed `AgentState`
- **Connector protocol** (`AdPlatformConnector`) for pluggable ad platform integrations (Meta, Google, TikTok, etc.)

## Common Commands

```bash
pnpm dev          # Start all services
pnpm build        # Build all packages
pnpm lint         # Lint all packages
pnpm type-check   # Type-check all packages
```

## Environment Variables

See `.env.example` — requires Supabase credentials, Anthropic API key, OpenAI API key, agent service URL, gateway port, and CORS origin.
