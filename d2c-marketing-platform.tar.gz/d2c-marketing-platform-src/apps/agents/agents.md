# Agent System Architecture

## Overview

The agent service is a Python FastAPI application that uses **LangGraph** to orchestrate a multi-agent system. A **router agent** classifies user intent and dispatches to one of six specialist agents, each equipped with domain-specific tools.

## How It Works

```
User message
    |
    v
[Router Agent] -- classify_intent() --> JSON { "agent": "...", "reasoning": "..." }
    |
    |-- audience  --> Audience Agent
    |-- campaign  --> Campaign Agent
    |-- journey   --> Journey Agent
    |-- design    --> Design Agent
    |-- launch    --> Launch Agent
    |-- analytics --> Analytics Agent
    |-- none      --> Direct response (general greeting)
```

1. The gateway sends a `POST /chat` request with the user message, org context, and session info
2. The **router agent** (`classify_intent`) reads the last 5 messages and classifies intent using Claude
3. `route_to_agent` dispatches to the matched specialist (or returns a direct response)
4. The specialist agent runs with its tools in a loop (max 5 iterations) until it produces a final response
5. The entire flow streams back as **SSE events**

## Agents

| Agent      | LLM             | Purpose                                               |
| ---------- | --------------- | ----------------------------------------------------- |
| Router     | Claude Sonnet 4 (temp 0)   | Intent classification and dispatch            |
| Audience   | Claude Sonnet 4 (temp 0)   | Customer segmentation, audience sizing        |
| Campaign   | Claude Sonnet 4 (temp 0)   | Campaign analysis, optimization, budgets      |
| Journey    | Claude Sonnet 4 (temp 0)   | Customer journey design, lifecycle flows      |
| Design     | GPT-4o (temp 0.7)          | Ad copy, email templates, creative content    |
| Launch     | Claude Sonnet 4 (temp 0)   | Publishing campaigns to ad platforms          |
| Analytics  | Claude Sonnet 4 (temp 0)   | Funnels, cohorts, retention, metrics          |

**LLM strategy:** Claude for reasoning/data tasks (deterministic, temp 0). GPT-4o for creative/marketing copy (higher temp for variety).

## Agent State

All agents share a common `AgentState` (defined in `agents/state.py`):

```python
class AgentState(TypedDict):
    messages: Annotated[Sequence[BaseMessage], add_messages]
    org_id: str
    user_id: str
    session_id: str
    current_agent: AgentName      # Which agent is running
    next_agent: Optional[AgentName]
    brand_context: dict           # Org's brand voice, guidelines
    customer_schema: dict         # Org's customer data structure
    pending_approval: Optional[ApprovalRequest]
    approval_status: Optional[str]
    tool_outputs: list[dict]
    error: Optional[str]
```

`brand_context` and `customer_schema` are fetched by the gateway from Supabase and injected into the agent state so agents can personalize responses.

## Tools

Each agent has a dedicated toolset. Tools are LangChain `@tool`-decorated functions that interact with Supabase.

| File                | Agent     | Tools                                                        |
| ------------------- | --------- | ------------------------------------------------------------ |
| `audience_tools.py` | Audience  | `query_customer_schema`, `estimate_audience_size`, `create_audience_draft`, `build_lookalike_audience` |
| `campaign_tools.py` | Campaign  | Campaign CRUD, performance queries                           |
| `journey_tools.py`  | Journey   | Journey node/edge management                                 |
| `design_tools.py`   | Design    | Creative generation                                          |
| `launch_tools.py`   | Launch    | Campaign deployment via connectors                           |
| `analytics_tools.py`| Analytics | Metric retrieval, aggregation                                |
| `common_tools.py`   | Shared    | Utility functions used across agents                         |

### Tool execution pattern

Each agent follows the same loop:

1. Bind tools to LLM via `llm.bind_tools(TOOLS)`
2. Invoke LLM with system prompt + brand context + conversation messages
3. If LLM returns `tool_calls`, execute each tool (auto-injecting `org_id`)
4. Append `ToolMessage` results and re-invoke
5. Repeat up to 5 iterations until the LLM responds without tool calls

## Approval Workflow

Tools can return `{"requires_approval": True}` to trigger human review:

1. Tool returns result with `requires_approval: True`
2. Agent halts and sets `pending_approval` on the state with an `ApprovalRequest`
3. SSE stream emits an `approval_request` event to the frontend
4. Frontend renders an ApprovalCard for the user to approve/reject

Example: `create_audience_draft` creates a draft audience and requires approval before activation.

## Prompts

System prompts live in `app/llm/prompts/` as plain text files:

```
prompts/
  router.txt      # Intent classification instructions
  audience.txt    # Audience agent persona and instructions
  campaign.txt    # Campaign agent persona
  journey.txt     # Journey agent persona
  design.txt      # Design agent persona
  launch.txt      # Launch agent persona
  analytics.txt   # Analytics agent persona
```

The router prompt returns structured JSON: `{"agent": "<name>", "reasoning": "..."}`.
Specialist prompts define the agent's role, capabilities, and response style.

## SSE Event Stream

The `/chat` endpoint returns an SSE stream with these event types:

| Event              | Payload                          | When                                |
| ------------------ | -------------------------------- | ----------------------------------- |
| `token`            | `{ content: string }`            | Each LLM output token               |
| `agent_switch`     | `{ agent: string }`              | Router dispatches to a specialist    |
| `tool_start`       | `{ tool: string }`               | Agent begins a tool call             |
| `tool_end`         | `{ tool: string, output: string }`| Tool execution completes            |
| `approval_request` | `{ approval: ApprovalRequest }`  | Agent needs human approval           |
| `done`             | `{}`                             | Stream complete                      |
| `error`            | `{ message: string }`            | Something went wrong                 |

## Connectors

Ad platform integrations follow the `AdPlatformConnector` protocol (defined in `connectors/base.py`):

```python
class AdPlatformConnector(Protocol):
    async def test_connection(self) -> bool
    async def create_campaign(self, config: CampaignConfig) -> dict
    async def update_campaign(self, platform_campaign_id, updates) -> dict
    async def pause_campaign(self, platform_campaign_id) -> bool
    async def resume_campaign(self, platform_campaign_id) -> bool
    async def get_campaign_metrics(self, platform_campaign_id, start_date, end_date) -> list
    async def upload_audience(self, audience_name, customer_emails) -> dict
    async def create_ad(self, platform_campaign_id, creative) -> dict
```

Currently implemented: **Google Ads** and **Facebook Ads** (each with `mock` and `live` variants). Use `connectors/factory.py` to get a connector instance:

```python
connector = get_connector("google_ads", config={...}, use_mock=True)
```

## Adding a New Agent

1. **Create the prompt** in `app/llm/prompts/<name>.txt`
2. **Create tools** in `app/tools/<name>_tools.py` (export as `<NAME>_TOOLS` list)
3. **Create the agent** in `app/agents/<name>_agent.py` following the same pattern as `audience_agent.py`
4. **Register in router** — add to `AgentName` literal in `state.py`, update `router_agent.py`:
   - Import the agent's run function in `build_router_graph()`
   - Add node: `graph.add_node("<name>", run_<name>_agent)`
   - Add to the conditional edges map and the terminal edge loop
5. **Update the router prompt** in `prompts/router.txt` to include the new agent in the available agents list

## Adding a New Connector

1. Create `app/connectors/<platform>/` with `__init__.py`, `interface.py`, `mock.py`, and `live.py`
2. Implement the `AdPlatformConnector` protocol in both mock and live classes
3. Register in `connectors/factory.py`

## Running Locally

```bash
# From apps/agents/
uvicorn app.main:app --reload

# Or from project root via Docker
docker compose up agents
```

Server runs on port 8000. Health check: `GET /health`.
