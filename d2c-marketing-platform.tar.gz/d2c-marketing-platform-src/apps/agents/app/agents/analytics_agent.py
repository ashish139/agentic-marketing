from pathlib import Path

from langchain_core.messages import AIMessage, SystemMessage, ToolMessage

from app.agents.state import AgentState
from app.llm.providers import get_reasoning_llm
from app.tools.analytics_tools import ANALYTICS_TOOLS

SYSTEM_PROMPT = Path(__file__).resolve().parent.parent.joinpath(
    "llm", "prompts", "analytics.txt"
).read_text()


async def run_analytics_agent(state: AgentState) -> dict:
    """Run the Analytics Agent with tools."""
    llm = get_reasoning_llm()
    llm_with_tools = llm.bind_tools(ANALYTICS_TOOLS)

    messages = [SystemMessage(content=SYSTEM_PROMPT)]

    if state.get("customer_schema"):
        messages.append(
            SystemMessage(
                content=f"Customer Schema: {state['customer_schema']}"
            )
        )

    messages.extend(state["messages"])

    tool_map = {t.name: t for t in ANALYTICS_TOOLS}
    max_iterations = 5

    for _ in range(max_iterations):
        response = await llm_with_tools.ainvoke(messages)
        messages.append(response)

        if not response.tool_calls:
            break

        for tc in response.tool_calls:
            tool = tool_map.get(tc["name"])
            if tool:
                args = dict(tc["args"])
                if "org_id" not in args and "org_id" in state:
                    args["org_id"] = state["org_id"]

                result = await tool.ainvoke(args)
                messages.append(
                    ToolMessage(content=str(result), tool_call_id=tc["id"])
                )

    final = messages[-1]
    if isinstance(final, AIMessage):
        return {"messages": [final], "current_agent": "analytics"}
    return {
        "messages": [AIMessage(content=str(final.content))],
        "current_agent": "analytics",
    }
