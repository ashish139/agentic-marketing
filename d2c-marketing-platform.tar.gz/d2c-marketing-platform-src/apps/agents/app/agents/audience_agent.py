from pathlib import Path

from langchain_core.messages import AIMessage, SystemMessage, ToolMessage

from app.agents.state import AgentState, ApprovalRequest
from app.llm.providers import get_reasoning_llm
from app.tools.audience_tools import AUDIENCE_TOOLS

SYSTEM_PROMPT = Path(__file__).resolve().parent.parent.joinpath(
    "llm", "prompts", "audience.txt"
).read_text()


async def run_audience_agent(state: AgentState) -> dict:
    """Run the Audience Agent with tools."""
    llm = get_reasoning_llm()
    llm_with_tools = llm.bind_tools(AUDIENCE_TOOLS)

    messages = [SystemMessage(content=SYSTEM_PROMPT)]

    # Inject brand context and customer schema
    if state.get("brand_context"):
        messages.append(
            SystemMessage(content=f"Brand Context: {state['brand_context']}")
        )
    if state.get("customer_schema"):
        messages.append(
            SystemMessage(content=f"Customer Schema: {state['customer_schema']}")
        )

    messages.extend(state["messages"])

    tool_map = {t.name: t for t in AUDIENCE_TOOLS}
    max_iterations = 5

    for _ in range(max_iterations):
        response = await llm_with_tools.ainvoke(messages)
        messages.append(response)

        if not response.tool_calls:
            break

        for tc in response.tool_calls:
            tool = tool_map.get(tc["name"])
            if tool:
                args = dict(tc["args"])
                # Inject org_id if the tool expects it and it is missing
                if "org_id" not in args and "org_id" in state:
                    args["org_id"] = state["org_id"]

                result = await tool.ainvoke(args)
                messages.append(
                    ToolMessage(content=str(result), tool_call_id=tc["id"])
                )

                # Check if the action needs human approval
                if isinstance(result, dict) and result.get("requires_approval"):
                    return {
                        "messages": [
                            response,
                            ToolMessage(content=str(result), tool_call_id=tc["id"]),
                        ],
                        "pending_approval": ApprovalRequest(
                            action_type="create_audience",
                            title=f"Create Audience: {args.get('name', 'Unnamed')}",
                            description=result.get("message", ""),
                            payload=result.get("audience", {}),
                            diff=None,
                        ),
                        "current_agent": "audience",
                    }

    final = messages[-1]
    if isinstance(final, AIMessage):
        return {"messages": [final], "current_agent": "audience"}
    return {
        "messages": [AIMessage(content=str(final.content))],
        "current_agent": "audience",
    }
