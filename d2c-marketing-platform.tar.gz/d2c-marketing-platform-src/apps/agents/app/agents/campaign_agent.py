from pathlib import Path

from langchain_core.messages import AIMessage, SystemMessage, ToolMessage

from app.agents.state import AgentState
from app.llm.providers import get_reasoning_llm
from app.tools.campaign_tools import CAMPAIGN_TOOLS

SYSTEM_PROMPT = Path(__file__).resolve().parent.parent.joinpath(
    "llm", "prompts", "campaign.txt"
).read_text()


async def run_campaign_agent(state: AgentState) -> dict:
    """Run the Campaign Agent with tools."""
    llm = get_reasoning_llm()
    llm_with_tools = llm.bind_tools(CAMPAIGN_TOOLS)

    messages = [SystemMessage(content=SYSTEM_PROMPT)]

    if state.get("brand_context"):
        messages.append(
            SystemMessage(content=f"Brand Context: {state['brand_context']}")
        )

    messages.extend(state["messages"])

    tool_map = {t.name: t for t in CAMPAIGN_TOOLS}
    max_iterations = 5

    for _ in range(max_iterations):
        response = await llm_with_tools.ainvoke(messages)
        messages.append(response)

        if not response.tool_calls:
            break

        for tc in response.tool_calls:
            tool = tool_map.get(tc["name"])
            if tool:
                args = dict(tc["args"])
                if "org_id" not in args and "org_id" in state:
                    args["org_id"] = state["org_id"]

                result = await tool.ainvoke(args)
                messages.append(
                    ToolMessage(content=str(result), tool_call_id=tc["id"])
                )

    final = messages[-1]
    if isinstance(final, AIMessage):
        return {"messages": [final], "current_agent": "campaign"}
    return {
        "messages": [AIMessage(content=str(final.content))],
        "current_agent": "campaign",
    }
