from pathlib import Path

from langchain_core.messages import AIMessage, SystemMessage, ToolMessage

from app.agents.state import AgentState
from app.llm.providers import get_creative_llm
from app.tools.design_tools import DESIGN_TOOLS

SYSTEM_PROMPT = Path(__file__).resolve().parent.parent.joinpath(
    "llm", "prompts", "design.txt"
).read_text()


async def run_design_agent(state: AgentState) -> dict:
    """Run the Design Agent with tools. Uses GPT-4o for creative output."""
    llm = get_creative_llm()
    llm_with_tools = llm.bind_tools(DESIGN_TOOLS)

    messages = [SystemMessage(content=SYSTEM_PROMPT)]

    if state.get("brand_context"):
        messages.append(
            SystemMessage(
                content=f"Brand Guidelines: {state['brand_context']}"
            )
        )

    messages.extend(state["messages"])

    tool_map = {t.name: t for t in DESIGN_TOOLS}
    max_iterations = 5

    for _ in range(max_iterations):
        response = await llm_with_tools.ainvoke(messages)
        messages.append(response)

        if not response.tool_calls:
            break

        for tc in response.tool_calls:
            tool = tool_map.get(tc["name"])
            if tool:
                args = dict(tc["args"])
                result = await tool.ainvoke(args)
                messages.append(
                    ToolMessage(content=str(result), tool_call_id=tc["id"])
                )

    final = messages[-1]
    if isinstance(final, AIMessage):
        return {"messages": [final], "current_agent": "design"}
    return {
        "messages": [AIMessage(content=str(final.content))],
        "current_agent": "design",
    }
