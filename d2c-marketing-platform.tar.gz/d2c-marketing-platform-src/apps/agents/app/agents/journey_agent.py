from pathlib import Path

from langchain_core.messages import AIMessage, SystemMessage, ToolMessage

from app.agents.state import AgentState, ApprovalRequest
from app.llm.providers import get_reasoning_llm
from app.tools.journey_tools import JOURNEY_TOOLS

SYSTEM_PROMPT = Path(__file__).resolve().parent.parent.joinpath(
    "llm", "prompts", "journey.txt"
).read_text()


async def run_journey_agent(state: AgentState) -> dict:
    """Run the Journey Agent with tools."""
    llm = get_reasoning_llm()
    llm_with_tools = llm.bind_tools(JOURNEY_TOOLS)

    messages = [SystemMessage(content=SYSTEM_PROMPT)]

    if state.get("brand_context"):
        messages.append(
            SystemMessage(content=f"Brand Context: {state['brand_context']}")
        )

    messages.extend(state["messages"])

    tool_map = {t.name: t for t in JOURNEY_TOOLS}
    max_iterations = 8  # Journeys may need more steps

    for _ in range(max_iterations):
        response = await llm_with_tools.ainvoke(messages)
        messages.append(response)

        if not response.tool_calls:
            break

        for tc in response.tool_calls:
            tool = tool_map.get(tc["name"])
            if tool:
                args = dict(tc["args"])
                if "org_id" not in args and "org_id" in state:
                    args["org_id"] = state["org_id"]

                result = await tool.ainvoke(args)
                messages.append(
                    ToolMessage(content=str(result), tool_call_id=tc["id"])
                )

                # Journey creation requires approval
                if isinstance(result, dict) and result.get("requires_approval"):
                    journey = result.get("journey", {})
                    return {
                        "messages": [
                            response,
                            ToolMessage(
                                content=str(result), tool_call_id=tc["id"]
                            ),
                        ],
                        "pending_approval": ApprovalRequest(
                            action_type="create_journey",
                            title=f"Create Journey: {journey.get('name', 'Unnamed')}",
                            description=result.get("message", ""),
                            payload=journey,
                            diff=None,
                        ),
                        "current_agent": "journey",
                    }

    final = messages[-1]
    if isinstance(final, AIMessage):
        return {"messages": [final], "current_agent": "journey"}
    return {
        "messages": [AIMessage(content=str(final.content))],
        "current_agent": "journey",
    }
