import json
from pathlib import Path

from langchain_core.messages import AIMessage
from langgraph.graph import END, StateGraph

from app.agents.state import AgentState
from app.llm.providers import get_router_llm

ROUTER_PROMPT = Path(__file__).resolve().parent.parent.joinpath(
    "llm", "prompts", "router.txt"
).read_text()


async def classify_intent(state: AgentState) -> dict:
    """Classify the user's intent and decide which agent handles it."""
    llm = get_router_llm()

    recent_messages = list(state["messages"][-5:])
    messages = [{"role": "system", "content": ROUTER_PROMPT}]
    for msg in recent_messages:
        role = "assistant" if msg.type == "ai" else msg.type
        messages.append({"role": role, "content": msg.content})

    response = await llm.ainvoke(messages)

    try:
        parsed = json.loads(response.content)
        next_agent = parsed.get("agent", "none")
    except (json.JSONDecodeError, AttributeError):
        next_agent = "none"

    if next_agent == "none" or next_agent not in {
        "audience",
        "campaign",
        "journey",
        "design",
        "launch",
        "analytics",
    }:
        # General conversation — return the LLM response directly
        return {
            "next_agent": None,
            "messages": [
                AIMessage(
                    content="Hello! I'm your D2C marketing assistant. "
                    "I can help you with audience segmentation, campaign analysis, "
                    "customer journeys, ad copy design, campaign launches, and analytics. "
                    "What would you like to work on?"
                )
            ],
        }

    return {"next_agent": next_agent, "current_agent": next_agent}


def route_to_agent(state: AgentState) -> str:
    """Determine which agent node to route to based on classification."""
    next_agent = state.get("next_agent")
    if next_agent and next_agent in {
        "audience",
        "campaign",
        "journey",
        "design",
        "launch",
        "analytics",
    }:
        return next_agent
    return "direct_response"


async def handle_direct(state: AgentState) -> dict:
    """Handle general conversation that doesn't need a specialist agent."""
    return {}


def build_router_graph():
    """Build the top-level router graph that dispatches to specialized agents."""
    from app.agents.analytics_agent import run_analytics_agent
    from app.agents.audience_agent import run_audience_agent
    from app.agents.campaign_agent import run_campaign_agent
    from app.agents.design_agent import run_design_agent
    from app.agents.journey_agent import run_journey_agent
    from app.agents.launch_agent import run_launch_agent

    graph = StateGraph(AgentState)

    # Add nodes
    graph.add_node("classify", classify_intent)
    graph.add_node("audience", run_audience_agent)
    graph.add_node("campaign", run_campaign_agent)
    graph.add_node("journey", run_journey_agent)
    graph.add_node("design", run_design_agent)
    graph.add_node("launch", run_launch_agent)
    graph.add_node("analytics", run_analytics_agent)
    graph.add_node("direct_response", handle_direct)

    # Entry point
    graph.set_entry_point("classify")

    # Conditional routing from classify
    graph.add_conditional_edges(
        "classify",
        route_to_agent,
        {
            "audience": "audience",
            "campaign": "campaign",
            "journey": "journey",
            "design": "design",
            "launch": "launch",
            "analytics": "analytics",
            "direct_response": "direct_response",
        },
    )

    # All agents terminate after running
    for node in [
        "audience",
        "campaign",
        "journey",
        "design",
        "launch",
        "analytics",
        "direct_response",
    ]:
        graph.add_edge(node, END)

    return graph.compile()
