from __future__ import annotations

from typing import Annotated, Literal, Optional, Sequence, TypedDict

from langchain_core.messages import BaseMessage
from langgraph.graph.message import add_messages

AgentName = Literal[
    "router",
    "audience",
    "campaign",
    "journey",
    "design",
    "launch",
    "analytics",
]


class ApprovalRequest(TypedDict):
    action_type: str
    title: str
    description: str
    payload: dict
    diff: Optional[dict]


class AgentState(TypedDict):
    messages: Annotated[Sequence[BaseMessage], add_messages]
    org_id: str
    user_id: str
    session_id: str
    current_agent: AgentName
    next_agent: Optional[AgentName]
    brand_context: dict
    customer_schema: dict
    pending_approval: Optional[ApprovalRequest]
    approval_status: Optional[str]
    tool_outputs: list[dict]
    error: Optional[str]
