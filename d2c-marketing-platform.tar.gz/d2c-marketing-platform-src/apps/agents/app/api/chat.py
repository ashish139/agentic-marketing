import json

from fastapi import APIRouter
from langchain_core.messages import HumanMessage
from pydantic import BaseModel
from sse_starlette.sse import EventSourceResponse

from app.agents.state import AgentState

router = APIRouter()


class ChatRequest(BaseModel):
    org_id: str
    user_id: str
    session_id: str
    content: str
    brand_context: dict = {}
    customer_schema: dict = {}


@router.post("/chat")
async def chat(req: ChatRequest):
    from app.agents.router_agent import build_router_graph

    graph = build_router_graph()

    initial_state: AgentState = {
        "messages": [HumanMessage(content=req.content)],
        "org_id": req.org_id,
        "user_id": req.user_id,
        "session_id": req.session_id,
        "current_agent": "router",
        "next_agent": None,
        "brand_context": req.brand_context,
        "customer_schema": req.customer_schema,
        "pending_approval": None,
        "approval_status": None,
        "tool_outputs": [],
        "error": None,
    }

    async def event_stream():
        try:
            final_state = None
            async for event in graph.astream_events(initial_state, version="v2"):
                kind = event["event"]

                if kind == "on_chat_model_stream":
                    chunk = event["data"]["chunk"]
                    token = chunk.content if hasattr(chunk, "content") else ""
                    if token:
                        yield {
                            "event": "message",
                            "data": json.dumps(
                                {"type": "token", "content": token}
                            ),
                        }

                elif kind == "on_chain_end" and event.get("name") == "LangGraph":
                    final_state = event["data"].get("output", {})

                elif kind == "on_chain_start" and "agent" in event.get("name", ""):
                    agent_name = (
                        event["name"]
                        .replace("_agent", "")
                        .replace("_reasoning", "")
                    )
                    yield {
                        "event": "message",
                        "data": json.dumps(
                            {"type": "agent_switch", "agent": agent_name}
                        ),
                    }

                elif kind == "on_tool_start":
                    yield {
                        "event": "message",
                        "data": json.dumps(
                            {"type": "tool_start", "tool": event["name"]}
                        ),
                    }

                elif kind == "on_tool_end":
                    output = str(event["data"].get("output", ""))[:500]
                    yield {
                        "event": "message",
                        "data": json.dumps(
                            {
                                "type": "tool_end",
                                "tool": event["name"],
                                "output": output,
                            }
                        ),
                    }

            # Check final state for pending approval requests
            if final_state and final_state.get("pending_approval"):
                yield {
                    "event": "message",
                    "data": json.dumps(
                        {
                            "type": "approval_request",
                            "approval": final_state["pending_approval"],
                        }
                    ),
                }

            yield {"event": "message", "data": json.dumps({"type": "done"})}

        except Exception as e:
            yield {
                "event": "message",
                "data": json.dumps({"type": "error", "message": str(e)}),
            }

    return EventSourceResponse(event_stream())
