from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    supabase_url: str = "http://localhost:54321"
    supabase_service_role_key: str = ""
    anthropic_api_key: str = ""
    openai_api_key: str = ""
    cors_origin: str = "http://localhost:5173"

    class Config:
        env_file = "../../.env"


settings = Settings()
