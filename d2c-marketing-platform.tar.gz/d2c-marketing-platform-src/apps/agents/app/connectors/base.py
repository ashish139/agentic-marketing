from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable


@dataclass
class CampaignConfig:
    name: str
    campaign_type: str
    audience_emails: list[str]
    creatives: list[dict]
    daily_budget: float
    total_budget: float
    start_date: str
    end_date: str | None = None


@dataclass
class CampaignMetricsResponse:
    date: str
    impressions: int
    clicks: int
    conversions: int
    spend: float
    revenue: float


@runtime_checkable
class AdPlatformConnector(Protocol):
    async def test_connection(self) -> bool: ...

    async def create_campaign(self, config: CampaignConfig) -> dict: ...

    async def update_campaign(
        self, platform_campaign_id: str, updates: dict
    ) -> dict: ...

    async def pause_campaign(self, platform_campaign_id: str) -> bool: ...

    async def resume_campaign(self, platform_campaign_id: str) -> bool: ...

    async def get_campaign_metrics(
        self, platform_campaign_id: str, start_date: str, end_date: str
    ) -> list[CampaignMetricsResponse]: ...

    async def upload_audience(
        self, audience_name: str, customer_emails: list[str]
    ) -> dict: ...

    async def create_ad(
        self, platform_campaign_id: str, creative: dict
    ) -> dict: ...
