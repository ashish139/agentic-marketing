from enum import Enum


class FacebookAdsCampaignObjective(str, Enum):
    CONVERSIONS = "CONVERSIONS"
    TRAFFIC = "LINK_CLICKS"
    REACH = "REACH"
    BRAND_AWARENESS = "BRAND_AWARENESS"
    CATALOG_SALES = "PRODUCT_CATALOG_SALES"
    APP_INSTALLS = "APP_INSTALLS"


class FacebookAdsPlacement(str, Enum):
    FEED = "feed"
    STORIES = "stories"
    REELS = "reels"
    MARKETPLACE = "marketplace"
    RIGHT_COLUMN = "right_hand_column"
    INSTAGRAM_FEED = "instagram_feed"
    INSTAGRAM_STORIES = "instagram_stories"
    INSTAGRAM_REELS = "instagram_reels"


class FacebookAdsStatus(str, Enum):
    ACTIVE = "ACTIVE"
    PAUSED = "PAUSED"
    DELETED = "DELETED"
    ARCHIVED = "ARCHIVED"
