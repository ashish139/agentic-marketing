import random
import uuid
from datetime import datetime, timedelta

from app.connectors.base import CampaignConfig, CampaignMetricsResponse


class MockFacebookAdsConnector:
    """Mock Facebook Ads connector with realistic D2C social metrics.

    Facebook/Meta ads typically have:
    - Higher CTR than Google (social discovery)
    - Lower CPC ($0.30-$2.00)
    - Higher engagement but sometimes lower intent
    """

    _campaigns: dict[str, dict] = {}
    _audiences: dict[str, dict] = {}
    _ads: dict[str, dict] = {}

    def __init__(self, config: dict = {}):
        self.config = config

    async def test_connection(self) -> bool:
        return True

    async def create_campaign(self, config: CampaignConfig) -> dict:
        campaign_id = f"fb_{uuid.uuid4().hex[:12]}"
        campaign = {
            "platform_campaign_id": campaign_id,
            "name": config.name,
            "objective": config.campaign_type,
            "status": "PAUSED",
            "daily_budget": config.daily_budget,
            "lifetime_budget": config.total_budget,
            "start_time": config.start_date,
            "end_time": config.end_date,
            "created_time": datetime.utcnow().isoformat(),
        }
        self._campaigns[campaign_id] = campaign
        return campaign

    async def update_campaign(
        self, platform_campaign_id: str, updates: dict
    ) -> dict:
        if platform_campaign_id not in self._campaigns:
            self._campaigns[platform_campaign_id] = {
                "platform_campaign_id": platform_campaign_id
            }
        self._campaigns[platform_campaign_id].update(updates)
        return self._campaigns[platform_campaign_id]

    async def pause_campaign(self, platform_campaign_id: str) -> bool:
        if platform_campaign_id in self._campaigns:
            self._campaigns[platform_campaign_id]["status"] = "PAUSED"
        return True

    async def resume_campaign(self, platform_campaign_id: str) -> bool:
        if platform_campaign_id in self._campaigns:
            self._campaigns[platform_campaign_id]["status"] = "ACTIVE"
        return True

    async def get_campaign_metrics(
        self, platform_campaign_id: str, start_date: str, end_date: str
    ) -> list[CampaignMetricsResponse]:
        """Generate realistic Facebook Ads metrics for D2C.

        Ranges:
        - CTR: 1.5-7% (higher social engagement)
        - CPC: $0.30-$2.00 (lower than Google)
        - Conversion rate: 1.5-5%
        - ROAS: 2-6x
        """
        start = datetime.strptime(start_date, "%Y-%m-%d")
        end = datetime.strptime(end_date, "%Y-%m-%d")
        days = (end - start).days + 1

        metrics = []
        for i in range(days):
            date = start + timedelta(days=i)
            impressions = random.randint(1000, 8000)
            ctr = random.uniform(0.015, 0.07)
            clicks = int(impressions * ctr)
            cpc = random.uniform(0.30, 2.00)
            spend = round(clicks * cpc, 2)
            conv_rate = random.uniform(0.015, 0.05)
            conversions = max(1, int(clicks * conv_rate))
            roas = random.uniform(2.0, 6.0)
            revenue = round(spend * roas, 2)

            metrics.append(
                CampaignMetricsResponse(
                    date=date.strftime("%Y-%m-%d"),
                    impressions=impressions,
                    clicks=clicks,
                    conversions=conversions,
                    spend=spend,
                    revenue=revenue,
                )
            )

        return metrics

    async def upload_audience(
        self, audience_name: str, customer_emails: list[str]
    ) -> dict:
        audience_id = f"fb_aud_{uuid.uuid4().hex[:8]}"
        audience = {
            "id": audience_id,
            "name": audience_name,
            "approximate_count": len(customer_emails),
            "operation_status": {
                "status": "NORMAL",
            },
            "delivery_status": {
                "status": "READY",
            },
            # Facebook typically has higher match rates due to email/phone matching
            "match_rate_estimate": round(random.uniform(0.50, 0.85), 2),
        }
        self._audiences[audience_id] = audience
        return audience

    async def create_ad(
        self, platform_campaign_id: str, creative: dict
    ) -> dict:
        ad_id = f"fb_ad_{uuid.uuid4().hex[:8]}"
        ad = {
            "id": ad_id,
            "campaign_id": platform_campaign_id,
            "creative": {
                "title": creative.get("headline", ""),
                "body": creative.get("body", ""),
                "image_url": creative.get("image_url", ""),
                "link_url": creative.get("link_url", ""),
                "call_to_action_type": creative.get("cta", "SHOP_NOW"),
            },
            "status": "PAUSED",
            "review_status": "APPROVED",
        }
        self._ads[ad_id] = ad
        return ad
