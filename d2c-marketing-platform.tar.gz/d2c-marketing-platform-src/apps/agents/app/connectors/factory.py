from app.connectors.base import AdPlatformConnector


def get_connector(
    platform: str,
    config: dict = {},
    use_mock: bool = True,
) -> AdPlatformConnector:
    """Factory function to get the appropriate ad platform connector.

    Args:
        platform: One of 'google_ads' or 'facebook_ads'
        config: Platform-specific configuration (API keys, account IDs, etc.)
        use_mock: If True, return a mock connector for development/testing

    Returns:
        An AdPlatformConnector instance.

    Raises:
        ValueError: If the platform is not supported.
    """
    if platform == "google_ads":
        if use_mock:
            from app.connectors.google_ads.mock import MockGoogleAdsConnector

            return MockGoogleAdsConnector(config)
        from app.connectors.google_ads.live import LiveGoogleAdsConnector

        return LiveGoogleAdsConnector(config)

    elif platform == "facebook_ads":
        if use_mock:
            from app.connectors.facebook_ads.mock import MockFacebookAdsConnector

            return MockFacebookAdsConnector(config)
        from app.connectors.facebook_ads.live import LiveFacebookAdsConnector

        return LiveFacebookAdsConnector(config)

    else:
        raise ValueError(
            f"Unknown platform: {platform}. "
            f"Supported: 'google_ads', 'facebook_ads'"
        )
