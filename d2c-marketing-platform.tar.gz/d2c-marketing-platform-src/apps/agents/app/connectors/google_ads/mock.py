import random
import uuid
from datetime import datetime, timedelta

from app.connectors.base import CampaignConfig, CampaignMetricsResponse


class MockGoogleAdsConnector:
    """Mock Google Ads connector with realistic D2C metrics."""

    # Class-level state to persist across calls within the same process
    _campaigns: dict[str, dict] = {}
    _audiences: dict[str, dict] = {}
    _ads: dict[str, dict] = {}

    def __init__(self, config: dict = {}):
        self.config = config

    async def test_connection(self) -> bool:
        return True

    async def create_campaign(self, config: CampaignConfig) -> dict:
        campaign_id = f"gads_{uuid.uuid4().hex[:12]}"
        campaign = {
            "platform_campaign_id": campaign_id,
            "name": config.name,
            "campaign_type": config.campaign_type,
            "status": "PAUSED",
            "daily_budget": config.daily_budget,
            "total_budget": config.total_budget,
            "start_date": config.start_date,
            "end_date": config.end_date,
            "created_at": datetime.utcnow().isoformat(),
        }
        self._campaigns[campaign_id] = campaign
        return campaign

    async def update_campaign(
        self, platform_campaign_id: str, updates: dict
    ) -> dict:
        if platform_campaign_id not in self._campaigns:
            self._campaigns[platform_campaign_id] = {
                "platform_campaign_id": platform_campaign_id
            }
        self._campaigns[platform_campaign_id].update(updates)
        return self._campaigns[platform_campaign_id]

    async def pause_campaign(self, platform_campaign_id: str) -> bool:
        if platform_campaign_id in self._campaigns:
            self._campaigns[platform_campaign_id]["status"] = "PAUSED"
        return True

    async def resume_campaign(self, platform_campaign_id: str) -> bool:
        if platform_campaign_id in self._campaigns:
            self._campaigns[platform_campaign_id]["status"] = "ENABLED"
        return True

    async def get_campaign_metrics(
        self, platform_campaign_id: str, start_date: str, end_date: str
    ) -> list[CampaignMetricsResponse]:
        """Generate realistic Google Ads metrics for D2C.

        Ranges:
        - CTR: 1-5%
        - CPC: $0.50-$3.00
        - Conversion rate: 2-6%
        - ROAS: 2-8x
        """
        start = datetime.strptime(start_date, "%Y-%m-%d")
        end = datetime.strptime(end_date, "%Y-%m-%d")
        days = (end - start).days + 1

        metrics = []
        for i in range(days):
            date = start + timedelta(days=i)
            impressions = random.randint(800, 5000)
            ctr = random.uniform(0.01, 0.05)
            clicks = int(impressions * ctr)
            cpc = random.uniform(0.50, 3.00)
            spend = round(clicks * cpc, 2)
            conv_rate = random.uniform(0.02, 0.06)
            conversions = max(1, int(clicks * conv_rate))
            roas = random.uniform(2.0, 8.0)
            revenue = round(spend * roas, 2)

            metrics.append(
                CampaignMetricsResponse(
                    date=date.strftime("%Y-%m-%d"),
                    impressions=impressions,
                    clicks=clicks,
                    conversions=conversions,
                    spend=spend,
                    revenue=revenue,
                )
            )

        return metrics

    async def upload_audience(
        self, audience_name: str, customer_emails: list[str]
    ) -> dict:
        audience_id = f"gads_aud_{uuid.uuid4().hex[:8]}"
        audience = {
            "audience_id": audience_id,
            "name": audience_name,
            "size": len(customer_emails),
            "status": "PROCESSING",
            "match_rate_estimate": round(random.uniform(0.40, 0.75), 2),
        }
        self._audiences[audience_id] = audience
        return audience

    async def create_ad(
        self, platform_campaign_id: str, creative: dict
    ) -> dict:
        ad_id = f"gads_ad_{uuid.uuid4().hex[:8]}"
        ad = {
            "ad_id": ad_id,
            "campaign_id": platform_campaign_id,
            "type": creative.get("type", "responsive_search"),
            "headlines": creative.get("headlines", []),
            "descriptions": creative.get("descriptions", []),
            "status": "PAUSED",
            "approval_status": "APPROVED",
        }
        self._ads[ad_id] = ad
        return ad
