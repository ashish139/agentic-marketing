from langchain_anthropic import ChatAnthropic
from langchain_openai import ChatOpenAI

from app.config import settings


def get_reasoning_llm() -> ChatAnthropic:
    """Claude for analysis, classification, and data interpretation."""
    return ChatAnthropic(
        model="claude-sonnet-4-20250514",
        api_key=settings.anthropic_api_key,
        temperature=0,
        max_tokens=4096,
    )


def get_creative_llm() -> ChatOpenAI:
    """GPT-4o for marketing copy, ad text, and email content."""
    return ChatOpenAI(
        model="gpt-4o",
        api_key=settings.openai_api_key,
        temperature=0.7,
        max_tokens=4096,
    )


def get_router_llm() -> ChatAnthropic:
    """Fast Claude for intent classification."""
    return ChatAnthropic(
        model="claude-sonnet-4-20250514",
        api_key=settings.anthropic_api_key,
        temperature=0,
        max_tokens=1024,
    )
