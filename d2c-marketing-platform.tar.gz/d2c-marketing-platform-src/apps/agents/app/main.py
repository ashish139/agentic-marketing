from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: initialize Supabase client
    from app.db.supabase_client import get_supabase

    get_supabase()
    yield
    # Shutdown: nothing to clean up


def create_app() -> FastAPI:
    application = FastAPI(
        title="D2C Marketing AI Agents",
        version="0.1.0",
        description="LangGraph-powered AI agents for D2C marketing automation",
        lifespan=lifespan,
    )

    application.add_middleware(
        CORSMiddleware,
        allow_origins=[settings.cors_origin],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    from app.api.router import api_router

    application.include_router(api_router, prefix="/api")

    return application


app = create_app()
