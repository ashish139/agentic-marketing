from datetime import datetime
from typing import Literal, Optional

from pydantic import BaseModel


class ApprovalCreate(BaseModel):
    """Request to create an approval record."""

    org_id: str
    session_id: str
    action_type: str
    title: str
    description: str
    payload: dict
    diff: Optional[dict] = None
    requested_by: str


class ApprovalResponse(BaseModel):
    """An approval record returned from the API."""

    id: str
    org_id: str
    session_id: str
    action_type: str
    title: str
    description: str
    payload: dict
    diff: Optional[dict] = None
    status: Literal["pending", "approved", "rejected"]
    requested_by: str
    reviewed_by: Optional[str] = None
    reviewed_at: Optional[datetime] = None
    created_at: datetime


class ApprovalDecision(BaseModel):
    """A user's decision on a pending approval."""

    status: Literal["approved", "rejected"]
    reviewed_by: str
    comment: str = ""
