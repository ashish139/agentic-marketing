from datetime import datetime
from typing import Literal, Optional

from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    """Incoming chat request from the frontend."""

    org_id: str
    user_id: str
    session_id: str
    content: str
    brand_context: dict = {}
    customer_schema: dict = {}


class StreamToken(BaseModel):
    """A single token in the SSE stream."""

    type: Literal["token"] = "token"
    content: str


class AgentSwitch(BaseModel):
    """Notification that the active agent has changed."""

    type: Literal["agent_switch"] = "agent_switch"
    agent: str


class ToolStart(BaseModel):
    """Notification that a tool invocation has started."""

    type: Literal["tool_start"] = "tool_start"
    tool: str


class ToolEnd(BaseModel):
    """Notification that a tool invocation has completed."""

    type: Literal["tool_end"] = "tool_end"
    tool: str
    output: str


class ApprovalRequestMessage(BaseModel):
    """A request for human approval before proceeding."""

    type: Literal["approval_request"] = "approval_request"
    approval: dict


class ErrorMessage(BaseModel):
    """An error that occurred during processing."""

    type: Literal["error"] = "error"
    message: str


class DoneMessage(BaseModel):
    """Indicates the stream has completed."""

    type: Literal["done"] = "done"


class ChatMessage(BaseModel):
    """A stored chat message in a session."""

    id: Optional[str] = None
    session_id: str
    role: Literal["user", "assistant", "system", "tool"]
    content: str
    agent: Optional[str] = None
    tool_calls: Optional[list[dict]] = None
    metadata: dict = {}
    created_at: Optional[datetime] = None
