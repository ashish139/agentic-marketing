from datetime import datetime, timedelta

from langchain_core.tools import tool

from app.db.supabase_client import get_supabase


@tool
def run_analytics_query(org_id: str, query_type: str, params: dict) -> dict:
    """Run an analytics query against customer or event data.

    Args:
        org_id: Organization ID
        query_type: One of 'events', 'customers', 'metrics'
        params: Query parameters:
            - events: {"event_name": str, "start_date": str, "end_date": str, "limit": int}
            - customers: {"filters": [{"field": str, "op": str, "value": any}], "limit": int}
            - metrics: {"metric": str, "group_by": str, "start_date": str, "end_date": str}

    Returns:
        dict with query results and row count.
    """
    sb = get_supabase()
    limit = params.get("limit", 100)

    if query_type == "events":
        query = (
            sb.table("events")
            .select("*")
            .eq("org_id", org_id)
        )
        if params.get("event_name"):
            query = query.eq("event_name", params["event_name"])
        if params.get("start_date"):
            query = query.gte("created_at", params["start_date"])
        if params.get("end_date"):
            query = query.lte("created_at", params["end_date"])
        query = query.order("created_at", desc=True).limit(limit)
        result = query.execute()

        return {
            "query_type": "events",
            "rows": result.data,
            "count": len(result.data),
        }

    elif query_type == "customers":
        query = (
            sb.table("customers")
            .select("*")
            .eq("org_id", org_id)
        )
        for f in params.get("filters", []):
            field = f["field"]
            op = f["op"]
            value = f["value"]
            if op == "eq":
                query = query.eq(field, value)
            elif op == "gt":
                query = query.gt(field, value)
            elif op == "gte":
                query = query.gte(field, value)
            elif op == "lt":
                query = query.lt(field, value)
            elif op == "lte":
                query = query.lte(field, value)
            elif op == "neq":
                query = query.neq(field, value)

        query = query.limit(limit)
        result = query.execute()

        return {
            "query_type": "customers",
            "rows": result.data,
            "count": len(result.data),
        }

    elif query_type == "metrics":
        # Aggregate campaign metrics
        metric = params.get("metric", "revenue")
        start_date = params.get(
            "start_date",
            (datetime.utcnow() - timedelta(days=30)).strftime("%Y-%m-%d"),
        )
        end_date = params.get(
            "end_date",
            datetime.utcnow().strftime("%Y-%m-%d"),
        )

        result = (
            sb.table("campaign_metrics")
            .select("date, impressions, clicks, conversions, spend, revenue")
            .gte("date", start_date)
            .lte("date", end_date)
            .order("date")
            .execute()
        )

        rows = result.data or []

        # Aggregate by date
        aggregated: dict[str, dict] = {}
        for row in rows:
            d = row["date"]
            if d not in aggregated:
                aggregated[d] = {
                    "date": d,
                    "impressions": 0,
                    "clicks": 0,
                    "conversions": 0,
                    "spend": 0.0,
                    "revenue": 0.0,
                }
            aggregated[d]["impressions"] += row.get("impressions", 0)
            aggregated[d]["clicks"] += row.get("clicks", 0)
            aggregated[d]["conversions"] += row.get("conversions", 0)
            aggregated[d]["spend"] += float(row.get("spend", 0))
            aggregated[d]["revenue"] += float(row.get("revenue", 0))

        daily_data = sorted(aggregated.values(), key=lambda x: x["date"])

        return {
            "query_type": "metrics",
            "date_range": {"start": start_date, "end": end_date},
            "daily_data": daily_data,
            "totals": {
                "impressions": sum(d["impressions"] for d in daily_data),
                "clicks": sum(d["clicks"] for d in daily_data),
                "conversions": sum(d["conversions"] for d in daily_data),
                "spend": round(sum(d["spend"] for d in daily_data), 2),
                "revenue": round(sum(d["revenue"] for d in daily_data), 2),
            },
        }

    else:
        return {"error": f"Unknown query_type: {query_type}. Use 'events', 'customers', or 'metrics'."}


@tool
def build_funnel(
    org_id: str,
    steps: list[str],
    start_date: str = "",
    end_date: str = "",
) -> dict:
    """Build a conversion funnel from event steps.

    Args:
        org_id: Organization ID
        steps: Ordered list of event names forming the funnel.
            Example: ['page_view', 'add_to_cart', 'checkout', 'purchase']
        start_date: Start date (YYYY-MM-DD). Defaults to 30 days ago.
        end_date: End date (YYYY-MM-DD). Defaults to today.

    Returns:
        dict with funnel steps, counts, and conversion rates between steps.
    """
    sb = get_supabase()

    if not start_date:
        start_date = (datetime.utcnow() - timedelta(days=30)).strftime("%Y-%m-%d")
    if not end_date:
        end_date = datetime.utcnow().strftime("%Y-%m-%d")

    funnel_data = []
    previous_count = None

    for i, step_name in enumerate(steps):
        result = (
            sb.table("events")
            .select("customer_id", count="exact")
            .eq("org_id", org_id)
            .eq("event_name", step_name)
            .gte("created_at", start_date)
            .lte("created_at", end_date)
            .execute()
        )
        count = result.count or 0

        step_data = {
            "step": i + 1,
            "event": step_name,
            "unique_users": count,
        }

        if previous_count is not None and previous_count > 0:
            step_data["conversion_rate"] = round(
                (count / previous_count * 100), 2
            )
            step_data["drop_off_rate"] = round(
                ((previous_count - count) / previous_count * 100), 2
            )
            step_data["drop_off_count"] = previous_count - count
        elif i == 0:
            step_data["conversion_rate"] = 100.0
            step_data["drop_off_rate"] = 0.0
            step_data["drop_off_count"] = 0

        funnel_data.append(step_data)
        previous_count = count

    # Overall funnel conversion
    first_count = funnel_data[0]["unique_users"] if funnel_data else 0
    last_count = funnel_data[-1]["unique_users"] if funnel_data else 0
    overall_conversion = (
        round((last_count / first_count * 100), 2) if first_count > 0 else 0
    )

    return {
        "funnel": funnel_data,
        "date_range": {"start": start_date, "end": end_date},
        "overall_conversion_rate": overall_conversion,
        "biggest_drop_off": max(
            funnel_data[1:],
            key=lambda s: s.get("drop_off_rate", 0),
            default=None,
        )
        if len(funnel_data) > 1
        else None,
    }


@tool
def cohort_analysis(
    org_id: str,
    cohort_field: str,
    metric: str,
    periods: int = 12,
) -> dict:
    """Perform cohort analysis. Groups customers by a time-based cohort field
    and tracks a metric over subsequent periods.

    Args:
        org_id: Organization ID
        cohort_field: Field to group cohorts by (e.g. 'created_at' for signup month)
        metric: Metric to track ('purchase_count', 'revenue', 'active')
        periods: Number of monthly periods to track (default 12)

    Returns:
        dict with cohort table data.
    """
    sb = get_supabase()

    # Fetch customers with their cohort date
    customers = (
        sb.table("customers")
        .select(f"id, {cohort_field}")
        .eq("org_id", org_id)
        .order(cohort_field)
        .execute()
    )

    if not customers.data:
        return {"error": "No customer data found."}

    # Group customers into monthly cohorts
    cohorts: dict[str, list[str]] = {}
    for customer in customers.data:
        cohort_date = customer.get(cohort_field, "")
        if not cohort_date:
            continue
        # Extract YYYY-MM for monthly cohorts
        cohort_month = cohort_date[:7]
        if cohort_month not in cohorts:
            cohorts[cohort_month] = []
        cohorts[cohort_month].append(customer["id"])

    # For each cohort, measure the metric across periods
    cohort_table = []
    for cohort_month, customer_ids in sorted(cohorts.items()):
        cohort_start = datetime.strptime(f"{cohort_month}-01", "%Y-%m-%d")
        row = {
            "cohort": cohort_month,
            "size": len(customer_ids),
            "periods": {},
        }

        for period in range(min(periods, 6)):  # Limit DB calls
            period_start = cohort_start + timedelta(days=period * 30)
            period_end = period_start + timedelta(days=30)

            if metric == "active":
                # Count customers with any event in this period
                result = (
                    sb.table("events")
                    .select("customer_id", count="exact")
                    .eq("org_id", org_id)
                    .in_("customer_id", customer_ids[:100])  # Limit for performance
                    .gte("created_at", period_start.strftime("%Y-%m-%d"))
                    .lt("created_at", period_end.strftime("%Y-%m-%d"))
                    .execute()
                )
                count = result.count or 0
            elif metric == "purchase_count":
                result = (
                    sb.table("events")
                    .select("customer_id", count="exact")
                    .eq("org_id", org_id)
                    .eq("event_name", "purchase")
                    .in_("customer_id", customer_ids[:100])
                    .gte("created_at", period_start.strftime("%Y-%m-%d"))
                    .lt("created_at", period_end.strftime("%Y-%m-%d"))
                    .execute()
                )
                count = result.count or 0
            else:
                count = 0

            retention_pct = (
                round((count / len(customer_ids) * 100), 1)
                if len(customer_ids) > 0
                else 0
            )
            row["periods"][f"month_{period}"] = {
                "count": count,
                "retention_pct": retention_pct,
            }

        cohort_table.append(row)

    return {
        "cohort_field": cohort_field,
        "metric": metric,
        "cohorts": cohort_table,
        "total_cohorts": len(cohort_table),
    }


@tool
def calculate_retention(
    org_id: str,
    period: str = "monthly",
    num_periods: int = 6,
) -> dict:
    """Calculate customer retention rates over time periods.

    Args:
        org_id: Organization ID
        period: Period granularity ('weekly' or 'monthly')
        num_periods: Number of periods to calculate (default 6)

    Returns:
        dict with retention rates for each period.
    """
    sb = get_supabase()

    period_days = 7 if period == "weekly" else 30
    now = datetime.utcnow()
    retention_data = []

    for i in range(num_periods):
        period_start = now - timedelta(days=(i + 1) * period_days)
        period_end = now - timedelta(days=i * period_days)
        next_period_end = now - timedelta(days=max(0, (i - 1) * period_days))

        # Customers active in this period
        active_in_period = (
            sb.table("events")
            .select("customer_id", count="exact")
            .eq("org_id", org_id)
            .gte("created_at", period_start.strftime("%Y-%m-%d"))
            .lt("created_at", period_end.strftime("%Y-%m-%d"))
            .execute()
        )
        active_count = active_in_period.count or 0

        # Customers from this period who are active in the next period
        if i > 0:
            retained = (
                sb.table("events")
                .select("customer_id", count="exact")
                .eq("org_id", org_id)
                .gte("created_at", period_end.strftime("%Y-%m-%d"))
                .lt("created_at", next_period_end.strftime("%Y-%m-%d"))
                .execute()
            )
            retained_count = retained.count or 0
        else:
            retained_count = active_count  # Current period

        retention_rate = (
            round((retained_count / active_count * 100), 1)
            if active_count > 0
            else 0
        )

        retention_data.append(
            {
                "period": f"{period}_{num_periods - i}",
                "period_start": period_start.strftime("%Y-%m-%d"),
                "period_end": period_end.strftime("%Y-%m-%d"),
                "active_customers": active_count,
                "retained_customers": retained_count,
                "retention_rate": retention_rate,
            }
        )

    # Reverse so oldest period is first
    retention_data.reverse()

    # Calculate average retention
    rates = [r["retention_rate"] for r in retention_data if r["retention_rate"] > 0]
    avg_retention = round(sum(rates) / len(rates), 1) if rates else 0

    return {
        "period_type": period,
        "num_periods": num_periods,
        "retention_data": retention_data,
        "average_retention_rate": avg_retention,
    }


ANALYTICS_TOOLS = [
    run_analytics_query,
    build_funnel,
    cohort_analysis,
    calculate_retention,
]
