from langchain_core.tools import tool

from app.db.supabase_client import get_supabase


@tool
def query_customer_schema(org_id: str) -> dict:
    """Retrieve the customer data schema for the organization.
    Returns field names, types, and descriptions."""
    sb = get_supabase()
    result = (
        sb.table("organizations")
        .select("customer_schema")
        .eq("id", org_id)
        .single()
        .execute()
    )
    return result.data.get("customer_schema", {})


@tool
def estimate_audience_size(org_id: str, rules: list[dict]) -> dict:
    """Estimate how many customers match the given filter rules.

    Args:
        org_id: Organization ID
        rules: List of filter rules, each with 'field', 'op', and 'value'.
               Example: [{"field": "properties.ltv", "op": "gt", "value": 100}]

    Returns:
        dict with estimated_size, total_customers, and percentage.
    """
    sb = get_supabase()

    # Get total customers
    total_result = (
        sb.table("customers")
        .select("id", count="exact")
        .eq("org_id", org_id)
        .execute()
    )
    total = total_result.count or 0

    # Build filtered query
    query = (
        sb.table("customers")
        .select("id", count="exact")
        .eq("org_id", org_id)
    )

    for rule in rules:
        field = rule["field"]
        op = rule["op"]
        value = rule["value"]

        # Handle JSONB properties fields
        if field.startswith("properties."):
            json_field = field.replace("properties.", "")
            col = f"properties->>'{json_field}'"
            str_value = str(value)
            if op == "gt":
                query = query.gt(col, str_value)
            elif op == "gte":
                query = query.gte(col, str_value)
            elif op == "lt":
                query = query.lt(col, str_value)
            elif op == "lte":
                query = query.lte(col, str_value)
            elif op == "eq":
                query = query.eq(col, str_value)
            elif op == "neq":
                query = query.neq(col, str_value)
        else:
            # Direct column filters
            if op == "gt":
                query = query.gt(field, value)
            elif op == "gte":
                query = query.gte(field, value)
            elif op == "lt":
                query = query.lt(field, value)
            elif op == "lte":
                query = query.lte(field, value)
            elif op == "eq":
                query = query.eq(field, value)
            elif op == "neq":
                query = query.neq(field, value)
            elif op == "in":
                query = query.in_(field, value)

    result = query.execute()
    estimated = result.count or 0
    percentage = round((estimated / total * 100), 2) if total > 0 else 0

    return {
        "estimated_size": estimated,
        "total_customers": total,
        "percentage": percentage,
    }


@tool
def create_audience_draft(
    org_id: str,
    name: str,
    description: str,
    rules: list[dict],
    audience_type: str = "dynamic",
) -> dict:
    """Create a draft audience that will be held for human approval before activation.

    Args:
        org_id: Organization ID
        name: Name of the audience
        description: Description of who is in this audience
        rules: Filter rules
        audience_type: 'static', 'dynamic', or 'lookalike'
    """
    sb = get_supabase()

    # First estimate size
    size_estimate = estimate_audience_size.invoke(
        {"org_id": org_id, "rules": rules}
    )

    result = (
        sb.table("audiences")
        .insert(
            {
                "org_id": org_id,
                "name": name,
                "description": description,
                "rules": rules,
                "audience_type": audience_type,
                "estimated_size": size_estimate["estimated_size"],
                "status": "draft",
            }
        )
        .execute()
    )

    return {
        "audience": result.data[0],
        "estimated_size": size_estimate,
        "requires_approval": True,
        "message": (
            f"Draft audience '{name}' created with "
            f"~{size_estimate['estimated_size']} customers "
            f"({size_estimate['percentage']}% of total). "
            f"Awaiting approval to activate."
        ),
    }


@tool
def build_lookalike_audience(
    org_id: str,
    source_audience_id: str,
    expansion_factor: float = 2.0,
) -> dict:
    """Generate a lookalike audience based on a source audience.

    Args:
        org_id: Organization ID
        source_audience_id: ID of the source audience to base the lookalike on
        expansion_factor: How much to expand (2.0 = 2x the source size)
    """
    sb = get_supabase()

    source = (
        sb.table("audiences")
        .select("*")
        .eq("id", source_audience_id)
        .single()
        .execute()
    )
    source_data = source.data

    estimated_size = int(
        (source_data.get("estimated_size", 0) or 0) * expansion_factor
    )

    result = (
        sb.table("audiences")
        .insert(
            {
                "org_id": org_id,
                "name": f"Lookalike: {source_data['name']}",
                "description": (
                    f"Lookalike audience based on '{source_data['name']}' "
                    f"with {expansion_factor}x expansion"
                ),
                "rules": source_data.get("rules", []),
                "audience_type": "lookalike",
                "source_audience_id": source_audience_id,
                "estimated_size": estimated_size,
                "status": "draft",
            }
        )
        .execute()
    )

    return {
        "audience": result.data[0],
        "source_audience": source_data["name"],
        "expansion_factor": expansion_factor,
        "estimated_size": estimated_size,
        "requires_approval": True,
    }


AUDIENCE_TOOLS = [
    query_customer_schema,
    estimate_audience_size,
    create_audience_draft,
    build_lookalike_audience,
]
