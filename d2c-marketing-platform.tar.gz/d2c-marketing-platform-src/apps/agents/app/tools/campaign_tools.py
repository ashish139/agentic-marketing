from datetime import datetime, timedelta

from langchain_core.tools import tool

from app.db.supabase_client import get_supabase


@tool
def get_campaign_metrics(
    org_id: str,
    campaign_id: str,
    start_date: str = "",
    end_date: str = "",
) -> dict:
    """Get performance metrics for a campaign over a date range.

    Args:
        org_id: Organization ID
        campaign_id: Campaign ID
        start_date: Start date (YYYY-MM-DD). Defaults to 30 days ago.
        end_date: End date (YYYY-MM-DD). Defaults to today.

    Returns:
        dict with campaign info and aggregated metrics.
    """
    sb = get_supabase()

    if not start_date:
        start_date = (datetime.utcnow() - timedelta(days=30)).strftime("%Y-%m-%d")
    if not end_date:
        end_date = datetime.utcnow().strftime("%Y-%m-%d")

    # Get campaign info
    campaign = (
        sb.table("campaigns")
        .select("*")
        .eq("id", campaign_id)
        .eq("org_id", org_id)
        .single()
        .execute()
    )

    # Get metrics for the date range
    metrics = (
        sb.table("campaign_metrics")
        .select("*")
        .eq("campaign_id", campaign_id)
        .gte("date", start_date)
        .lte("date", end_date)
        .order("date")
        .execute()
    )

    rows = metrics.data or []

    total_impressions = sum(r.get("impressions", 0) for r in rows)
    total_clicks = sum(r.get("clicks", 0) for r in rows)
    total_conversions = sum(r.get("conversions", 0) for r in rows)
    total_spend = sum(float(r.get("spend", 0)) for r in rows)
    total_revenue = sum(float(r.get("revenue", 0)) for r in rows)

    ctr = round((total_clicks / total_impressions * 100), 2) if total_impressions > 0 else 0
    cpc = round((total_spend / total_clicks), 2) if total_clicks > 0 else 0
    cpa = round((total_spend / total_conversions), 2) if total_conversions > 0 else 0
    roas = round((total_revenue / total_spend), 2) if total_spend > 0 else 0

    return {
        "campaign": campaign.data,
        "date_range": {"start": start_date, "end": end_date},
        "metrics": {
            "impressions": total_impressions,
            "clicks": total_clicks,
            "conversions": total_conversions,
            "spend": round(total_spend, 2),
            "revenue": round(total_revenue, 2),
            "ctr": ctr,
            "cpc": cpc,
            "cpa": cpa,
            "roas": roas,
        },
        "daily_breakdown": rows,
    }


@tool
def compare_campaigns(org_id: str, campaign_ids: list[str]) -> dict:
    """Compare performance metrics across multiple campaigns side by side.

    Args:
        org_id: Organization ID
        campaign_ids: List of campaign IDs to compare

    Returns:
        dict with each campaign's metrics for comparison.
    """
    sb = get_supabase()

    comparisons = []
    for cid in campaign_ids:
        campaign = (
            sb.table("campaigns")
            .select("id, name, campaign_type, status")
            .eq("id", cid)
            .eq("org_id", org_id)
            .single()
            .execute()
        )

        metrics = (
            sb.table("campaign_metrics")
            .select("impressions, clicks, conversions, spend, revenue")
            .eq("campaign_id", cid)
            .execute()
        )

        rows = metrics.data or []
        total_impressions = sum(r.get("impressions", 0) for r in rows)
        total_clicks = sum(r.get("clicks", 0) for r in rows)
        total_conversions = sum(r.get("conversions", 0) for r in rows)
        total_spend = sum(float(r.get("spend", 0)) for r in rows)
        total_revenue = sum(float(r.get("revenue", 0)) for r in rows)

        ctr = round((total_clicks / total_impressions * 100), 2) if total_impressions > 0 else 0
        cpc = round((total_spend / total_clicks), 2) if total_clicks > 0 else 0
        cpa = round((total_spend / total_conversions), 2) if total_conversions > 0 else 0
        roas = round((total_revenue / total_spend), 2) if total_spend > 0 else 0

        comparisons.append(
            {
                "campaign": campaign.data,
                "metrics": {
                    "impressions": total_impressions,
                    "clicks": total_clicks,
                    "conversions": total_conversions,
                    "spend": round(total_spend, 2),
                    "revenue": round(total_revenue, 2),
                    "ctr": ctr,
                    "cpc": cpc,
                    "cpa": cpa,
                    "roas": roas,
                },
            }
        )

    # Determine the best performer by ROAS
    best_roas = max(comparisons, key=lambda c: c["metrics"]["roas"])
    best_cpa = min(comparisons, key=lambda c: c["metrics"]["cpa"]) if any(c["metrics"]["cpa"] > 0 for c in comparisons) else None

    return {
        "comparisons": comparisons,
        "insights": {
            "best_roas": best_roas["campaign"]["name"] if best_roas else None,
            "best_cpa": best_cpa["campaign"]["name"] if best_cpa else None,
        },
    }


@tool
def suggest_optimization(org_id: str, campaign_id: str) -> dict:
    """Analyze campaign performance and suggest optimizations.

    Args:
        org_id: Organization ID
        campaign_id: Campaign ID to analyze

    Returns:
        dict with performance summary and suggested optimizations.
    """
    sb = get_supabase()

    # Get the last 30 days of metrics
    thirty_days_ago = (datetime.utcnow() - timedelta(days=30)).strftime("%Y-%m-%d")

    campaign = (
        sb.table("campaigns")
        .select("*")
        .eq("id", campaign_id)
        .eq("org_id", org_id)
        .single()
        .execute()
    )

    metrics = (
        sb.table("campaign_metrics")
        .select("*")
        .eq("campaign_id", campaign_id)
        .gte("date", thirty_days_ago)
        .order("date")
        .execute()
    )

    rows = metrics.data or []
    if not rows:
        return {
            "campaign": campaign.data,
            "suggestions": ["No metrics data available. Ensure the campaign is running and tracking is configured."],
        }

    total_impressions = sum(r.get("impressions", 0) for r in rows)
    total_clicks = sum(r.get("clicks", 0) for r in rows)
    total_conversions = sum(r.get("conversions", 0) for r in rows)
    total_spend = sum(float(r.get("spend", 0)) for r in rows)
    total_revenue = sum(float(r.get("revenue", 0)) for r in rows)

    ctr = (total_clicks / total_impressions * 100) if total_impressions > 0 else 0
    cpc = (total_spend / total_clicks) if total_clicks > 0 else 0
    cpa = (total_spend / total_conversions) if total_conversions > 0 else 0
    roas = (total_revenue / total_spend) if total_spend > 0 else 0
    conv_rate = (total_conversions / total_clicks * 100) if total_clicks > 0 else 0

    suggestions = []

    # CTR analysis
    if ctr < 1.0:
        suggestions.append(
            "Low CTR (below 1%). Consider refreshing ad creatives, "
            "testing new headlines, or narrowing audience targeting."
        )
    elif ctr > 5.0:
        suggestions.append(
            "Excellent CTR. Consider scaling budget to capture more of this audience."
        )

    # CPA analysis (D2C benchmarks)
    if cpa > 50:
        suggestions.append(
            f"High CPA (${cpa:.2f}). Test lower-funnel audiences, "
            "retargeting, or landing page optimizations to improve conversion rate."
        )

    # ROAS analysis
    if roas < 2.0:
        suggestions.append(
            f"ROAS ({roas:.1f}x) is below the 2x break-even threshold. "
            "Consider pausing underperforming ad sets or shifting budget to higher-performing creatives."
        )
    elif roas > 5.0:
        suggestions.append(
            f"Strong ROAS ({roas:.1f}x). This campaign is highly profitable. "
            "Consider increasing daily budget by 20-30% to scale."
        )

    # Conversion rate analysis
    if conv_rate < 2.0 and total_clicks > 100:
        suggestions.append(
            "Low conversion rate despite decent traffic. "
            "Focus on landing page optimization, offer clarity, or checkout flow improvements."
        )

    # Trend analysis: compare last 7 days vs previous 7 days
    if len(rows) >= 14:
        recent = rows[-7:]
        previous = rows[-14:-7]
        recent_spend = sum(float(r.get("spend", 0)) for r in recent)
        prev_spend = sum(float(r.get("spend", 0)) for r in previous)
        recent_conv = sum(r.get("conversions", 0) for r in recent)
        prev_conv = sum(r.get("conversions", 0) for r in previous)

        if prev_conv > 0 and recent_conv < prev_conv * 0.7:
            suggestions.append(
                "Conversions dropped by 30%+ in the last week. "
                "Check for creative fatigue, audience saturation, or external factors."
            )

    if not suggestions:
        suggestions.append("Campaign performance is within healthy ranges. Continue monitoring.")

    return {
        "campaign": campaign.data,
        "performance_summary": {
            "ctr": round(ctr, 2),
            "cpc": round(cpc, 2),
            "cpa": round(cpa, 2),
            "roas": round(roas, 2),
            "conversion_rate": round(conv_rate, 2),
            "total_spend": round(total_spend, 2),
            "total_revenue": round(total_revenue, 2),
        },
        "suggestions": suggestions,
    }


@tool
def forecast_budget(
    org_id: str,
    campaign_id: str,
    new_daily_budget: float,
    days: int = 30,
) -> dict:
    """Forecast the impact of a budget change on campaign performance.

    Args:
        org_id: Organization ID
        campaign_id: Campaign ID
        new_daily_budget: Proposed new daily budget in dollars
        days: Number of days to forecast (default 30)

    Returns:
        dict with projected metrics at the new budget level.
    """
    sb = get_supabase()

    # Get recent metrics to establish baselines
    seven_days_ago = (datetime.utcnow() - timedelta(days=7)).strftime("%Y-%m-%d")

    metrics = (
        sb.table("campaign_metrics")
        .select("*")
        .eq("campaign_id", campaign_id)
        .gte("date", seven_days_ago)
        .execute()
    )

    rows = metrics.data or []
    if not rows:
        return {"error": "No recent metrics available for forecasting."}

    # Calculate daily averages from recent data
    num_days = len(rows)
    avg_daily_spend = sum(float(r.get("spend", 0)) for r in rows) / num_days
    avg_daily_impressions = sum(r.get("impressions", 0) for r in rows) / num_days
    avg_daily_clicks = sum(r.get("clicks", 0) for r in rows) / num_days
    avg_daily_conversions = sum(r.get("conversions", 0) for r in rows) / num_days
    avg_daily_revenue = sum(float(r.get("revenue", 0)) for r in rows) / num_days

    # Calculate scale factor (assumes linear scaling with diminishing returns)
    if avg_daily_spend > 0:
        raw_scale = new_daily_budget / avg_daily_spend
        # Apply diminishing returns: scale^0.8 for increases, scale^1.1 for decreases
        if raw_scale > 1:
            scale_factor = raw_scale ** 0.8
        else:
            scale_factor = raw_scale ** 1.1
    else:
        return {"error": "Current daily spend is zero, cannot forecast."}

    projected = {
        "daily_budget": new_daily_budget,
        "forecast_days": days,
        "current_daily_averages": {
            "spend": round(avg_daily_spend, 2),
            "impressions": round(avg_daily_impressions),
            "clicks": round(avg_daily_clicks),
            "conversions": round(avg_daily_conversions, 1),
            "revenue": round(avg_daily_revenue, 2),
        },
        "projected_daily_averages": {
            "spend": new_daily_budget,
            "impressions": round(avg_daily_impressions * scale_factor),
            "clicks": round(avg_daily_clicks * scale_factor),
            "conversions": round(avg_daily_conversions * scale_factor, 1),
            "revenue": round(avg_daily_revenue * scale_factor, 2),
        },
        "projected_totals": {
            "spend": round(new_daily_budget * days, 2),
            "impressions": round(avg_daily_impressions * scale_factor * days),
            "clicks": round(avg_daily_clicks * scale_factor * days),
            "conversions": round(avg_daily_conversions * scale_factor * days, 1),
            "revenue": round(avg_daily_revenue * scale_factor * days, 2),
        },
        "projected_roas": round(
            (avg_daily_revenue * scale_factor) / new_daily_budget, 2
        )
        if new_daily_budget > 0
        else 0,
        "budget_change_pct": round((raw_scale - 1) * 100, 1),
        "note": "Projections use diminishing returns model. Actual results may vary.",
    }

    return projected


CAMPAIGN_TOOLS = [
    get_campaign_metrics,
    compare_campaigns,
    suggest_optimization,
    forecast_budget,
]
