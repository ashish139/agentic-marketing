from langchain_core.tools import tool

from app.db.supabase_client import get_supabase


@tool
def get_brand_context(org_id: str) -> dict:
    """Get brand guidelines and context for the organization."""
    sb = get_supabase()
    result = (
        sb.table("organizations")
        .select("name, brand_guidelines, customer_schema")
        .eq("id", org_id)
        .single()
        .execute()
    )
    return result.data


@tool
def get_customer_schema(org_id: str) -> dict:
    """Get the customer data schema with available fields and their types."""
    sb = get_supabase()
    result = (
        sb.table("organizations")
        .select("customer_schema")
        .eq("id", org_id)
        .single()
        .execute()
    )
    return result.data["customer_schema"]


COMMON_TOOLS = [get_brand_context, get_customer_schema]
