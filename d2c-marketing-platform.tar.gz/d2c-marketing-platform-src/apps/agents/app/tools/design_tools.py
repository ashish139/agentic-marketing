from langchain_core.tools import tool


@tool
def generate_ad_copy(
    brand_guidelines: dict,
    audience_description: str,
    product: str,
    platform: str,
    num_variations: int = 3,
) -> dict:
    """Generate ad copy variations. Returns a structured template for the LLM
    to fill with headlines, body text, and CTAs.

    Args:
        brand_guidelines: Brand tone, colors, do/don't rules
        audience_description: Who the ad targets
        product: Product or offer being promoted
        platform: Ad platform (google_ads, facebook_ads, instagram, tiktok)
        num_variations: Number of copy variations to generate (default 3)

    Returns:
        dict with platform constraints and a template the LLM will complete.
    """
    platform_constraints = {
        "google_ads": {
            "headline_max_chars": 30,
            "description_max_chars": 90,
            "headlines_needed": 3,
            "descriptions_needed": 2,
        },
        "facebook_ads": {
            "headline_max_chars": 40,
            "body_max_chars": 125,
            "cta_options": [
                "Shop Now",
                "Learn More",
                "Sign Up",
                "Get Offer",
                "Book Now",
            ],
        },
        "instagram": {
            "caption_max_chars": 2200,
            "effective_chars": 125,
            "hashtags_recommended": 5,
        },
        "tiktok": {
            "text_max_chars": 100,
            "tone": "casual, authentic, trend-aware",
        },
    }

    constraints = platform_constraints.get(platform, platform_constraints["facebook_ads"])

    return {
        "template": {
            "platform": platform,
            "constraints": constraints,
            "audience": audience_description,
            "product": product,
            "brand_tone": brand_guidelines.get("tone", "professional"),
            "brand_voice": brand_guidelines.get("voice", ""),
            "colors": brand_guidelines.get("colors", {}),
            "do_not_use": brand_guidelines.get("do_not_use", []),
            "num_variations": num_variations,
            "format": (
                "Return a JSON array of variations. Each variation should have: "
                "headline, body, cta, and a brief rationale for the approach."
            ),
        }
    }


@tool
def generate_email_template(
    brand_guidelines: dict,
    campaign_type: str,
    audience_description: str,
    key_message: str,
) -> dict:
    """Generate an email template with subject line and body.

    Args:
        brand_guidelines: Brand tone, colors, font preferences
        campaign_type: Type of email (welcome, promotional, abandoned_cart,
                       post_purchase, re_engagement, newsletter)
        audience_description: Who receives this email
        key_message: The main message or offer

    Returns:
        dict with template structure and brand-aligned guidelines.
    """
    type_guidelines = {
        "welcome": {
            "tone": "warm, excited",
            "sections": ["hero_banner", "welcome_message", "value_props", "cta"],
            "cta_text": "Start Shopping",
            "subject_tips": "Include brand name, set expectations",
        },
        "promotional": {
            "tone": "urgent, exciting",
            "sections": ["hero_offer", "product_grid", "urgency_banner", "cta"],
            "cta_text": "Shop the Sale",
            "subject_tips": "Lead with discount %, use urgency words",
        },
        "abandoned_cart": {
            "tone": "helpful, gentle nudge",
            "sections": ["reminder_header", "cart_items", "incentive", "cta"],
            "cta_text": "Complete Your Order",
            "subject_tips": "Reference items left behind, add incentive",
        },
        "post_purchase": {
            "tone": "grateful, supportive",
            "sections": ["thank_you", "order_summary", "recommendations", "cta"],
            "cta_text": "Track Your Order",
            "subject_tips": "Confirm order, set delivery expectations",
        },
        "re_engagement": {
            "tone": "friendly, we-miss-you",
            "sections": ["reconnect_header", "whats_new", "special_offer", "cta"],
            "cta_text": "Come Back & Save",
            "subject_tips": "Personal, reference time away, include offer",
        },
        "newsletter": {
            "tone": "informative, brand-aligned",
            "sections": ["header", "featured_content", "product_spotlight", "cta"],
            "cta_text": "Read More",
            "subject_tips": "Curiosity-driven, highlight top story",
        },
    }

    guidelines = type_guidelines.get(campaign_type, type_guidelines["promotional"])

    return {
        "template": {
            "campaign_type": campaign_type,
            "audience": audience_description,
            "key_message": key_message,
            "type_guidelines": guidelines,
            "brand_tone": brand_guidelines.get("tone", "professional"),
            "brand_colors": brand_guidelines.get("colors", {}),
            "brand_fonts": brand_guidelines.get("fonts", {}),
            "logo_url": brand_guidelines.get("logo_url", ""),
            "format": (
                "Return JSON with: subject (under 50 chars), preview_text (under 90 chars), "
                "sections (array of {type, content_html}), and cta_text."
            ),
        }
    }


@tool
def apply_brand_guidelines(content: str, brand_guidelines: dict) -> dict:
    """Review content against brand guidelines and suggest adjustments.

    Args:
        content: The marketing content to review
        brand_guidelines: Brand rules including tone, forbidden words, etc.

    Returns:
        dict with compliance analysis and suggested fixes.
    """
    tone = brand_guidelines.get("tone", "")
    do_not_use = brand_guidelines.get("do_not_use", [])
    required_elements = brand_guidelines.get("required_elements", [])

    issues: list[dict] = []
    content_lower = content.lower()

    # Check for forbidden words/phrases
    for word in do_not_use:
        if word.lower() in content_lower:
            issues.append(
                {
                    "type": "forbidden_word",
                    "word": word,
                    "suggestion": f"Remove or replace '{word}' - it violates brand guidelines.",
                }
            )

    # Check for required elements
    for element in required_elements:
        if element.lower() not in content_lower:
            issues.append(
                {
                    "type": "missing_element",
                    "element": element,
                    "suggestion": f"Consider including '{element}' as required by brand guidelines.",
                }
            )

    return {
        "content": content,
        "brand_tone": tone,
        "is_compliant": len(issues) == 0,
        "issues": issues,
        "issue_count": len(issues),
        "message": (
            "Content is brand-compliant."
            if not issues
            else f"Found {len(issues)} brand guideline issue(s) to address."
        ),
    }


@tool
def create_variations(
    original_content: dict,
    num_variations: int = 3,
) -> dict:
    """Create A/B test variations of existing content.

    Args:
        original_content: Original content dict with headline, body, cta fields
        num_variations: Number of variations to create (default 3)

    Returns:
        dict with variation guidelines for the LLM to generate.
    """
    strategies = [
        {
            "name": "urgency",
            "description": "Add time pressure or scarcity",
            "example_modifiers": ["Limited time", "Only X left", "Ends tonight"],
        },
        {
            "name": "social_proof",
            "description": "Add customer validation",
            "example_modifiers": ["Join 10K+ customers", "Top rated", "As seen in"],
        },
        {
            "name": "benefit_focused",
            "description": "Lead with the outcome, not the feature",
            "example_modifiers": ["Transform your", "Finally,", "The secret to"],
        },
        {
            "name": "question_hook",
            "description": "Open with an engaging question",
            "example_modifiers": ["Ready to", "What if", "Tired of"],
        },
        {
            "name": "direct_value",
            "description": "Lead with the offer/discount",
            "example_modifiers": ["Save X%", "Free shipping", "Buy 1 get 1"],
        },
    ]

    # Pick strategies for the requested number of variations
    selected = strategies[:num_variations]

    return {
        "original": original_content,
        "variation_strategies": selected,
        "num_variations": num_variations,
        "format": (
            "For each strategy, create a variation of the original content. "
            "Return JSON array with: strategy_name, headline, body, cta, "
            "and hypothesis (what you expect this variation to test)."
        ),
    }


DESIGN_TOOLS = [
    generate_ad_copy,
    generate_email_template,
    apply_brand_guidelines,
    create_variations,
]
