from langchain_core.tools import tool

from app.db.supabase_client import get_supabase


@tool
def create_journey_draft(
    org_id: str,
    name: str,
    description: str,
    entry_conditions: dict,
    goal: dict = {},
) -> dict:
    """Create a new journey draft.

    Args:
        org_id: Organization ID
        name: Journey name
        description: What this journey does
        entry_conditions: Conditions that trigger journey entry,
            e.g. {"event": "signup", "filters": {"source": "organic"}}
        goal: Optional goal definition,
            e.g. {"event": "purchase", "within_days": 7}

    Returns:
        dict with the created journey and approval status.
    """
    sb = get_supabase()

    result = (
        sb.table("journeys")
        .insert(
            {
                "org_id": org_id,
                "name": name,
                "description": description,
                "entry_conditions": entry_conditions,
                "goal": goal,
                "status": "draft",
                "steps": [],
            }
        )
        .execute()
    )

    return {
        "journey": result.data[0],
        "requires_approval": True,
        "message": f"Journey '{name}' created as draft. Add steps before activating.",
    }


@tool
def add_journey_step(
    journey_id: str,
    step_type: str,
    title: str,
    config: dict,
    sort_order: int,
    position_x: int = 0,
    position_y: int = 0,
) -> dict:
    """Add a step to an existing journey.

    Args:
        journey_id: ID of the journey to add a step to
        step_type: One of: email, sms, push, wait, condition, split, webhook, retarget_ad
        title: Display title for this step
        config: Step configuration. Examples:
            - email: {"template_id": "...", "subject": "..."}
            - wait: {"duration": "2d"} or {"duration": "4h"}
            - condition: {"field": "properties.ltv", "op": "gt", "value": 100,
                          "true_next": 3, "false_next": 4}
            - split: {"variant_a_pct": 50, "variant_b_pct": 50}
            - retarget_ad: {"platform": "facebook_ads", "audience_id": "..."}
        sort_order: Position in the journey sequence (1-based)
        position_x: X coordinate for visual canvas placement
        position_y: Y coordinate for visual canvas placement

    Returns:
        dict with the updated journey steps.
    """
    sb = get_supabase()

    # Fetch current journey
    journey = (
        sb.table("journeys")
        .select("steps")
        .eq("id", journey_id)
        .single()
        .execute()
    )

    current_steps = journey.data.get("steps", []) or []

    new_step = {
        "id": len(current_steps) + 1,
        "step_type": step_type,
        "title": title,
        "config": config,
        "sort_order": sort_order,
        "position_x": position_x,
        "position_y": position_y,
    }

    current_steps.append(new_step)
    # Sort by sort_order
    current_steps.sort(key=lambda s: s["sort_order"])

    result = (
        sb.table("journeys")
        .update({"steps": current_steps})
        .eq("id", journey_id)
        .execute()
    )

    return {
        "journey_id": journey_id,
        "added_step": new_step,
        "total_steps": len(current_steps),
        "all_steps": current_steps,
    }


@tool
def set_entry_condition(journey_id: str, entry_conditions: dict) -> dict:
    """Update the entry conditions for a journey.

    Args:
        journey_id: ID of the journey
        entry_conditions: New entry conditions, e.g.
            {"event": "cart_abandoned", "filters": {"cart_value_gt": 50},
             "cooldown_days": 30}

    Returns:
        dict with updated journey entry conditions.
    """
    sb = get_supabase()

    result = (
        sb.table("journeys")
        .update({"entry_conditions": entry_conditions})
        .eq("id", journey_id)
        .execute()
    )

    return {
        "journey_id": journey_id,
        "entry_conditions": entry_conditions,
        "message": "Entry conditions updated successfully.",
    }


@tool
def validate_journey(journey_id: str) -> dict:
    """Validate a journey's structure.

    Checks that all steps are connected, the journey has entry and exit
    conditions, wait steps have valid durations, and conditions have both
    true/false branches.

    Args:
        journey_id: ID of the journey to validate

    Returns:
        dict with validation results and any issues found.
    """
    sb = get_supabase()

    journey = (
        sb.table("journeys")
        .select("*")
        .eq("id", journey_id)
        .single()
        .execute()
    )

    data = journey.data
    steps = data.get("steps", []) or []
    entry_conditions = data.get("entry_conditions", {}) or {}
    issues: list[str] = []
    warnings: list[str] = []

    # Check entry conditions exist
    if not entry_conditions:
        issues.append("Journey has no entry conditions defined.")

    # Check steps exist
    if not steps:
        issues.append("Journey has no steps. Add at least one step.")
    else:
        # Check for at least one action step (not just waits/conditions)
        action_types = {"email", "sms", "push", "webhook", "retarget_ad"}
        action_steps = [s for s in steps if s.get("step_type") in action_types]
        if not action_steps:
            warnings.append(
                "Journey has no action steps (email, SMS, push, etc.). "
                "Consider adding at least one."
            )

        # Validate each step
        for step in steps:
            step_type = step.get("step_type", "")
            step_title = step.get("title", f"Step {step.get('id', '?')}")
            config = step.get("config", {})

            if step_type == "wait":
                if not config.get("duration"):
                    issues.append(f"Wait step '{step_title}' has no duration set.")

            elif step_type == "condition":
                if not config.get("field"):
                    issues.append(
                        f"Condition step '{step_title}' has no field to evaluate."
                    )
                if "true_next" not in config or "false_next" not in config:
                    warnings.append(
                        f"Condition step '{step_title}' is missing true/false branch targets."
                    )

            elif step_type == "split":
                a_pct = config.get("variant_a_pct", 0)
                b_pct = config.get("variant_b_pct", 0)
                if a_pct + b_pct != 100:
                    issues.append(
                        f"Split step '{step_title}' percentages don't add up to 100 "
                        f"(got {a_pct}% + {b_pct}%)."
                    )

            elif step_type == "email":
                if not config.get("template_id") and not config.get("subject"):
                    warnings.append(
                        f"Email step '{step_title}' has no template or subject configured."
                    )

        # Check sort order continuity
        sort_orders = sorted(s.get("sort_order", 0) for s in steps)
        expected = list(range(1, len(steps) + 1))
        if sort_orders != expected:
            warnings.append(
                "Step sort_order values are not sequential. "
                "This may cause rendering issues on the canvas."
            )

    is_valid = len(issues) == 0

    return {
        "journey_id": journey_id,
        "journey_name": data.get("name", ""),
        "is_valid": is_valid,
        "issues": issues,
        "warnings": warnings,
        "step_count": len(steps),
        "message": (
            "Journey is valid and ready for activation."
            if is_valid
            else f"Journey has {len(issues)} issue(s) that must be fixed."
        ),
    }


JOURNEY_TOOLS = [
    create_journey_draft,
    add_journey_step,
    set_entry_condition,
    validate_journey,
]
