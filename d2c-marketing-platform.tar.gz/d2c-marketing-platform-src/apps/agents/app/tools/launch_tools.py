from datetime import datetime

from langchain_core.tools import tool

from app.connectors.factory import get_connector
from app.db.supabase_client import get_supabase


@tool
async def publish_to_google_ads(org_id: str, campaign_id: str) -> dict:
    """Publish a campaign to Google Ads. This action requires human approval.

    Args:
        org_id: Organization ID
        campaign_id: Campaign ID to publish

    Returns:
        dict with publish details and approval requirement.
    """
    sb = get_supabase()

    # Fetch campaign details
    campaign = (
        sb.table("campaigns")
        .select("*")
        .eq("id", campaign_id)
        .eq("org_id", org_id)
        .single()
        .execute()
    )
    campaign_data = campaign.data

    # Fetch associated audience
    audience_id = campaign_data.get("audience_id")
    audience_data = None
    if audience_id:
        audience = (
            sb.table("audiences")
            .select("name, estimated_size")
            .eq("id", audience_id)
            .single()
            .execute()
        )
        audience_data = audience.data

    connector = get_connector("google_ads", use_mock=True)

    # Test connection
    connected = await connector.test_connection()
    if not connected:
        return {"error": "Failed to connect to Google Ads. Check credentials."}

    return {
        "platform": "google_ads",
        "campaign": {
            "id": campaign_id,
            "name": campaign_data.get("name"),
            "type": campaign_data.get("campaign_type"),
            "daily_budget": campaign_data.get("daily_budget"),
            "total_budget": campaign_data.get("total_budget"),
        },
        "audience": audience_data,
        "requires_approval": True,
        "message": (
            f"Ready to publish '{campaign_data.get('name')}' to Google Ads. "
            f"Daily budget: ${campaign_data.get('daily_budget', 0)}. "
            f"Awaiting human approval before going live."
        ),
    }


@tool
async def publish_to_facebook_ads(org_id: str, campaign_id: str) -> dict:
    """Publish a campaign to Facebook Ads. This action requires human approval.

    Args:
        org_id: Organization ID
        campaign_id: Campaign ID to publish

    Returns:
        dict with publish details and approval requirement.
    """
    sb = get_supabase()

    campaign = (
        sb.table("campaigns")
        .select("*")
        .eq("id", campaign_id)
        .eq("org_id", org_id)
        .single()
        .execute()
    )
    campaign_data = campaign.data

    audience_id = campaign_data.get("audience_id")
    audience_data = None
    if audience_id:
        audience = (
            sb.table("audiences")
            .select("name, estimated_size")
            .eq("id", audience_id)
            .single()
            .execute()
        )
        audience_data = audience.data

    connector = get_connector("facebook_ads", use_mock=True)

    connected = await connector.test_connection()
    if not connected:
        return {"error": "Failed to connect to Facebook Ads. Check credentials."}

    return {
        "platform": "facebook_ads",
        "campaign": {
            "id": campaign_id,
            "name": campaign_data.get("name"),
            "type": campaign_data.get("campaign_type"),
            "daily_budget": campaign_data.get("daily_budget"),
            "total_budget": campaign_data.get("total_budget"),
        },
        "audience": audience_data,
        "requires_approval": True,
        "message": (
            f"Ready to publish '{campaign_data.get('name')}' to Facebook Ads. "
            f"Daily budget: ${campaign_data.get('daily_budget', 0)}. "
            f"Awaiting human approval before going live."
        ),
    }


@tool
def schedule_send(
    org_id: str,
    campaign_id: str,
    send_date: str,
    send_time: str,
) -> dict:
    """Schedule a campaign to be sent at a specific date and time.

    Args:
        org_id: Organization ID
        campaign_id: Campaign ID to schedule
        send_date: Date to send (YYYY-MM-DD)
        send_time: Time to send in UTC (HH:MM)

    Returns:
        dict with scheduling confirmation.
    """
    sb = get_supabase()

    # Validate the date is in the future
    scheduled_dt = datetime.strptime(f"{send_date} {send_time}", "%Y-%m-%d %H:%M")
    if scheduled_dt <= datetime.utcnow():
        return {"error": "Scheduled time must be in the future."}

    # Update campaign with scheduled time
    result = (
        sb.table("campaigns")
        .update(
            {
                "status": "scheduled",
                "scheduled_at": scheduled_dt.isoformat(),
            }
        )
        .eq("id", campaign_id)
        .eq("org_id", org_id)
        .execute()
    )

    campaign_data = result.data[0] if result.data else {}

    return {
        "campaign_id": campaign_id,
        "campaign_name": campaign_data.get("name", ""),
        "scheduled_at": scheduled_dt.isoformat(),
        "status": "scheduled",
        "requires_approval": True,
        "message": (
            f"Campaign '{campaign_data.get('name', '')}' scheduled for "
            f"{send_date} at {send_time} UTC. Awaiting approval to confirm."
        ),
    }


@tool
def set_budget(
    org_id: str,
    campaign_id: str,
    daily_budget: float = 0,
    total_budget: float = 0,
) -> dict:
    """Set or update campaign budget.

    Args:
        org_id: Organization ID
        campaign_id: Campaign ID
        daily_budget: Daily spend limit in dollars (0 to leave unchanged)
        total_budget: Total campaign budget in dollars (0 to leave unchanged)

    Returns:
        dict with updated budget details.
    """
    sb = get_supabase()

    # Build update payload with only non-zero values
    updates: dict = {}
    if daily_budget > 0:
        updates["daily_budget"] = daily_budget
    if total_budget > 0:
        updates["total_budget"] = total_budget

    if not updates:
        return {"error": "Provide at least one of daily_budget or total_budget."}

    result = (
        sb.table("campaigns")
        .update(updates)
        .eq("id", campaign_id)
        .eq("org_id", org_id)
        .execute()
    )

    campaign_data = result.data[0] if result.data else {}

    return {
        "campaign_id": campaign_id,
        "campaign_name": campaign_data.get("name", ""),
        "daily_budget": campaign_data.get("daily_budget"),
        "total_budget": campaign_data.get("total_budget"),
        "message": (
            f"Budget updated for '{campaign_data.get('name', '')}'. "
            f"Daily: ${campaign_data.get('daily_budget', 0)}, "
            f"Total: ${campaign_data.get('total_budget', 0)}."
        ),
    }


LAUNCH_TOOLS = [
    publish_to_google_ads,
    publish_to_facebook_ads,
    schedule_send,
    set_budget,
]
