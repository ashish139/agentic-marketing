import { buildApp } from './app.js';
import { config } from './config.js';

async function main() {
  const app = await buildApp();
  await app.listen({ port: config.port, host: '0.0.0.0' });
  console.log(`Gateway running on port ${config.port}`);
}

main().catch((err) => {
  console.error('Failed to start gateway:', err);
  process.exit(1);
});
