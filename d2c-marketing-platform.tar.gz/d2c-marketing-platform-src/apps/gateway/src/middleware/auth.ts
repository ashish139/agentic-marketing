import type { FastifyRequest, FastifyReply } from 'fastify';
import { supabaseAdmin } from '../services/supabaseAdmin.js';

declare module 'fastify' {
  interface FastifyRequest {
    auth: {
      userId: string;
      orgId: string;
      role: string;
    };
  }
}

export async function authMiddleware(
  request: FastifyRequest,
  reply: FastifyReply,
): Promise<void> {
  const authHeader = request.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return reply.status(401).send({
      error: 'Unauthorized',
      message: 'Missing or invalid Authorization header',
    });
  }

  const token = authHeader.slice(7);

  try {
    const {
      data: { user },
      error: userError,
    } = await supabaseAdmin.auth.getUser(token);

    if (userError || !user) {
      return reply.status(401).send({
        error: 'Unauthorized',
        message: 'Invalid or expired token',
      });
    }

    // Look up org membership
    const { data: membership, error: memberError } = await supabaseAdmin
      .from('org_members')
      .select('org_id, role')
      .eq('user_id', user.id)
      .limit(1)
      .single();

    if (memberError || !membership) {
      return reply.status(403).send({
        error: 'Forbidden',
        message: 'User is not a member of any organization',
      });
    }

    request.auth = {
      userId: user.id,
      orgId: membership.org_id,
      role: membership.role,
    };
  } catch (err) {
    request.log.error(err, 'Auth middleware error');
    return reply.status(401).send({
      error: 'Unauthorized',
      message: 'Authentication failed',
    });
  }
}
