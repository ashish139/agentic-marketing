import type { FastifyError, FastifyRequest, FastifyReply } from 'fastify';

export function errorHandler(
  error: FastifyError,
  request: FastifyRequest,
  reply: FastifyReply,
): void {
  request.log.error(error);

  const statusCode = error.statusCode ?? 500;

  const response: Record<string, unknown> = {
    error: statusCode >= 500 ? 'Internal Server Error' : error.message,
    message: error.message,
    statusCode,
  };

  if (error.validation) {
    response.error = 'Validation Error';
    response.details = error.validation;
    reply.status(400).send(response);
    return;
  }

  if (process.env.NODE_ENV !== 'production') {
    response.stack = error.stack;
  }

  reply.status(statusCode).send(response);
}
