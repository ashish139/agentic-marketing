import type { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { z } from 'zod';
import { config } from '../config.js';
import { supabaseAdmin } from '../services/supabaseAdmin.js';

const chatSchema = z.object({
  sessionId: z.string().uuid().optional(),
  content: z.string().min(1).max(10000),
});

export async function agentRoutes(app: FastifyInstance) {
  // POST /api/agent/chat — SSE proxy to Python agent service
  app.post('/chat', async (request: FastifyRequest, reply: FastifyReply) => {
    const parsed = chatSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({
        error: 'Validation Error',
        details: parsed.error.flatten().fieldErrors,
      });
    }

    const { content } = parsed.data;
    let { sessionId } = parsed.data;
    const { userId, orgId } = request.auth;

    // Create or fetch session
    if (!sessionId) {
      const { data: session, error } = await supabaseAdmin
        .from('agent_sessions')
        .insert({
          org_id: orgId,
          user_id: userId,
          title: content.slice(0, 100),
        })
        .select('id')
        .single();

      if (error || !session) {
        return reply.status(500).send({
          error: 'Failed to create session',
          message: error?.message,
        });
      }
      sessionId = session.id;
    } else {
      // Verify session belongs to user
      const { data: session, error } = await supabaseAdmin
        .from('agent_sessions')
        .select('id')
        .eq('id', sessionId)
        .eq('user_id', userId)
        .single();

      if (error || !session) {
        return reply.status(404).send({
          error: 'Session not found',
        });
      }
    }

    // Save user message
    await supabaseAdmin.from('agent_messages').insert({
      session_id: sessionId,
      role: 'user',
      content,
    });

    // Fetch brand context for the org
    const { data: org } = await supabaseAdmin
      .from('organizations')
      .select('brand_context, customer_schema')
      .eq('id', orgId)
      .single();

    // Set SSE headers
    reply.raw.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'X-Session-Id': sessionId,
    });

    let assistantContent = '';

    try {
      // Proxy request to Python agent service
      const agentResponse = await fetch(`${config.agentServiceUrl}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          org_id: orgId,
          user_id: userId,
          session_id: sessionId,
          content,
          brand_context: org?.brand_context ?? null,
          customer_schema: org?.customer_schema ?? null,
        }),
      });

      if (!agentResponse.ok || !agentResponse.body) {
        reply.raw.write(`data: ${JSON.stringify({ type: 'error', message: 'Agent service unavailable' })}\n\n`);
        reply.raw.end();
        return;
      }

      const reader = agentResponse.body.getReader();
      const decoder = new TextDecoder();

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        reply.raw.write(chunk);

        // Parse SSE data lines to accumulate assistant content
        const lines = chunk.split('\n');
        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.type === 'token' && data.content) {
                assistantContent += data.content;
              } else if (data.type === 'message' && data.content) {
                assistantContent = data.content;
              }
            } catch {
              // Not JSON, might be raw text SSE
              if (line.slice(6).trim() !== '[DONE]') {
                assistantContent += line.slice(6);
              }
            }
          }
        }
      }

      // Send done event
      reply.raw.write('data: [DONE]\n\n');
    } catch (err) {
      request.log.error(err, 'Agent proxy error');
      reply.raw.write(`data: ${JSON.stringify({ type: 'error', message: 'Stream interrupted' })}\n\n`);
    } finally {
      // Save assistant message if we got any content
      if (assistantContent.length > 0) {
        await supabaseAdmin.from('agent_messages').insert({
          session_id: sessionId,
          role: 'assistant',
          content: assistantContent,
        });
      }

      reply.raw.end();
    }

    // Prevent Fastify from trying to send a response (we already did via raw)
    return reply;
  });

  // GET /api/agent/sessions — list sessions for current user
  app.get('/sessions', async (request: FastifyRequest, reply: FastifyReply) => {
    const { userId } = request.auth;
    const { limit = '20', offset = '0' } = request.query as Record<string, string>;

    const { data: sessions, error, count } = await supabaseAdmin
      .from('agent_sessions')
      .select('id, title, created_at, updated_at', { count: 'exact' })
      .eq('user_id', userId)
      .order('updated_at', { ascending: false })
      .range(Number(offset), Number(offset) + Number(limit) - 1);

    if (error) {
      return reply.status(500).send({ error: 'Failed to fetch sessions', message: error.message });
    }

    return reply.send({
      data: sessions,
      total: count,
      limit: Number(limit),
      offset: Number(offset),
    });
  });

  // GET /api/agent/sessions/:id — get session with messages
  app.get('/sessions/:id', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };
    const { userId } = request.auth;

    const { data: session, error: sessionError } = await supabaseAdmin
      .from('agent_sessions')
      .select('*')
      .eq('id', id)
      .eq('user_id', userId)
      .single();

    if (sessionError || !session) {
      return reply.status(404).send({ error: 'Session not found' });
    }

    const { data: messages, error: messagesError } = await supabaseAdmin
      .from('agent_messages')
      .select('id, role, content, tool_calls, tool_results, created_at')
      .eq('session_id', id)
      .order('created_at', { ascending: true });

    if (messagesError) {
      return reply.status(500).send({ error: 'Failed to fetch messages', message: messagesError.message });
    }

    return reply.send({
      ...session,
      messages: messages ?? [],
    });
  });
}
