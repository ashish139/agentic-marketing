import type { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { z } from 'zod';
import { supabaseAdmin } from '../services/supabaseAdmin.js';

const analyticsQuerySchema = z.object({
  type: z.enum(['funnel', 'cohort', 'retention', 'events', 'aggregate']),
  event_names: z.array(z.string()).optional(),
  date_range: z.object({
    start: z.string(),
    end: z.string(),
  }),
  group_by: z.string().optional(),
  filters: z.array(z.object({
    field: z.string(),
    operator: z.enum(['eq', 'neq', 'gt', 'gte', 'lt', 'lte', 'in', 'like']),
    value: z.unknown(),
  })).optional(),
  granularity: z.enum(['hour', 'day', 'week', 'month']).optional(),
  limit: z.number().optional(),
});

const createDashboardSchema = z.object({
  name: z.string().min(1).max(255),
  description: z.string().optional(),
  layout: z.record(z.unknown()).optional(),
});

const createWidgetSchema = z.object({
  name: z.string().min(1),
  type: z.enum(['line_chart', 'bar_chart', 'pie_chart', 'metric', 'table', 'funnel', 'heatmap']),
  query_config: z.record(z.unknown()),
  position: z.object({
    x: z.number(),
    y: z.number(),
    w: z.number(),
    h: z.number(),
  }).optional(),
});

export async function analyticsRoutes(app: FastifyInstance) {
  // POST /api/analytics/query — execute analytics query
  app.post('/query', async (request: FastifyRequest, reply: FastifyReply) => {
    const parsed = analyticsQuerySchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Validation Error', details: parsed.error.flatten().fieldErrors });
    }

    const { orgId } = request.auth;
    const query = parsed.data;

    try {
      let result: unknown;

      switch (query.type) {
        case 'events': {
          result = await queryEvents(orgId, query);
          break;
        }
        case 'funnel': {
          result = await queryFunnel(orgId, query);
          break;
        }
        case 'cohort': {
          result = await queryCohort(orgId, query);
          break;
        }
        case 'retention': {
          result = await queryRetention(orgId, query);
          break;
        }
        case 'aggregate': {
          result = await queryAggregate(orgId, query);
          break;
        }
      }

      return reply.send({ data: result });
    } catch (err) {
      request.log.error(err, 'Analytics query error');
      return reply.status(500).send({ error: 'Analytics query failed' });
    }
  });

  // GET /api/analytics/dashboards — list dashboards (registered under /api/analytics prefix)
  app.get('/dashboards', async (request: FastifyRequest, reply: FastifyReply) => {
    const { orgId } = request.auth;

    const { data, error } = await supabaseAdmin
      .from('dashboards')
      .select('id, name, description, created_at, updated_at')
      .eq('org_id', orgId)
      .order('created_at', { ascending: false });

    if (error) {
      return reply.status(500).send({ error: 'Failed to fetch dashboards', message: error.message });
    }

    return reply.send({ data: data ?? [] });
  });

  // GET /api/analytics/dashboards/:id — get dashboard with widgets
  app.get('/dashboards/:id', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };
    const { orgId } = request.auth;

    const { data: dashboard, error } = await supabaseAdmin
      .from('dashboards')
      .select('*')
      .eq('id', id)
      .eq('org_id', orgId)
      .single();

    if (error || !dashboard) {
      return reply.status(404).send({ error: 'Dashboard not found' });
    }

    const { data: widgets } = await supabaseAdmin
      .from('dashboard_widgets')
      .select('*')
      .eq('dashboard_id', id)
      .order('created_at', { ascending: true });

    return reply.send({ ...dashboard, widgets: widgets ?? [] });
  });

  // POST /api/analytics/dashboards — create dashboard
  app.post('/dashboards', async (request: FastifyRequest, reply: FastifyReply) => {
    const parsed = createDashboardSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Validation Error', details: parsed.error.flatten().fieldErrors });
    }

    const { orgId, userId } = request.auth;

    const { data, error } = await supabaseAdmin
      .from('dashboards')
      .insert({
        ...parsed.data,
        org_id: orgId,
        created_by: userId,
      })
      .select()
      .single();

    if (error) {
      return reply.status(500).send({ error: 'Failed to create dashboard', message: error.message });
    }

    return reply.status(201).send(data);
  });

  // POST /api/analytics/dashboards/:id/widgets — add widget
  app.post('/dashboards/:id/widgets', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };
    const { orgId } = request.auth;

    // Verify dashboard belongs to org
    const { data: dashboard, error: dashError } = await supabaseAdmin
      .from('dashboards')
      .select('id')
      .eq('id', id)
      .eq('org_id', orgId)
      .single();

    if (dashError || !dashboard) {
      return reply.status(404).send({ error: 'Dashboard not found' });
    }

    const parsed = createWidgetSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Validation Error', details: parsed.error.flatten().fieldErrors });
    }

    const { data, error } = await supabaseAdmin
      .from('dashboard_widgets')
      .insert({
        ...parsed.data,
        dashboard_id: id,
      })
      .select()
      .single();

    if (error) {
      return reply.status(500).send({ error: 'Failed to add widget', message: error.message });
    }

    return reply.status(201).send(data);
  });
}

// --- Analytics Query Helpers ---

type QueryParams = z.infer<typeof analyticsQuerySchema>;

async function queryEvents(orgId: string, query: QueryParams) {
  let q = supabaseAdmin
    .from('analytics_events')
    .select('*', { count: 'exact' })
    .eq('org_id', orgId)
    .gte('timestamp', query.date_range.start)
    .lte('timestamp', query.date_range.end)
    .order('timestamp', { ascending: false })
    .limit(query.limit ?? 1000);

  if (query.event_names && query.event_names.length > 0) {
    q = q.in('event_name', query.event_names);
  }

  if (query.filters) {
    for (const filter of query.filters) {
      switch (filter.operator) {
        case 'eq': q = q.eq(filter.field, filter.value as string); break;
        case 'neq': q = q.neq(filter.field, filter.value as string); break;
        case 'gt': q = q.gt(filter.field, filter.value as string); break;
        case 'gte': q = q.gte(filter.field, filter.value as string); break;
        case 'lt': q = q.lt(filter.field, filter.value as string); break;
        case 'lte': q = q.lte(filter.field, filter.value as string); break;
        case 'in': q = q.in(filter.field, filter.value as string[]); break;
        case 'like': q = q.like(filter.field, filter.value as string); break;
      }
    }
  }

  const { data, count, error } = await q;
  if (error) throw error;

  return { events: data ?? [], total: count };
}

async function queryFunnel(orgId: string, query: QueryParams) {
  if (!query.event_names || query.event_names.length < 2) {
    return { error: 'Funnel requires at least 2 event names' };
  }

  const steps: Array<{ event: string; count: number; conversion_rate: number }> = [];

  for (let i = 0; i < query.event_names.length; i++) {
    const eventName = query.event_names[i];

    const { count, error } = await supabaseAdmin
      .from('analytics_events')
      .select('customer_id', { count: 'exact', head: true })
      .eq('org_id', orgId)
      .eq('event_name', eventName)
      .gte('timestamp', query.date_range.start)
      .lte('timestamp', query.date_range.end);

    if (error) throw error;

    const totalCount = count ?? 0;
    const prevCount = i > 0 ? steps[i - 1].count : totalCount;
    const conversionRate = prevCount > 0 ? (totalCount / prevCount) * 100 : 0;

    steps.push({
      event: eventName,
      count: totalCount,
      conversion_rate: Math.round(conversionRate * 100) / 100,
    });
  }

  return {
    steps,
    overall_conversion: steps.length > 1 && steps[0].count > 0
      ? Math.round((steps[steps.length - 1].count / steps[0].count) * 10000) / 100
      : 0,
  };
}

async function queryCohort(orgId: string, query: QueryParams) {
  // Group customers by their first event date, then track subsequent activity
  const { data, error } = await supabaseAdmin
    .from('analytics_events')
    .select('customer_id, event_name, timestamp')
    .eq('org_id', orgId)
    .gte('timestamp', query.date_range.start)
    .lte('timestamp', query.date_range.end)
    .order('timestamp', { ascending: true })
    .limit(query.limit ?? 10000);

  if (error) throw error;

  // Group by customer first-event month
  const customerFirstEvent = new Map<string, string>();
  const cohorts = new Map<string, Set<string>>();

  for (const event of data ?? []) {
    const custId = event.customer_id;
    if (!custId) continue;

    const month = event.timestamp.slice(0, 7); // YYYY-MM
    if (!customerFirstEvent.has(custId)) {
      customerFirstEvent.set(custId, month);
    }

    const cohortKey = customerFirstEvent.get(custId)!;
    if (!cohorts.has(cohortKey)) {
      cohorts.set(cohortKey, new Set());
    }
    cohorts.get(cohortKey)!.add(custId);
  }

  const result = Array.from(cohorts.entries()).map(([month, customers]) => ({
    cohort: month,
    size: customers.size,
  }));

  return { cohorts: result };
}

async function queryRetention(orgId: string, query: QueryParams) {
  const { data, error } = await supabaseAdmin
    .from('analytics_events')
    .select('customer_id, timestamp')
    .eq('org_id', orgId)
    .gte('timestamp', query.date_range.start)
    .lte('timestamp', query.date_range.end)
    .order('timestamp', { ascending: true })
    .limit(query.limit ?? 50000);

  if (error) throw error;

  // Calculate weekly retention
  const customerFirstWeek = new Map<string, number>();
  const weeklyActivity = new Map<string, Set<number>>();

  const startDate = new Date(query.date_range.start).getTime();

  for (const event of data ?? []) {
    const custId = event.customer_id;
    if (!custId) continue;

    const eventTime = new Date(event.timestamp).getTime();
    const weekNum = Math.floor((eventTime - startDate) / (7 * 24 * 60 * 60 * 1000));

    if (!customerFirstWeek.has(custId)) {
      customerFirstWeek.set(custId, weekNum);
    }

    if (!weeklyActivity.has(custId)) {
      weeklyActivity.set(custId, new Set());
    }
    weeklyActivity.get(custId)!.add(weekNum);
  }

  // Build retention matrix
  const maxWeeks = 12;
  const retentionByWeek: Array<{ week: number; retained: number; total: number; rate: number }> = [];

  for (let w = 0; w < maxWeeks; w++) {
    const cohortUsers = Array.from(customerFirstWeek.entries())
      .filter(([, firstWeek]) => firstWeek === 0);
    const total = cohortUsers.length;
    const retained = cohortUsers.filter(([custId]) =>
      weeklyActivity.get(custId)?.has(w)
    ).length;

    retentionByWeek.push({
      week: w,
      retained,
      total,
      rate: total > 0 ? Math.round((retained / total) * 10000) / 100 : 0,
    });
  }

  return { retention: retentionByWeek };
}

async function queryAggregate(orgId: string, query: QueryParams) {
  let q = supabaseAdmin
    .from('analytics_events')
    .select('event_name, customer_id', { count: 'exact' })
    .eq('org_id', orgId)
    .gte('timestamp', query.date_range.start)
    .lte('timestamp', query.date_range.end);

  if (query.event_names && query.event_names.length > 0) {
    q = q.in('event_name', query.event_names);
  }

  const { count, error } = await q;
  if (error) throw error;

  // Get unique customers
  const { data: uniqueData, error: uniqueError } = await supabaseAdmin
    .from('analytics_events')
    .select('customer_id')
    .eq('org_id', orgId)
    .gte('timestamp', query.date_range.start)
    .lte('timestamp', query.date_range.end)
    .limit(100000);

  if (uniqueError) throw uniqueError;

  const uniqueCustomers = new Set((uniqueData ?? []).map(d => d.customer_id).filter(Boolean));

  return {
    total_events: count ?? 0,
    unique_customers: uniqueCustomers.size,
    date_range: query.date_range,
  };
}
