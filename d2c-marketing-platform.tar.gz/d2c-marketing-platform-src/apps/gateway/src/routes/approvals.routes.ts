import type { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { z } from 'zod';
import { supabaseAdmin } from '../services/supabaseAdmin.js';

const rejectSchema = z.object({
  note: z.string().optional(),
});

export async function approvalRoutes(app: FastifyInstance) {
  // GET /api/approvals — list approvals
  app.get('/', async (request: FastifyRequest, reply: FastifyReply) => {
    const { orgId } = request.auth;
    const { status = 'pending', limit = '20', offset = '0' } = request.query as Record<string, string>;

    let query = supabaseAdmin
      .from('approvals')
      .select('id, entity_type, entity_id, entity_name, status, requested_by, reviewed_by, reviewed_at, note, created_at', { count: 'exact' })
      .eq('org_id', orgId)
      .order('created_at', { ascending: false })
      .range(Number(offset), Number(offset) + Number(limit) - 1);

    if (status !== 'all') {
      query = query.eq('status', status);
    }

    const { data, error, count } = await query;

    if (error) {
      return reply.status(500).send({ error: 'Failed to fetch approvals', message: error.message });
    }

    return reply.send({ data, total: count, limit: Number(limit), offset: Number(offset) });
  });

  // GET /api/approvals/:id — get approval detail
  app.get('/:id', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };
    const { orgId } = request.auth;

    const { data: approval, error } = await supabaseAdmin
      .from('approvals')
      .select('*')
      .eq('id', id)
      .eq('org_id', orgId)
      .single();

    if (error || !approval) {
      return reply.status(404).send({ error: 'Approval not found' });
    }

    // Fetch the linked entity details
    let entityData = null;
    if (approval.entity_type && approval.entity_id) {
      const tableName = getTableForEntityType(approval.entity_type);
      if (tableName) {
        const { data } = await supabaseAdmin
          .from(tableName)
          .select('*')
          .eq('id', approval.entity_id)
          .single();
        entityData = data;
      }
    }

    return reply.send({ ...approval, entity: entityData });
  });

  // POST /api/approvals/:id/approve — approve
  app.post('/:id/approve', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };
    const { orgId, userId, role } = request.auth;

    // Verify user has permission to approve (owner or admin)
    if (role !== 'owner' && role !== 'admin') {
      return reply.status(403).send({ error: 'Forbidden', message: 'Only owners and admins can approve' });
    }

    const { data: approval, error: fetchError } = await supabaseAdmin
      .from('approvals')
      .select('id, status, entity_type, entity_id')
      .eq('id', id)
      .eq('org_id', orgId)
      .single();

    if (fetchError || !approval) {
      return reply.status(404).send({ error: 'Approval not found' });
    }

    if (approval.status !== 'pending') {
      return reply.status(400).send({ error: `Approval is already ${approval.status}` });
    }

    const { data, error } = await supabaseAdmin
      .from('approvals')
      .update({
        status: 'approved',
        reviewed_by: userId,
        reviewed_at: new Date().toISOString(),
      })
      .eq('id', id)
      .select()
      .single();

    if (error) {
      return reply.status(500).send({ error: 'Failed to approve', message: error.message });
    }

    return reply.send({ message: 'Approved successfully', approval: data });
  });

  // POST /api/approvals/:id/reject — reject with optional note
  app.post('/:id/reject', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };
    const { orgId, userId, role } = request.auth;

    if (role !== 'owner' && role !== 'admin') {
      return reply.status(403).send({ error: 'Forbidden', message: 'Only owners and admins can reject' });
    }

    const parsed = rejectSchema.safeParse(request.body);
    const note = parsed.success ? parsed.data.note : undefined;

    const { data: approval, error: fetchError } = await supabaseAdmin
      .from('approvals')
      .select('id, status')
      .eq('id', id)
      .eq('org_id', orgId)
      .single();

    if (fetchError || !approval) {
      return reply.status(404).send({ error: 'Approval not found' });
    }

    if (approval.status !== 'pending') {
      return reply.status(400).send({ error: `Approval is already ${approval.status}` });
    }

    const updateData: Record<string, unknown> = {
      status: 'rejected',
      reviewed_by: userId,
      reviewed_at: new Date().toISOString(),
    };

    if (note) {
      updateData.note = note;
    }

    const { data, error } = await supabaseAdmin
      .from('approvals')
      .update(updateData)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      return reply.status(500).send({ error: 'Failed to reject', message: error.message });
    }

    return reply.send({ message: 'Rejected', approval: data });
  });
}

function getTableForEntityType(entityType: string): string | null {
  const mapping: Record<string, string> = {
    journey: 'journeys',
    campaign: 'campaigns',
    audience: 'audiences',
    connector: 'connectors',
  };
  return mapping[entityType] ?? null;
}
