import type { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { z } from 'zod';
import { supabaseAdmin } from '../services/supabaseAdmin.js';

const createAudienceSchema = z.object({
  name: z.string().min(1).max(255),
  description: z.string().optional(),
  rules: z.record(z.unknown()).optional(),
  tags: z.array(z.string()).optional(),
});

const updateAudienceSchema = z.object({
  name: z.string().min(1).max(255).optional(),
  description: z.string().optional(),
  rules: z.record(z.unknown()).optional(),
  tags: z.array(z.string()).optional(),
  status: z.enum(['active', 'archived']).optional(),
});

export async function audienceRoutes(app: FastifyInstance) {
  // GET /api/audiences — list audiences for org
  app.get('/', async (request: FastifyRequest, reply: FastifyReply) => {
    const { orgId } = request.auth;
    const { limit = '20', offset = '0', search, status } = request.query as Record<string, string>;

    let query = supabaseAdmin
      .from('audiences')
      .select('id, name, description, rules, tags, status, member_count, created_at, updated_at', { count: 'exact' })
      .eq('org_id', orgId)
      .order('created_at', { ascending: false })
      .range(Number(offset), Number(offset) + Number(limit) - 1);

    if (search) {
      query = query.ilike('name', `%${search}%`);
    }

    if (status) {
      query = query.eq('status', status);
    } else {
      query = query.neq('status', 'archived');
    }

    const { data, error, count } = await query;

    if (error) {
      return reply.status(500).send({ error: 'Failed to fetch audiences', message: error.message });
    }

    return reply.send({ data, total: count, limit: Number(limit), offset: Number(offset) });
  });

  // GET /api/audiences/:id — get single audience with member count
  app.get('/:id', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };
    const { orgId } = request.auth;

    const { data: audience, error } = await supabaseAdmin
      .from('audiences')
      .select('*')
      .eq('id', id)
      .eq('org_id', orgId)
      .single();

    if (error || !audience) {
      return reply.status(404).send({ error: 'Audience not found' });
    }

    // Fetch member count from audience_members
    const { count } = await supabaseAdmin
      .from('audience_members')
      .select('id', { count: 'exact', head: true })
      .eq('audience_id', id);

    return reply.send({ ...audience, member_count: count ?? 0 });
  });

  // POST /api/audiences — create audience
  app.post('/', async (request: FastifyRequest, reply: FastifyReply) => {
    const parsed = createAudienceSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Validation Error', details: parsed.error.flatten().fieldErrors });
    }

    const { orgId, userId } = request.auth;

    const { data, error } = await supabaseAdmin
      .from('audiences')
      .insert({
        ...parsed.data,
        org_id: orgId,
        created_by: userId,
        status: 'active',
      })
      .select()
      .single();

    if (error) {
      return reply.status(500).send({ error: 'Failed to create audience', message: error.message });
    }

    return reply.status(201).send(data);
  });

  // PATCH /api/audiences/:id — update audience
  app.patch('/:id', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };
    const { orgId } = request.auth;

    const parsed = updateAudienceSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Validation Error', details: parsed.error.flatten().fieldErrors });
    }

    const { data, error } = await supabaseAdmin
      .from('audiences')
      .update({ ...parsed.data, updated_at: new Date().toISOString() })
      .eq('id', id)
      .eq('org_id', orgId)
      .select()
      .single();

    if (error || !data) {
      return reply.status(404).send({ error: 'Audience not found or update failed' });
    }

    return reply.send(data);
  });

  // DELETE /api/audiences/:id — soft delete (archive)
  app.delete('/:id', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };
    const { orgId } = request.auth;

    const { data, error } = await supabaseAdmin
      .from('audiences')
      .update({ status: 'archived', updated_at: new Date().toISOString() })
      .eq('id', id)
      .eq('org_id', orgId)
      .select('id')
      .single();

    if (error || !data) {
      return reply.status(404).send({ error: 'Audience not found' });
    }

    return reply.send({ message: 'Audience archived', id: data.id });
  });

  // POST /api/audiences/:id/estimate — estimate audience size
  app.post('/:id/estimate', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };
    const { orgId } = request.auth;

    // Fetch audience rules
    const { data: audience, error: audienceError } = await supabaseAdmin
      .from('audiences')
      .select('rules')
      .eq('id', id)
      .eq('org_id', orgId)
      .single();

    if (audienceError || !audience) {
      return reply.status(404).send({ error: 'Audience not found' });
    }

    const rules = audience.rules as Record<string, unknown> | null;

    if (!rules || Object.keys(rules).length === 0) {
      // No rules = all customers
      const { count } = await supabaseAdmin
        .from('customers')
        .select('id', { count: 'exact', head: true })
        .eq('org_id', orgId);

      return reply.send({ estimated_size: count ?? 0, rules });
    }

    // Build query from rules
    let query = supabaseAdmin
      .from('customers')
      .select('id', { count: 'exact', head: true })
      .eq('org_id', orgId);

    // Apply rule filters
    const filters = rules.filters as Array<{
      field: string;
      operator: string;
      value: unknown;
    }> | undefined;

    if (filters && Array.isArray(filters)) {
      for (const filter of filters) {
        switch (filter.operator) {
          case 'eq':
            query = query.eq(filter.field, filter.value as string);
            break;
          case 'neq':
            query = query.neq(filter.field, filter.value as string);
            break;
          case 'gt':
            query = query.gt(filter.field, filter.value as string);
            break;
          case 'gte':
            query = query.gte(filter.field, filter.value as string);
            break;
          case 'lt':
            query = query.lt(filter.field, filter.value as string);
            break;
          case 'lte':
            query = query.lte(filter.field, filter.value as string);
            break;
          case 'like':
            query = query.like(filter.field, filter.value as string);
            break;
          case 'ilike':
            query = query.ilike(filter.field, filter.value as string);
            break;
          case 'in':
            query = query.in(filter.field, filter.value as string[]);
            break;
        }
      }
    }

    const { count } = await query;

    return reply.send({ estimated_size: count ?? 0, rules });
  });
}
