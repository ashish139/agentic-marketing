import type { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { z } from 'zod';
import { supabaseAdmin } from '../services/supabaseAdmin.js';

const signupSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  fullName: z.string().min(1),
  orgName: z.string().min(1),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
});

const refreshSchema = z.object({
  refreshToken: z.string(),
});

export async function authRoutes(app: FastifyInstance) {
  // POST /api/auth/signup
  app.post('/signup', async (request: FastifyRequest, reply: FastifyReply) => {
    const parsed = signupSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({
        error: 'Validation Error',
        details: parsed.error.flatten().fieldErrors,
      });
    }

    const { email, password, fullName, orgName } = parsed.data;

    // Create user in Supabase Auth
    const { data: authData, error: authError } = await supabaseAdmin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { full_name: fullName },
    });

    if (authError) {
      return reply.status(400).send({
        error: 'Signup Failed',
        message: authError.message,
      });
    }

    const userId = authData.user.id;

    // Create organization
    const { data: org, error: orgError } = await supabaseAdmin
      .from('organizations')
      .insert({ name: orgName })
      .select('id')
      .single();

    if (orgError) {
      // Rollback: delete the auth user
      await supabaseAdmin.auth.admin.deleteUser(userId);
      return reply.status(500).send({
        error: 'Signup Failed',
        message: 'Failed to create organization',
      });
    }

    // Create org membership
    const { error: memberError } = await supabaseAdmin
      .from('org_members')
      .insert({
        org_id: org.id,
        user_id: userId,
        role: 'owner',
      });

    if (memberError) {
      await supabaseAdmin.from('organizations').delete().eq('id', org.id);
      await supabaseAdmin.auth.admin.deleteUser(userId);
      return reply.status(500).send({
        error: 'Signup Failed',
        message: 'Failed to create organization membership',
      });
    }

    // Sign in the newly created user to get tokens
    const { data: session, error: loginError } = await supabaseAdmin.auth.signInWithPassword({
      email,
      password,
    });

    if (loginError) {
      return reply.status(200).send({
        user: authData.user,
        orgId: org.id,
        message: 'Account created. Please sign in.',
      });
    }

    return reply.status(201).send({
      user: session.user,
      session: {
        accessToken: session.session.access_token,
        refreshToken: session.session.refresh_token,
        expiresAt: session.session.expires_at,
      },
      orgId: org.id,
    });
  });

  // POST /api/auth/login
  app.post('/login', async (request: FastifyRequest, reply: FastifyReply) => {
    const parsed = loginSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({
        error: 'Validation Error',
        details: parsed.error.flatten().fieldErrors,
      });
    }

    const { email, password } = parsed.data;

    const { data, error } = await supabaseAdmin.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      return reply.status(401).send({
        error: 'Login Failed',
        message: error.message,
      });
    }

    // Fetch org membership
    const { data: membership } = await supabaseAdmin
      .from('org_members')
      .select('org_id, role')
      .eq('user_id', data.user.id)
      .limit(1)
      .single();

    return reply.send({
      user: data.user,
      session: {
        accessToken: data.session.access_token,
        refreshToken: data.session.refresh_token,
        expiresAt: data.session.expires_at,
      },
      orgId: membership?.org_id ?? null,
      role: membership?.role ?? null,
    });
  });

  // POST /api/auth/refresh
  app.post('/refresh', async (request: FastifyRequest, reply: FastifyReply) => {
    const parsed = refreshSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({
        error: 'Validation Error',
        details: parsed.error.flatten().fieldErrors,
      });
    }

    const { refreshToken } = parsed.data;

    const { data, error } = await supabaseAdmin.auth.refreshSession({
      refresh_token: refreshToken,
    });

    if (error || !data.session) {
      return reply.status(401).send({
        error: 'Refresh Failed',
        message: error?.message ?? 'Invalid refresh token',
      });
    }

    return reply.send({
      session: {
        accessToken: data.session.access_token,
        refreshToken: data.session.refresh_token,
        expiresAt: data.session.expires_at,
      },
      user: data.user,
    });
  });

  // POST /api/auth/logout
  app.post('/logout', async (request: FastifyRequest, reply: FastifyReply) => {
    const authHeader = request.headers.authorization;
    if (authHeader?.startsWith('Bearer ')) {
      const token = authHeader.slice(7);
      // Get user from token then sign them out
      const { data: { user } } = await supabaseAdmin.auth.getUser(token);
      if (user) {
        await supabaseAdmin.auth.admin.signOut(user.id);
      }
    }

    return reply.send({ message: 'Logged out successfully' });
  });
}
