import type { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { z } from 'zod';
import { supabaseAdmin } from '../services/supabaseAdmin.js';

const createCampaignSchema = z.object({
  name: z.string().min(1).max(255),
  description: z.string().optional(),
  platform: z.enum(['email', 'sms', 'push', 'whatsapp', 'social', 'ads']),
  audience_id: z.string().uuid().optional(),
  scheduled_at: z.string().datetime().optional(),
  content: z.record(z.unknown()).optional(),
  settings: z.record(z.unknown()).optional(),
});

const updateCampaignSchema = z.object({
  name: z.string().min(1).max(255).optional(),
  description: z.string().optional(),
  platform: z.enum(['email', 'sms', 'push', 'whatsapp', 'social', 'ads']).optional(),
  audience_id: z.string().uuid().nullable().optional(),
  status: z.enum(['draft', 'scheduled', 'active', 'paused', 'completed', 'archived']).optional(),
  scheduled_at: z.string().datetime().nullable().optional(),
  content: z.record(z.unknown()).optional(),
  settings: z.record(z.unknown()).optional(),
});

const createCreativeSchema = z.object({
  name: z.string().min(1),
  type: z.enum(['image', 'video', 'text', 'html', 'template']),
  content: z.record(z.unknown()),
  variant_label: z.string().optional(),
});

export async function campaignRoutes(app: FastifyInstance) {
  // GET /api/campaigns — list campaigns with filters
  app.get('/', async (request: FastifyRequest, reply: FastifyReply) => {
    const { orgId } = request.auth;
    const { limit = '20', offset = '0', status, platform, search } = request.query as Record<string, string>;

    let query = supabaseAdmin
      .from('campaigns')
      .select('id, name, description, platform, status, audience_id, scheduled_at, sent_count, open_rate, click_rate, created_at, updated_at', { count: 'exact' })
      .eq('org_id', orgId)
      .order('created_at', { ascending: false })
      .range(Number(offset), Number(offset) + Number(limit) - 1);

    if (status) query = query.eq('status', status);
    if (platform) query = query.eq('platform', platform);
    if (search) query = query.ilike('name', `%${search}%`);

    const { data, error, count } = await query;

    if (error) {
      return reply.status(500).send({ error: 'Failed to fetch campaigns', message: error.message });
    }

    return reply.send({ data, total: count, limit: Number(limit), offset: Number(offset) });
  });

  // GET /api/campaigns/:id — get campaign with creatives
  app.get('/:id', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };
    const { orgId } = request.auth;

    const { data: campaign, error } = await supabaseAdmin
      .from('campaigns')
      .select('*')
      .eq('id', id)
      .eq('org_id', orgId)
      .single();

    if (error || !campaign) {
      return reply.status(404).send({ error: 'Campaign not found' });
    }

    const { data: creatives } = await supabaseAdmin
      .from('campaign_creatives')
      .select('*')
      .eq('campaign_id', id)
      .order('created_at', { ascending: true });

    return reply.send({ ...campaign, creatives: creatives ?? [] });
  });

  // POST /api/campaigns — create campaign
  app.post('/', async (request: FastifyRequest, reply: FastifyReply) => {
    const parsed = createCampaignSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Validation Error', details: parsed.error.flatten().fieldErrors });
    }

    const { orgId, userId } = request.auth;

    const { data, error } = await supabaseAdmin
      .from('campaigns')
      .insert({
        ...parsed.data,
        org_id: orgId,
        created_by: userId,
        status: 'draft',
      })
      .select()
      .single();

    if (error) {
      return reply.status(500).send({ error: 'Failed to create campaign', message: error.message });
    }

    return reply.status(201).send(data);
  });

  // PATCH /api/campaigns/:id — update campaign
  app.patch('/:id', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };
    const { orgId } = request.auth;

    const parsed = updateCampaignSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Validation Error', details: parsed.error.flatten().fieldErrors });
    }

    const { data, error } = await supabaseAdmin
      .from('campaigns')
      .update({ ...parsed.data, updated_at: new Date().toISOString() })
      .eq('id', id)
      .eq('org_id', orgId)
      .select()
      .single();

    if (error || !data) {
      return reply.status(404).send({ error: 'Campaign not found or update failed' });
    }

    return reply.send(data);
  });

  // GET /api/campaigns/:id/metrics — get metrics for date range
  app.get('/:id/metrics', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };
    const { orgId } = request.auth;
    const { start_date, end_date } = request.query as Record<string, string>;

    // Verify campaign belongs to org
    const { data: campaign, error: campError } = await supabaseAdmin
      .from('campaigns')
      .select('id')
      .eq('id', id)
      .eq('org_id', orgId)
      .single();

    if (campError || !campaign) {
      return reply.status(404).send({ error: 'Campaign not found' });
    }

    let query = supabaseAdmin
      .from('campaign_metrics')
      .select('*')
      .eq('campaign_id', id)
      .order('recorded_at', { ascending: true });

    if (start_date) query = query.gte('recorded_at', start_date);
    if (end_date) query = query.lte('recorded_at', end_date);

    const { data: metrics, error } = await query;

    if (error) {
      return reply.status(500).send({ error: 'Failed to fetch metrics', message: error.message });
    }

    return reply.send({ data: metrics ?? [] });
  });

  // POST /api/campaigns/:id/creatives — add creative to campaign
  app.post('/:id/creatives', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };
    const { orgId } = request.auth;

    // Verify campaign belongs to org
    const { data: campaign, error: campError } = await supabaseAdmin
      .from('campaigns')
      .select('id')
      .eq('id', id)
      .eq('org_id', orgId)
      .single();

    if (campError || !campaign) {
      return reply.status(404).send({ error: 'Campaign not found' });
    }

    const parsed = createCreativeSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Validation Error', details: parsed.error.flatten().fieldErrors });
    }

    const { data, error } = await supabaseAdmin
      .from('campaign_creatives')
      .insert({
        ...parsed.data,
        campaign_id: id,
      })
      .select()
      .single();

    if (error) {
      return reply.status(500).send({ error: 'Failed to add creative', message: error.message });
    }

    return reply.status(201).send(data);
  });
}
