import type { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { z } from 'zod';
import { config } from '../config.js';
import { supabaseAdmin } from '../services/supabaseAdmin.js';

const createConnectorSchema = z.object({
  name: z.string().min(1).max(255),
  type: z.enum(['email', 'sms', 'push', 'whatsapp', 'social', 'ads', 'crm', 'cdp', 'analytics', 'webhook']),
  provider: z.string().min(1),
  config: z.record(z.unknown()).optional(),
  is_mock: z.boolean().default(true),
});

const updateConnectorSchema = z.object({
  name: z.string().min(1).max(255).optional(),
  config: z.record(z.unknown()).optional(),
  is_mock: z.boolean().optional(),
  status: z.enum(['active', 'inactive', 'error']).optional(),
});

export async function connectorRoutes(app: FastifyInstance) {
  // GET /api/connectors — list connectors for org
  app.get('/', async (request: FastifyRequest, reply: FastifyReply) => {
    const { orgId } = request.auth;

    const { data, error } = await supabaseAdmin
      .from('connectors')
      .select('id, name, type, provider, status, is_mock, created_at, updated_at')
      .eq('org_id', orgId)
      .order('created_at', { ascending: false });

    if (error) {
      return reply.status(500).send({ error: 'Failed to fetch connectors', message: error.message });
    }

    return reply.send({ data: data ?? [] });
  });

  // POST /api/connectors — create connector
  app.post('/', async (request: FastifyRequest, reply: FastifyReply) => {
    const parsed = createConnectorSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Validation Error', details: parsed.error.flatten().fieldErrors });
    }

    const { orgId, userId } = request.auth;

    const { data, error } = await supabaseAdmin
      .from('connectors')
      .insert({
        ...parsed.data,
        org_id: orgId,
        created_by: userId,
        status: 'active',
      })
      .select()
      .single();

    if (error) {
      return reply.status(500).send({ error: 'Failed to create connector', message: error.message });
    }

    return reply.status(201).send(data);
  });

  // PATCH /api/connectors/:id — update connector
  app.patch('/:id', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };
    const { orgId } = request.auth;

    const parsed = updateConnectorSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Validation Error', details: parsed.error.flatten().fieldErrors });
    }

    const { data, error } = await supabaseAdmin
      .from('connectors')
      .update({ ...parsed.data, updated_at: new Date().toISOString() })
      .eq('id', id)
      .eq('org_id', orgId)
      .select()
      .single();

    if (error || !data) {
      return reply.status(404).send({ error: 'Connector not found or update failed' });
    }

    return reply.send(data);
  });

  // POST /api/connectors/:id/test — test connection
  app.post('/:id/test', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };
    const { orgId } = request.auth;

    // Fetch connector
    const { data: connector, error } = await supabaseAdmin
      .from('connectors')
      .select('*')
      .eq('id', id)
      .eq('org_id', orgId)
      .single();

    if (error || !connector) {
      return reply.status(404).send({ error: 'Connector not found' });
    }

    try {
      // Proxy test request to agent service
      const response = await fetch(`${config.agentServiceUrl}/connectors/test`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          org_id: orgId,
          connector_id: id,
          type: connector.type,
          provider: connector.provider,
          config: connector.config,
          is_mock: connector.is_mock,
        }),
      });

      if (!response.ok) {
        const errBody = await response.json().catch(() => ({}));
        // Update connector status to error
        await supabaseAdmin
          .from('connectors')
          .update({ status: 'error', updated_at: new Date().toISOString() })
          .eq('id', id);

        return reply.status(response.status).send({
          error: 'Connection test failed',
          details: errBody,
        });
      }

      const result = await response.json();

      // Update connector status to active
      await supabaseAdmin
        .from('connectors')
        .update({ status: 'active', updated_at: new Date().toISOString() })
        .eq('id', id);

      return reply.send({ success: true, result });
    } catch (err) {
      request.log.error(err, 'Connector test error');

      await supabaseAdmin
        .from('connectors')
        .update({ status: 'error', updated_at: new Date().toISOString() })
        .eq('id', id);

      return reply.status(502).send({
        error: 'Connection test failed',
        message: 'Agent service unavailable',
      });
    }
  });

  // DELETE /api/connectors/:id — delete connector
  app.delete('/:id', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };
    const { orgId } = request.auth;

    const { data, error } = await supabaseAdmin
      .from('connectors')
      .delete()
      .eq('id', id)
      .eq('org_id', orgId)
      .select('id')
      .single();

    if (error || !data) {
      return reply.status(404).send({ error: 'Connector not found' });
    }

    return reply.send({ message: 'Connector deleted', id: data.id });
  });
}
