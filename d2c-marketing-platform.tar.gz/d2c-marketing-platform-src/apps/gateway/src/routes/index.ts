import type { FastifyInstance } from 'fastify';
import { authMiddleware } from '../middleware/auth.js';
import { authRoutes } from './auth.routes.js';
import { agentRoutes } from './agent.routes.js';
import { audienceRoutes } from './audiences.routes.js';
import { campaignRoutes } from './campaigns.routes.js';
import { journeyRoutes } from './journeys.routes.js';
import { analyticsRoutes } from './analytics.routes.js';
import { approvalRoutes } from './approvals.routes.js';
import { connectorRoutes } from './connectors.routes.js';

export async function registerRoutes(app: FastifyInstance) {
  // Health check - no auth required
  app.get('/health', async () => ({ status: 'ok', timestamp: new Date().toISOString() }));

  // Auth routes - no auth required
  app.register(authRoutes, { prefix: '/api/auth' });

  // All routes below require authentication
  app.register(async (authedApp) => {
    authedApp.addHook('preHandler', authMiddleware);
    authedApp.register(agentRoutes, { prefix: '/api/agent' });
    authedApp.register(audienceRoutes, { prefix: '/api/audiences' });
    authedApp.register(campaignRoutes, { prefix: '/api/campaigns' });
    authedApp.register(journeyRoutes, { prefix: '/api/journeys' });
    authedApp.register(analyticsRoutes, { prefix: '/api/analytics' });
    authedApp.register(approvalRoutes, { prefix: '/api/approvals' });
    authedApp.register(connectorRoutes, { prefix: '/api/connectors' });
  });
}
