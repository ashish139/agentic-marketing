import type { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify';
import { z } from 'zod';
import { supabaseAdmin } from '../services/supabaseAdmin.js';

const createJourneySchema = z.object({
  name: z.string().min(1).max(255),
  description: z.string().optional(),
  trigger_type: z.enum(['event', 'segment_entry', 'segment_exit', 'scheduled', 'manual']).optional(),
  trigger_config: z.record(z.unknown()).optional(),
  audience_id: z.string().uuid().optional(),
});

const updateJourneySchema = z.object({
  name: z.string().min(1).max(255).optional(),
  description: z.string().optional(),
  status: z.enum(['draft', 'active', 'paused', 'archived']).optional(),
  trigger_type: z.enum(['event', 'segment_entry', 'segment_exit', 'scheduled', 'manual']).optional(),
  trigger_config: z.record(z.unknown()).optional(),
  audience_id: z.string().uuid().nullable().optional(),
});

const createStepSchema = z.object({
  name: z.string().min(1),
  type: z.enum(['action', 'condition', 'delay', 'split', 'end']),
  config: z.record(z.unknown()).optional(),
  position_x: z.number().optional(),
  position_y: z.number().optional(),
});

const updateStepSchema = z.object({
  name: z.string().min(1).optional(),
  type: z.enum(['action', 'condition', 'delay', 'split', 'end']).optional(),
  config: z.record(z.unknown()).optional(),
  position_x: z.number().optional(),
  position_y: z.number().optional(),
});

const createEdgeSchema = z.object({
  source_step_id: z.string().uuid(),
  target_step_id: z.string().uuid(),
  condition_label: z.string().optional(),
  condition_config: z.record(z.unknown()).optional(),
});

export async function journeyRoutes(app: FastifyInstance) {
  // GET /api/journeys — list journeys
  app.get('/', async (request: FastifyRequest, reply: FastifyReply) => {
    const { orgId } = request.auth;
    const { limit = '20', offset = '0', status, search } = request.query as Record<string, string>;

    let query = supabaseAdmin
      .from('journeys')
      .select('id, name, description, status, trigger_type, audience_id, created_at, updated_at', { count: 'exact' })
      .eq('org_id', orgId)
      .order('created_at', { ascending: false })
      .range(Number(offset), Number(offset) + Number(limit) - 1);

    if (status) query = query.eq('status', status);
    if (search) query = query.ilike('name', `%${search}%`);

    const { data, error, count } = await query;

    if (error) {
      return reply.status(500).send({ error: 'Failed to fetch journeys', message: error.message });
    }

    return reply.send({ data, total: count, limit: Number(limit), offset: Number(offset) });
  });

  // GET /api/journeys/:id — get journey with steps and edges
  app.get('/:id', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };
    const { orgId } = request.auth;

    const { data: journey, error } = await supabaseAdmin
      .from('journeys')
      .select('*')
      .eq('id', id)
      .eq('org_id', orgId)
      .single();

    if (error || !journey) {
      return reply.status(404).send({ error: 'Journey not found' });
    }

    const [stepsResult, edgesResult] = await Promise.all([
      supabaseAdmin
        .from('journey_steps')
        .select('*')
        .eq('journey_id', id)
        .order('created_at', { ascending: true }),
      supabaseAdmin
        .from('journey_edges')
        .select('*')
        .eq('journey_id', id)
        .order('created_at', { ascending: true }),
    ]);

    return reply.send({
      ...journey,
      steps: stepsResult.data ?? [],
      edges: edgesResult.data ?? [],
    });
  });

  // POST /api/journeys — create journey
  app.post('/', async (request: FastifyRequest, reply: FastifyReply) => {
    const parsed = createJourneySchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Validation Error', details: parsed.error.flatten().fieldErrors });
    }

    const { orgId, userId } = request.auth;

    const { data, error } = await supabaseAdmin
      .from('journeys')
      .insert({
        ...parsed.data,
        org_id: orgId,
        created_by: userId,
        status: 'draft',
      })
      .select()
      .single();

    if (error) {
      return reply.status(500).send({ error: 'Failed to create journey', message: error.message });
    }

    return reply.status(201).send(data);
  });

  // PATCH /api/journeys/:id — update journey
  app.patch('/:id', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };
    const { orgId } = request.auth;

    const parsed = updateJourneySchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Validation Error', details: parsed.error.flatten().fieldErrors });
    }

    const { data, error } = await supabaseAdmin
      .from('journeys')
      .update({ ...parsed.data, updated_at: new Date().toISOString() })
      .eq('id', id)
      .eq('org_id', orgId)
      .select()
      .single();

    if (error || !data) {
      return reply.status(404).send({ error: 'Journey not found or update failed' });
    }

    return reply.send(data);
  });

  // POST /api/journeys/:id/steps — add step
  app.post('/:id/steps', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };
    const { orgId } = request.auth;

    // Verify journey belongs to org
    const { data: journey, error: journeyError } = await supabaseAdmin
      .from('journeys')
      .select('id')
      .eq('id', id)
      .eq('org_id', orgId)
      .single();

    if (journeyError || !journey) {
      return reply.status(404).send({ error: 'Journey not found' });
    }

    const parsed = createStepSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Validation Error', details: parsed.error.flatten().fieldErrors });
    }

    const { data, error } = await supabaseAdmin
      .from('journey_steps')
      .insert({
        ...parsed.data,
        journey_id: id,
      })
      .select()
      .single();

    if (error) {
      return reply.status(500).send({ error: 'Failed to add step', message: error.message });
    }

    return reply.status(201).send(data);
  });

  // PATCH /api/journeys/:id/steps/:stepId — update step
  app.patch('/:id/steps/:stepId', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id, stepId } = request.params as { id: string; stepId: string };
    const { orgId } = request.auth;

    // Verify journey belongs to org
    const { data: journey, error: journeyError } = await supabaseAdmin
      .from('journeys')
      .select('id')
      .eq('id', id)
      .eq('org_id', orgId)
      .single();

    if (journeyError || !journey) {
      return reply.status(404).send({ error: 'Journey not found' });
    }

    const parsed = updateStepSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Validation Error', details: parsed.error.flatten().fieldErrors });
    }

    const { data, error } = await supabaseAdmin
      .from('journey_steps')
      .update({ ...parsed.data, updated_at: new Date().toISOString() })
      .eq('id', stepId)
      .eq('journey_id', id)
      .select()
      .single();

    if (error || !data) {
      return reply.status(404).send({ error: 'Step not found or update failed' });
    }

    return reply.send(data);
  });

  // POST /api/journeys/:id/edges — add edge
  app.post('/:id/edges', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };
    const { orgId } = request.auth;

    // Verify journey belongs to org
    const { data: journey, error: journeyError } = await supabaseAdmin
      .from('journeys')
      .select('id')
      .eq('id', id)
      .eq('org_id', orgId)
      .single();

    if (journeyError || !journey) {
      return reply.status(404).send({ error: 'Journey not found' });
    }

    const parsed = createEdgeSchema.safeParse(request.body);
    if (!parsed.success) {
      return reply.status(400).send({ error: 'Validation Error', details: parsed.error.flatten().fieldErrors });
    }

    const { data, error } = await supabaseAdmin
      .from('journey_edges')
      .insert({
        ...parsed.data,
        journey_id: id,
      })
      .select()
      .single();

    if (error) {
      return reply.status(500).send({ error: 'Failed to add edge', message: error.message });
    }

    return reply.status(201).send(data);
  });

  // POST /api/journeys/:id/activate — activate journey
  app.post('/:id/activate', async (request: FastifyRequest, reply: FastifyReply) => {
    const { id } = request.params as { id: string };
    const { orgId, userId } = request.auth;

    const { data: journey, error: journeyError } = await supabaseAdmin
      .from('journeys')
      .select('id, status, name')
      .eq('id', id)
      .eq('org_id', orgId)
      .single();

    if (journeyError || !journey) {
      return reply.status(404).send({ error: 'Journey not found' });
    }

    if (journey.status === 'active') {
      return reply.status(400).send({ error: 'Journey is already active' });
    }

    // Check if there is a pending approval
    const { data: existingApproval } = await supabaseAdmin
      .from('approvals')
      .select('id, status')
      .eq('entity_type', 'journey')
      .eq('entity_id', id)
      .eq('status', 'approved')
      .single();

    if (!existingApproval) {
      // Create approval request
      const { data: approval, error: approvalError } = await supabaseAdmin
        .from('approvals')
        .insert({
          org_id: orgId,
          entity_type: 'journey',
          entity_id: id,
          entity_name: journey.name,
          requested_by: userId,
          status: 'pending',
        })
        .select()
        .single();

      if (approvalError) {
        return reply.status(500).send({ error: 'Failed to create approval', message: approvalError.message });
      }

      return reply.send({
        message: 'Approval required before activation',
        approval,
      });
    }

    // Activate journey
    const { data: updated, error: updateError } = await supabaseAdmin
      .from('journeys')
      .update({ status: 'active', updated_at: new Date().toISOString() })
      .eq('id', id)
      .eq('org_id', orgId)
      .select()
      .single();

    if (updateError) {
      return reply.status(500).send({ error: 'Failed to activate journey', message: updateError.message });
    }

    return reply.send({ message: 'Journey activated', journey: updated });
  });
}
