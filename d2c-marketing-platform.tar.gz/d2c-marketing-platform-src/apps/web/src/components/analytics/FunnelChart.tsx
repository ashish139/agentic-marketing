import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell,
} from 'recharts';

const funnelData = [
  { stage: 'Visitors', count: 45000, fill: '#6366f1' },
  { stage: 'Product Views', count: 28000, fill: '#818cf8' },
  { stage: 'Add to Cart', count: 12000, fill: '#a5b4fc' },
  { stage: 'Checkout', count: 6500, fill: '#c7d2fe' },
  { stage: 'Purchase', count: 3200, fill: '#4f46e5' },
];

export function FunnelChart() {
  return (
    <div>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={funnelData} layout="vertical" barCategoryGap="20%">
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" horizontal={false} />
          <XAxis
            type="number"
            tick={{ fontSize: 12, fill: '#94a3b8' }}
            axisLine={{ stroke: '#e2e8f0' }}
          />
          <YAxis
            type="category"
            dataKey="stage"
            tick={{ fontSize: 12, fill: '#64748b' }}
            axisLine={{ stroke: '#e2e8f0' }}
            width={100}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: '#fff',
              border: '1px solid #e2e8f0',
              borderRadius: '8px',
              fontSize: '12px',
            }}
            formatter={(value: number) => [value.toLocaleString(), 'Users']}
          />
          <Bar dataKey="count" radius={[0, 4, 4, 0]}>
            {funnelData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.fill} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
      <div className="flex items-center justify-center gap-6 mt-4">
        {funnelData.map((item, i) => {
          if (i === 0) return null;
          const prev = funnelData[i - 1];
          const rate = prev ? ((item.count / prev.count) * 100).toFixed(1) : '0';
          return (
            <div key={item.stage} className="text-center">
              <p className="text-xs text-slate-400">
                {prev?.stage} &rarr; {item.stage}
              </p>
              <p className="text-sm font-semibold text-slate-700">{rate}%</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
