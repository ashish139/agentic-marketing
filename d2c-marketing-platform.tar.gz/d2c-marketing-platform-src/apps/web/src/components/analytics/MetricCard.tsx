import { TrendingUp, TrendingDown } from 'lucide-react';

interface MetricCardProps {
  label: string;
  value: string;
  change: number;
  icon?: React.ReactNode;
}

export function MetricCard({ label, value, change, icon }: MetricCardProps) {
  const isPositive = change >= 0;

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-5 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between">
        <p className="text-sm font-medium text-slate-500">{label}</p>
        {icon && (
          <div className="p-2 rounded-lg bg-brand-50 text-brand-600">
            {icon}
          </div>
        )}
      </div>
      <p className="text-2xl font-bold text-slate-900 mt-2">{value}</p>
      <div className="mt-2 flex items-center gap-1.5">
        {isPositive ? (
          <TrendingUp className="w-4 h-4 text-emerald-500" />
        ) : (
          <TrendingDown className="w-4 h-4 text-red-500" />
        )}
        <span
          className={`text-sm font-medium ${isPositive ? 'text-emerald-600' : 'text-red-600'}`}
        >
          {isPositive ? '+' : ''}
          {change}%
        </span>
        <span className="text-xs text-slate-400">vs prior period</span>
      </div>
    </div>
  );
}
