import { useState } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import clsx from 'clsx';

const mockData = [
  { date: 'Apr 1', impressions: 12000, clicks: 840, conversions: 42, spend: 180, revenue: 756 },
  { date: 'Apr 3', impressions: 14500, clicks: 1015, conversions: 51, spend: 210, revenue: 918 },
  { date: 'Apr 5', impressions: 11800, clicks: 826, conversions: 37, spend: 175, revenue: 666 },
  { date: 'Apr 7', impressions: 16200, clicks: 1134, conversions: 62, spend: 245, revenue: 1116 },
  { date: 'Apr 9', impressions: 15000, clicks: 1050, conversions: 55, spend: 230, revenue: 990 },
  { date: 'Apr 11', impressions: 18300, clicks: 1281, conversions: 71, spend: 280, revenue: 1278 },
  { date: 'Apr 13', impressions: 17100, clicks: 1197, conversions: 68, spend: 265, revenue: 1224 },
  { date: 'Apr 15', impressions: 19500, clicks: 1365, conversions: 78, spend: 300, revenue: 1404 },
];

type Metric = 'impressions' | 'clicks' | 'conversions' | 'spend' | 'revenue';

const metricConfig: Record<Metric, { color: string; label: string }> = {
  impressions: { color: '#6366f1', label: 'Impressions' },
  clicks: { color: '#0ea5e9', label: 'Clicks' },
  conversions: { color: '#10b981', label: 'Conversions' },
  spend: { color: '#f59e0b', label: 'Spend ($)' },
  revenue: { color: '#8b5cf6', label: 'Revenue ($)' },
};

export function PerformanceChart() {
  const [activeMetrics, setActiveMetrics] = useState<Metric[]>([
    'impressions',
    'clicks',
    'conversions',
  ]);

  function toggleMetric(metric: Metric) {
    setActiveMetrics((prev) =>
      prev.includes(metric)
        ? prev.filter((m) => m !== metric)
        : [...prev, metric],
    );
  }

  return (
    <div>
      <div className="flex flex-wrap gap-2 mb-4">
        {(Object.entries(metricConfig) as [Metric, { color: string; label: string }][]).map(
          ([key, { color, label }]) => (
            <button
              key={key}
              onClick={() => toggleMetric(key)}
              className={clsx(
                'px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors',
                activeMetrics.includes(key)
                  ? 'border-transparent text-white'
                  : 'border-slate-200 text-slate-500 bg-white hover:bg-slate-50',
              )}
              style={
                activeMetrics.includes(key)
                  ? { backgroundColor: color }
                  : undefined
              }
            >
              {label}
            </button>
          ),
        )}
      </div>
      <ResponsiveContainer width="100%" height={320}>
        <LineChart data={mockData}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
          <XAxis
            dataKey="date"
            tick={{ fontSize: 12, fill: '#94a3b8' }}
            axisLine={{ stroke: '#e2e8f0' }}
          />
          <YAxis
            tick={{ fontSize: 12, fill: '#94a3b8' }}
            axisLine={{ stroke: '#e2e8f0' }}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: '#fff',
              border: '1px solid #e2e8f0',
              borderRadius: '8px',
              fontSize: '12px',
            }}
          />
          <Legend />
          {activeMetrics.map((metric) => (
            <Line
              key={metric}
              type="monotone"
              dataKey={metric}
              stroke={metricConfig[metric].color}
              strokeWidth={2}
              dot={{ r: 3 }}
              name={metricConfig[metric].label}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
