import clsx from 'clsx';

const agentColors: Record<string, { bg: string; text: string }> = {
  'Audience Agent': { bg: 'bg-purple-100', text: 'text-purple-700' },
  'Campaign Agent': { bg: 'bg-blue-100', text: 'text-blue-700' },
  'Journey Agent': { bg: 'bg-emerald-100', text: 'text-emerald-700' },
  'Analytics Agent': { bg: 'bg-amber-100', text: 'text-amber-700' },
  'Orchestrator': { bg: 'bg-brand-100', text: 'text-brand-700' },
};

const defaultColor = { bg: 'bg-slate-100', text: 'text-slate-700' };

interface AgentBadgeProps {
  agent: string;
  size?: 'sm' | 'md';
}

export function AgentBadge({ agent, size = 'sm' }: AgentBadgeProps) {
  const color = agentColors[agent] ?? defaultColor;

  return (
    <span
      className={clsx(
        'inline-flex items-center font-medium rounded-full',
        color.bg,
        color.text,
        size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-3 py-1 text-sm',
      )}
    >
      {agent}
    </span>
  );
}
