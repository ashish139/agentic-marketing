import type { ApprovalRequest } from '@/hooks/useAgent';
import { ShieldCheck, ShieldX, ChevronDown, ChevronUp } from 'lucide-react';
import { useState } from 'react';
import clsx from 'clsx';

interface ApprovalCardProps {
  approval: ApprovalRequest;
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
}

export function ApprovalCard({
  approval,
  onApprove,
  onReject,
}: ApprovalCardProps) {
  const [expanded, setExpanded] = useState(false);
  const isPending = approval.status === 'pending';

  return (
    <div
      className={clsx(
        'rounded-xl border-2 p-4 transition-colors',
        approval.status === 'approved' && 'border-emerald-200 bg-emerald-50',
        approval.status === 'rejected' && 'border-red-200 bg-red-50',
        approval.status === 'pending' && 'border-amber-200 bg-amber-50',
      )}
    >
      <div className="flex items-start gap-3">
        <div
          className={clsx(
            'p-1.5 rounded-lg',
            isPending ? 'bg-amber-200 text-amber-700' : 'bg-slate-200 text-slate-600',
          )}
        >
          <ShieldCheck className="w-4 h-4" />
        </div>
        <div className="flex-1 min-w-0">
          <h4 className="text-sm font-semibold text-slate-900">
            {approval.title}
          </h4>
          <p className="text-xs text-slate-600 mt-0.5">
            {approval.description}
          </p>

          {/* Payload diff view */}
          <button
            onClick={() => setExpanded(!expanded)}
            className="flex items-center gap-1 mt-2 text-xs text-slate-500 hover:text-slate-700 transition-colors"
          >
            {expanded ? (
              <ChevronUp className="w-3 h-3" />
            ) : (
              <ChevronDown className="w-3 h-3" />
            )}
            {expanded ? 'Hide' : 'View'} payload
          </button>

          {expanded && (
            <pre className="mt-2 p-3 bg-slate-900 text-slate-100 rounded-lg text-xs overflow-x-auto font-mono">
              {JSON.stringify(approval.payload, null, 2)}
            </pre>
          )}

          {/* Action buttons */}
          {isPending && (
            <div className="flex gap-2 mt-3">
              <button
                onClick={() => onApprove(approval.id)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-medium hover:bg-emerald-700 transition-colors"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                Approve
              </button>
              <button
                onClick={() => onReject(approval.id)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-600 text-white text-xs font-medium hover:bg-red-700 transition-colors"
              >
                <ShieldX className="w-3.5 h-3.5" />
                Reject
              </button>
            </div>
          )}

          {approval.status === 'approved' && (
            <p className="mt-2 text-xs font-medium text-emerald-700">
              Approved
            </p>
          )}
          {approval.status === 'rejected' && (
            <p className="mt-2 text-xs font-medium text-red-700">Rejected</p>
          )}
        </div>
      </div>
    </div>
  );
}
