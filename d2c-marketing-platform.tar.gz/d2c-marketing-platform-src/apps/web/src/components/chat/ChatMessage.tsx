import type { ChatMessage as ChatMessageType } from '@/hooks/useAgent';
import { AgentBadge } from './AgentBadge';
import { Bot, User, Loader2, CheckCircle2, XCircle } from 'lucide-react';
import clsx from 'clsx';

interface ChatMessageProps {
  message: ChatMessageType;
}

export function ChatMessage({ message }: ChatMessageProps) {
  const isUser = message.role === 'user';

  return (
    <div className={clsx('flex gap-3', isUser && 'justify-end')}>
      {!isUser && (
        <div className="w-8 h-8 rounded-lg bg-brand-100 text-brand-600 flex items-center justify-center shrink-0">
          <Bot className="w-4 h-4" />
        </div>
      )}
      <div
        className={clsx(
          'max-w-[70%] space-y-2',
          isUser && 'order-first',
        )}
      >
        {!isUser && message.agent && (
          <AgentBadge agent={message.agent} />
        )}
        <div
          className={clsx(
            'px-4 py-3 rounded-2xl text-sm leading-relaxed',
            isUser
              ? 'bg-brand-600 text-white rounded-br-md'
              : 'bg-slate-100 text-slate-800 rounded-bl-md',
          )}
        >
          <p className="whitespace-pre-wrap">{message.content}</p>
        </div>

        {/* Tool call indicators */}
        {message.toolCalls && message.toolCalls.length > 0 && (
          <div className="space-y-1">
            {message.toolCalls.map((tc) => (
              <div
                key={tc.id}
                className="flex items-center gap-2 text-xs text-slate-500"
              >
                {tc.status === 'running' && (
                  <Loader2 className="w-3 h-3 animate-spin text-brand-500" />
                )}
                {tc.status === 'completed' && (
                  <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                )}
                {tc.status === 'failed' && (
                  <XCircle className="w-3 h-3 text-red-500" />
                )}
                <span className="font-mono">{tc.name}</span>
              </div>
            ))}
          </div>
        )}
      </div>
      {isUser && (
        <div className="w-8 h-8 rounded-lg bg-slate-200 text-slate-600 flex items-center justify-center shrink-0">
          <User className="w-4 h-4" />
        </div>
      )}
    </div>
  );
}
