import { useEffect, useRef } from 'react';
import type { ChatMessage as ChatMessageType } from '@/hooks/useAgent';
import { ChatMessage } from './ChatMessage';
import { ApprovalCard } from './ApprovalCard';
import { MessageSquare } from 'lucide-react';

interface ChatWindowProps {
  messages: ChatMessageType[];
  isStreaming: boolean;
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
}

export function ChatWindow({
  messages,
  isStreaming,
  onApprove,
  onReject,
}: ChatWindowProps) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isStreaming]);

  if (messages.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center max-w-md">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-brand-50 text-brand-600 mb-4">
            <MessageSquare className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-semibold text-slate-900">
            Start a conversation
          </h3>
          <p className="text-sm text-slate-500 mt-2">
            Ask the AI to create audiences, launch campaigns, build customer
            journeys, or analyze your marketing data.
          </p>
          <div className="mt-6 flex flex-wrap gap-2 justify-center">
            {[
              'Create a high-value customer segment',
              'Launch a retargeting campaign',
              'Build an onboarding email flow',
              'Show me this month\'s ROAS',
            ].map((suggestion) => (
              <button
                key={suggestion}
                className="px-3 py-1.5 rounded-full bg-slate-100 text-sm text-slate-600 hover:bg-brand-50 hover:text-brand-700 transition-colors"
              >
                {suggestion}
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto px-4 py-6 space-y-4">
      {messages.map((message) => (
        <div key={message.id}>
          <ChatMessage message={message} />
          {message.approval && (
            <div className="ml-10 mt-2">
              <ApprovalCard
                approval={message.approval}
                onApprove={onApprove}
                onReject={onReject}
              />
            </div>
          )}
        </div>
      ))}
      {isStreaming && (
        <div className="flex items-center gap-2 text-sm text-slate-400 ml-10">
          <div className="flex gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-brand-400 animate-bounce" />
            <div
              className="w-1.5 h-1.5 rounded-full bg-brand-400 animate-bounce"
              style={{ animationDelay: '0.15s' }}
            />
            <div
              className="w-1.5 h-1.5 rounded-full bg-brand-400 animate-bounce"
              style={{ animationDelay: '0.3s' }}
            />
          </div>
        </div>
      )}
      <div ref={bottomRef} />
    </div>
  );
}
