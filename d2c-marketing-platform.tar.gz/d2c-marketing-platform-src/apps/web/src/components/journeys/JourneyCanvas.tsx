import { useCallback } from 'react';
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  useNodesState,
  useEdgesState,
  addEdge,
  type Connection,
  type Node,
  type Edge,
  type NodeTypes,
  Handle,
  Position,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { Mail, MessageSquare, Clock, GitBranch, Split } from 'lucide-react';

/* --- Custom Node Components --- */

function EmailNode({ data }: { data: { label: string; subject?: string } }) {
  return (
    <div className="bg-white border-2 border-blue-300 rounded-xl p-4 min-w-[180px] shadow-sm">
      <Handle type="target" position={Position.Top} className="!bg-blue-500" />
      <div className="flex items-center gap-2 mb-1">
        <Mail className="w-4 h-4 text-blue-500" />
        <span className="text-xs font-semibold text-blue-600 uppercase">
          Email
        </span>
      </div>
      <p className="text-sm font-medium text-slate-800">{data.label}</p>
      {data.subject && (
        <p className="text-xs text-slate-400 mt-1">{data.subject}</p>
      )}
      <Handle type="source" position={Position.Bottom} className="!bg-blue-500" />
    </div>
  );
}

function SMSNode({ data }: { data: { label: string } }) {
  return (
    <div className="bg-white border-2 border-emerald-300 rounded-xl p-4 min-w-[180px] shadow-sm">
      <Handle type="target" position={Position.Top} className="!bg-emerald-500" />
      <div className="flex items-center gap-2 mb-1">
        <MessageSquare className="w-4 h-4 text-emerald-500" />
        <span className="text-xs font-semibold text-emerald-600 uppercase">
          SMS
        </span>
      </div>
      <p className="text-sm font-medium text-slate-800">{data.label}</p>
      <Handle type="source" position={Position.Bottom} className="!bg-emerald-500" />
    </div>
  );
}

function WaitNode({ data }: { data: { label: string; duration?: string } }) {
  return (
    <div className="bg-white border-2 border-amber-300 rounded-xl p-4 min-w-[160px] shadow-sm">
      <Handle type="target" position={Position.Top} className="!bg-amber-500" />
      <div className="flex items-center gap-2 mb-1">
        <Clock className="w-4 h-4 text-amber-500" />
        <span className="text-xs font-semibold text-amber-600 uppercase">
          Wait
        </span>
      </div>
      <p className="text-sm font-medium text-slate-800">{data.label}</p>
      {data.duration && (
        <p className="text-xs text-slate-400 mt-1">{data.duration}</p>
      )}
      <Handle type="source" position={Position.Bottom} className="!bg-amber-500" />
    </div>
  );
}

function ConditionNode({ data }: { data: { label: string; condition?: string } }) {
  return (
    <div className="bg-white border-2 border-purple-300 rounded-xl p-4 min-w-[180px] shadow-sm">
      <Handle type="target" position={Position.Top} className="!bg-purple-500" />
      <div className="flex items-center gap-2 mb-1">
        <GitBranch className="w-4 h-4 text-purple-500" />
        <span className="text-xs font-semibold text-purple-600 uppercase">
          Condition
        </span>
      </div>
      <p className="text-sm font-medium text-slate-800">{data.label}</p>
      {data.condition && (
        <p className="text-xs text-slate-400 mt-1">{data.condition}</p>
      )}
      <Handle type="source" position={Position.Bottom} id="yes" className="!bg-emerald-500 !left-[30%]" />
      <Handle type="source" position={Position.Bottom} id="no" className="!bg-red-500 !left-[70%]" />
    </div>
  );
}

function SplitNode({ data }: { data: { label: string } }) {
  return (
    <div className="bg-white border-2 border-orange-300 rounded-xl p-4 min-w-[160px] shadow-sm">
      <Handle type="target" position={Position.Top} className="!bg-orange-500" />
      <div className="flex items-center gap-2 mb-1">
        <Split className="w-4 h-4 text-orange-500" />
        <span className="text-xs font-semibold text-orange-600 uppercase">
          A/B Split
        </span>
      </div>
      <p className="text-sm font-medium text-slate-800">{data.label}</p>
      <Handle type="source" position={Position.Bottom} id="a" className="!bg-orange-500 !left-[30%]" />
      <Handle type="source" position={Position.Bottom} id="b" className="!bg-orange-500 !left-[70%]" />
    </div>
  );
}

const nodeTypes: NodeTypes = {
  email: EmailNode,
  sms: SMSNode,
  wait: WaitNode,
  condition: ConditionNode,
  split: SplitNode,
};

interface JourneyCanvasProps {
  initialNodes: Node[];
  initialEdges: Edge[];
  onNodeSelect?: (node: Node | null) => void;
}

export function JourneyCanvas({
  initialNodes,
  initialEdges,
  onNodeSelect,
}: JourneyCanvasProps) {
  const [nodes, , onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

  const onConnect = useCallback(
    (params: Connection) => setEdges((eds) => addEdge(params, eds)),
    [setEdges],
  );

  return (
    <ReactFlow
      nodes={nodes}
      edges={edges}
      onNodesChange={onNodesChange}
      onEdgesChange={onEdgesChange}
      onConnect={onConnect}
      onNodeClick={(_, node) => onNodeSelect?.(node)}
      onPaneClick={() => onNodeSelect?.(null)}
      nodeTypes={nodeTypes}
      fitView
      className="bg-slate-50"
    >
      <Background gap={20} size={1} color="#e2e8f0" />
      <Controls className="!bg-white !border-slate-200 !rounded-lg !shadow-sm" />
      <MiniMap
        nodeColor="#6366f1"
        maskColor="rgba(0,0,0,0.08)"
        className="!bg-white !border-slate-200 !rounded-lg"
      />
    </ReactFlow>
  );
}
