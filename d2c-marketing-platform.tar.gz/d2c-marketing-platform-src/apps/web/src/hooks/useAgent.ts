import { useState, useCallback, useRef } from 'react';
import { createSSEStream } from '@/lib/streaming';
import { supabase } from '@/lib/supabase';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  agent?: string;
  toolCalls?: ToolCall[];
  approval?: ApprovalRequest;
  timestamp: Date;
}

export interface ToolCall {
  id: string;
  name: string;
  status: 'running' | 'completed' | 'failed';
}

export interface ApprovalRequest {
  id: string;
  title: string;
  description: string;
  payload: unknown;
  status: 'pending' | 'approved' | 'rejected';
}

export function useAgent(sessionId: string | null) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [activeAgent, setActiveAgent] = useState<string | null>(null);
  const [pendingApproval, setPendingApproval] =
    useState<ApprovalRequest | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const sendMessage = useCallback(
    async (content: string) => {
      const userMessage: ChatMessage = {
        id: crypto.randomUUID(),
        role: 'user',
        content,
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, userMessage]);
      setIsStreaming(true);

      const assistantId = crypto.randomUUID();
      setMessages((prev) => [
        ...prev,
        {
          id: assistantId,
          role: 'assistant',
          content: '',
          timestamp: new Date(),
        },
      ]);

      const abortController = new AbortController();
      abortRef.current = abortController;

      try {
        const {
          data: { session },
        } = await supabase.auth.getSession();
        const token = session?.access_token ?? null;

        const stream = createSSEStream(
          '/api/agent/chat',
          { message: content, sessionId },
          token,
          abortController.signal,
        );

        for await (const event of stream) {
          switch (event.event) {
            case 'token': {
              const { content: tokenContent } = event.data as {
                content: string;
              };
              setMessages((prev) =>
                prev.map((m) =>
                  m.id === assistantId
                    ? { ...m, content: m.content + tokenContent }
                    : m,
                ),
              );
              break;
            }
            case 'agent_switch': {
              const { agent } = event.data as { agent: string };
              setActiveAgent(agent);
              setMessages((prev) =>
                prev.map((m) =>
                  m.id === assistantId ? { ...m, agent } : m,
                ),
              );
              break;
            }
            case 'tool_start': {
              const { id, name } = event.data as { id: string; name: string };
              setMessages((prev) =>
                prev.map((m) =>
                  m.id === assistantId
                    ? {
                        ...m,
                        toolCalls: [
                          ...(m.toolCalls ?? []),
                          { id, name, status: 'running' as const },
                        ],
                      }
                    : m,
                ),
              );
              break;
            }
            case 'tool_end': {
              const { id, status } = event.data as {
                id: string;
                status: 'completed' | 'failed';
              };
              setMessages((prev) =>
                prev.map((m) =>
                  m.id === assistantId
                    ? {
                        ...m,
                        toolCalls: m.toolCalls?.map((tc) =>
                          tc.id === id ? { ...tc, status } : tc,
                        ),
                      }
                    : m,
                ),
              );
              break;
            }
            case 'approval_request': {
              const approval = event.data as ApprovalRequest;
              setPendingApproval(approval);
              setMessages((prev) =>
                prev.map((m) =>
                  m.id === assistantId
                    ? { ...m, approval: { ...approval, status: 'pending' } }
                    : m,
                ),
              );
              break;
            }
            case 'done':
              break;
          }
        }
      } catch (err) {
        if ((err as Error).name !== 'AbortError') {
          setMessages((prev) =>
            prev.map((m) =>
              m.id === assistantId
                ? {
                    ...m,
                    content:
                      m.content ||
                      'Sorry, something went wrong. Please try again.',
                  }
                : m,
            ),
          );
        }
      } finally {
        setIsStreaming(false);
        abortRef.current = null;
      }
    },
    [sessionId],
  );

  const approveAction = useCallback(async (approvalId: string) => {
    try {
      await fetch(`/api/approvals/${approvalId}/approve`, { method: 'POST' });
      setPendingApproval(null);
      setMessages((prev) =>
        prev.map((m) =>
          m.approval?.id === approvalId
            ? { ...m, approval: { ...m.approval, status: 'approved' } }
            : m,
        ),
      );
    } catch (err) {
      console.error('Failed to approve action:', err);
    }
  }, []);

  const rejectAction = useCallback(async (approvalId: string) => {
    try {
      await fetch(`/api/approvals/${approvalId}/reject`, { method: 'POST' });
      setPendingApproval(null);
      setMessages((prev) =>
        prev.map((m) =>
          m.approval?.id === approvalId
            ? { ...m, approval: { ...m.approval, status: 'rejected' } }
            : m,
        ),
      );
    } catch (err) {
      console.error('Failed to reject action:', err);
    }
  }, []);

  const stopStreaming = useCallback(() => {
    abortRef.current?.abort();
  }, []);

  return {
    messages,
    isStreaming,
    activeAgent,
    pendingApproval,
    sendMessage,
    approveAction,
    rejectAction,
    stopStreaming,
  };
}
