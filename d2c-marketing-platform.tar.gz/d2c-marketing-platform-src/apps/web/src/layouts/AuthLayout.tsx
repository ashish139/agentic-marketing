import { Outlet } from 'react-router-dom';

export function AuthLayout() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-brand-50 via-white to-slate-100 px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-brand-600 text-white font-bold text-xl mb-4">
            D
          </div>
          <h1 className="text-2xl font-bold text-slate-900">
            D2C Marketing AI
          </h1>
          <p className="text-slate-500 mt-1">
            Intelligent marketing automation platform
          </p>
        </div>
        <div className="bg-white rounded-2xl shadow-xl shadow-slate-200/50 border border-slate-200 p-8">
          <Outlet />
        </div>
      </div>
    </div>
  );
}
