import { NavLink, useLocation } from 'react-router-dom';
import { useStore } from '@/store';
import {
  LayoutDashboard,
  MessageSquare,
  Users,
  Megaphone,
  GitBranch,
  BarChart3,
  CheckCircle,
  Plug,
  ChevronDown,
  LogOut,
} from 'lucide-react';
import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import clsx from 'clsx';

const navItems = [
  { to: '/', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/chat', icon: MessageSquare, label: 'Chat with AI' },
  { to: '/audiences', icon: Users, label: 'Audiences' },
  { to: '/campaigns', icon: Megaphone, label: 'Campaigns' },
  { to: '/journeys', icon: GitBranch, label: 'Journeys' },
  { to: '/analytics', icon: BarChart3, label: 'Analytics' },
];

export function Sidebar() {
  const sidebarOpen = useStore((s) => s.sidebarOpen);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const { signOut } = useAuth();
  const location = useLocation();
  const pendingApprovals = 3; // TODO: fetch from API

  return (
    <aside
      className={clsx(
        'fixed left-0 top-0 h-screen bg-white border-r border-slate-200 flex flex-col transition-all duration-300 z-20',
        sidebarOpen ? 'w-64' : 'w-16',
      )}
    >
      {/* Logo */}
      <div className="h-14 flex items-center px-4 border-b border-slate-200 shrink-0">
        <div className="w-8 h-8 rounded-lg bg-brand-600 text-white flex items-center justify-center font-bold text-sm shrink-0">
          D
        </div>
        {sidebarOpen && (
          <span className="ml-3 font-semibold text-slate-900 truncate">
            D2C Marketing
          </span>
        )}
      </div>

      {/* Nav links */}
      <nav className="flex-1 py-3 px-2 space-y-1 overflow-y-auto">
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === '/'}
            className={({ isActive }) =>
              clsx(
                'flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors',
                isActive
                  ? 'bg-brand-50 text-brand-700'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900',
              )
            }
          >
            <item.icon className="w-5 h-5 shrink-0" />
            {sidebarOpen && <span className="truncate">{item.label}</span>}
          </NavLink>
        ))}

        {/* Approvals with badge */}
        <NavLink
          to="/approvals"
          className={({ isActive }) =>
            clsx(
              'flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors',
              isActive
                ? 'bg-brand-50 text-brand-700'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900',
            )
          }
        >
          <CheckCircle className="w-5 h-5 shrink-0" />
          {sidebarOpen && (
            <>
              <span className="truncate flex-1">Approvals</span>
              {pendingApprovals > 0 && (
                <span className="bg-red-500 text-white text-xs font-medium rounded-full w-5 h-5 flex items-center justify-center">
                  {pendingApprovals}
                </span>
              )}
            </>
          )}
          {!sidebarOpen && pendingApprovals > 0 && (
            <span className="absolute left-9 top-0 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
              {pendingApprovals}
            </span>
          )}
        </NavLink>

        {/* Settings section */}
        <div>
          <button
            onClick={() => setSettingsOpen(!settingsOpen)}
            className={clsx(
              'w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors text-slate-600 hover:bg-slate-100 hover:text-slate-900',
            )}
          >
            <Plug className="w-5 h-5 shrink-0" />
            {sidebarOpen && (
              <>
                <span className="truncate flex-1 text-left">Settings</span>
                <ChevronDown
                  className={clsx(
                    'w-4 h-4 transition-transform',
                    settingsOpen && 'rotate-180',
                  )}
                />
              </>
            )}
          </button>
          {settingsOpen && sidebarOpen && (
            <NavLink
              to="/settings/connectors"
              className={({ isActive }) =>
                clsx(
                  'flex items-center gap-3 pl-11 pr-3 py-2 rounded-lg text-sm font-medium transition-colors',
                  isActive
                    ? 'bg-brand-50 text-brand-700'
                    : 'text-slate-500 hover:bg-slate-100 hover:text-slate-900',
                )
              }
            >
              Connectors
            </NavLink>
          )}
        </div>
      </nav>

      {/* Sign out */}
      <div className="p-2 border-t border-slate-200">
        <button
          onClick={() => signOut()}
          className={clsx(
            'w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-slate-600 hover:bg-red-50 hover:text-red-600 transition-colors',
          )}
        >
          <LogOut className="w-5 h-5 shrink-0" />
          {sidebarOpen && <span>Sign out</span>}
        </button>
      </div>
    </aside>
  );
}
