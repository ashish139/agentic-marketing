export interface SSEEvent {
  event: string;
  data: unknown;
}

export async function* createSSEStream(
  url: string,
  body: unknown,
  token: string | null,
  signal?: AbortSignal,
): AsyncGenerator<SSEEvent> {
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'text/event-stream',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify(body),
    signal,
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`SSE request failed (${res.status}): ${errText}`);
  }

  const reader = res.body?.getReader();
  if (!reader) throw new Error('No response body');

  const decoder = new TextDecoder();
  let buffer = '';

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() ?? '';

      let currentEvent = 'message';
      let dataLines: string[] = [];

      for (const line of lines) {
        if (line.startsWith('event: ')) {
          currentEvent = line.slice(7).trim();
        } else if (line.startsWith('data: ')) {
          dataLines.push(line.slice(6));
        } else if (line === '') {
          if (dataLines.length > 0) {
            const rawData = dataLines.join('\n');
            let parsed: unknown;
            try {
              parsed = JSON.parse(rawData);
            } catch {
              parsed = rawData;
            }
            yield { event: currentEvent, data: parsed };
            currentEvent = 'message';
            dataLines = [];
          }
        }
      }
    }
  } finally {
    reader.releaseLock();
  }
}
