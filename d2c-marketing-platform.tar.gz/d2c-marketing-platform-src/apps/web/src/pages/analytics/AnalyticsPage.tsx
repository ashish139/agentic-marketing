import { useState } from 'react';
import { DollarSign, Users, ShoppingCart, BarChart3 } from 'lucide-react';
import { MetricCard } from '@/components/analytics/MetricCard';
import { FunnelChart } from '@/components/analytics/FunnelChart';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';

const cohortData = [
  { week: 'Week 0', jan: 100, feb: 100, mar: 100, apr: 100 },
  { week: 'Week 1', jan: 72, feb: 68, mar: 75, apr: 71 },
  { week: 'Week 2', jan: 58, feb: 55, mar: 62, apr: 60 },
  { week: 'Week 3', jan: 48, feb: 44, mar: 52, apr: 50 },
  { week: 'Week 4', jan: 41, feb: 38, mar: 45, apr: 44 },
];

const eventData = [
  { event: 'Page View', count: 125000 },
  { event: 'Product View', count: 45000 },
  { event: 'Add to Cart', count: 12000 },
  { event: 'Checkout Start', count: 6500 },
  { event: 'Purchase', count: 3200 },
  { event: 'Email Open', count: 18500 },
  { event: 'Email Click', count: 4200 },
];

export function AnalyticsPage() {
  const [dateRange, setDateRange] = useState('30d');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Analytics</h1>
          <p className="text-slate-500 mt-1">
            Track performance across your marketing stack
          </p>
        </div>
        <div className="flex items-center gap-2">
          {['7d', '14d', '30d', '90d'].map((range) => (
            <button
              key={range}
              onClick={() => setDateRange(range)}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                dateRange === range
                  ? 'bg-brand-600 text-white'
                  : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
              }`}
            >
              {range}
            </button>
          ))}
        </div>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          label="Revenue"
          value="$142,580"
          change={18.2}
          icon={<DollarSign className="w-5 h-5" />}
        />
        <MetricCard
          label="New Customers"
          value="1,245"
          change={12.5}
          icon={<Users className="w-5 h-5" />}
        />
        <MetricCard
          label="Orders"
          value="3,210"
          change={8.3}
          icon={<ShoppingCart className="w-5 h-5" />}
        />
        <MetricCard
          label="Conversion Rate"
          value="3.2%"
          change={-0.5}
          icon={<BarChart3 className="w-5 h-5" />}
        />
      </div>

      {/* Funnel */}
      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <h2 className="text-lg font-semibold text-slate-900 mb-4">
          Conversion Funnel
        </h2>
        <FunnelChart />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Cohort retention */}
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <h2 className="text-lg font-semibold text-slate-900 mb-4">
            Cohort Retention
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200">
                  <th className="text-left py-2 px-3 text-xs font-medium text-slate-500 uppercase">
                    Period
                  </th>
                  <th className="text-center py-2 px-3 text-xs font-medium text-slate-500 uppercase">
                    Jan
                  </th>
                  <th className="text-center py-2 px-3 text-xs font-medium text-slate-500 uppercase">
                    Feb
                  </th>
                  <th className="text-center py-2 px-3 text-xs font-medium text-slate-500 uppercase">
                    Mar
                  </th>
                  <th className="text-center py-2 px-3 text-xs font-medium text-slate-500 uppercase">
                    Apr
                  </th>
                </tr>
              </thead>
              <tbody>
                {cohortData.map((row) => (
                  <tr key={row.week} className="border-b border-slate-50">
                    <td className="py-2 px-3 font-medium text-slate-700">
                      {row.week}
                    </td>
                    {[row.jan, row.feb, row.mar, row.apr].map((val, i) => (
                      <td key={i} className="py-2 px-3 text-center">
                        <span
                          className="inline-block w-12 py-1 rounded text-xs font-medium"
                          style={{
                            backgroundColor: `rgba(99, 102, 241, ${val / 100})`,
                            color: val > 60 ? 'white' : '#334155',
                          }}
                        >
                          {val}%
                        </span>
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Event breakdown */}
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <h2 className="text-lg font-semibold text-slate-900 mb-4">
            Event Breakdown
          </h2>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={eventData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis
                dataKey="event"
                tick={{ fontSize: 11, fill: '#94a3b8' }}
                axisLine={{ stroke: '#e2e8f0' }}
                angle={-20}
                textAnchor="end"
                height={60}
              />
              <YAxis
                tick={{ fontSize: 12, fill: '#94a3b8' }}
                axisLine={{ stroke: '#e2e8f0' }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#fff',
                  border: '1px solid #e2e8f0',
                  borderRadius: '8px',
                  fontSize: '12px',
                }}
                formatter={(value: number) => [
                  value.toLocaleString(),
                  'Events',
                ]}
              />
              <Bar
                dataKey="count"
                fill="#6366f1"
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
