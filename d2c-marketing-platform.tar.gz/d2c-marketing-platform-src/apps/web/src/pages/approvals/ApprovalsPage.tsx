import { useState } from 'react';
import { ShieldCheck, ShieldX, Clock, CheckCircle, XCircle } from 'lucide-react';
import { AgentBadge } from '@/components/chat/AgentBadge';
import clsx from 'clsx';

interface Approval {
  id: string;
  title: string;
  description: string;
  agent: string;
  actionType: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  payload: Record<string, unknown>;
}

const mockApprovals: Approval[] = [
  {
    id: 'a1',
    title: 'Create audience "High-LTV Prospects"',
    description: 'Dynamic audience based on predicted LTV > $500 with engagement score > 70.',
    agent: 'Audience Agent',
    actionType: 'audience.create',
    status: 'pending',
    createdAt: '2026-04-16 10:30',
    payload: { name: 'High-LTV Prospects', type: 'predictive', rules: [{ field: 'predicted_ltv', op: '>', value: 500 }] },
  },
  {
    id: 'a2',
    title: 'Increase budget for "Spring Sale" to $7,500',
    description: 'Campaign is performing well with 4.2x ROAS. Recommending 50% budget increase.',
    agent: 'Campaign Agent',
    actionType: 'campaign.update_budget',
    status: 'pending',
    createdAt: '2026-04-16 09:15',
    payload: { campaignId: '1', currentBudget: 5000, newBudget: 7500 },
  },
  {
    id: 'a3',
    title: 'Activate "Win-Back" journey',
    description: 'Journey targets users inactive for 30+ days with a 3-step email sequence.',
    agent: 'Journey Agent',
    actionType: 'journey.activate',
    status: 'pending',
    createdAt: '2026-04-15 16:45',
    payload: { journeyId: '4', steps: 3, targetAudience: 'Inactive 30d' },
  },
  {
    id: 'a4',
    title: 'Pause "New Product Launch" campaign',
    description: 'ROAS dropped below 1.0x threshold. Recommending pause for optimization.',
    agent: 'Campaign Agent',
    actionType: 'campaign.pause',
    status: 'approved',
    createdAt: '2026-04-14 11:20',
    payload: { campaignId: '4', reason: 'Low ROAS' },
  },
  {
    id: 'a5',
    title: 'Delete audience "Test Segment"',
    description: 'Test audience with 0 members. No longer needed.',
    agent: 'Audience Agent',
    actionType: 'audience.delete',
    status: 'rejected',
    createdAt: '2026-04-13 14:00',
    payload: { audienceId: 'test-1' },
  },
];

const statusIcons: Record<string, React.ReactNode> = {
  pending: <Clock className="w-4 h-4 text-amber-500" />,
  approved: <CheckCircle className="w-4 h-4 text-emerald-500" />,
  rejected: <XCircle className="w-4 h-4 text-red-500" />,
};

export function ApprovalsPage() {
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const filtered = mockApprovals.filter(
    (a) => statusFilter === 'all' || a.status === statusFilter,
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Approvals</h1>
        <p className="text-slate-500 mt-1">
          Review and approve AI agent actions
        </p>
      </div>

      {/* Filters */}
      <div className="flex gap-2">
        {['all', 'pending', 'approved', 'rejected'].map((s) => (
          <button
            key={s}
            onClick={() => setStatusFilter(s)}
            className={clsx(
              'px-3 py-1.5 rounded-lg text-sm font-medium transition-colors capitalize',
              statusFilter === s
                ? 'bg-brand-600 text-white'
                : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50',
            )}
          >
            {s}
          </button>
        ))}
      </div>

      {/* List */}
      <div className="space-y-3">
        {filtered.map((approval) => (
          <div
            key={approval.id}
            className="bg-white rounded-xl border border-slate-200 p-5 hover:shadow-md transition-shadow"
          >
            <div className="flex items-start gap-4">
              <div className="mt-0.5">{statusIcons[approval.status]}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="text-sm font-semibold text-slate-900">
                    {approval.title}
                  </h3>
                  <AgentBadge agent={approval.agent} />
                </div>
                <p className="text-sm text-slate-500">{approval.description}</p>
                <div className="flex items-center gap-4 mt-2">
                  <span className="text-xs text-slate-400">
                    {approval.createdAt}
                  </span>
                  <span className="text-xs font-mono text-slate-400">
                    {approval.actionType}
                  </span>
                  <button
                    onClick={() =>
                      setExpandedId(
                        expandedId === approval.id ? null : approval.id,
                      )
                    }
                    className="text-xs text-brand-600 hover:text-brand-700 font-medium"
                  >
                    {expandedId === approval.id ? 'Hide' : 'View'} payload
                  </button>
                </div>

                {expandedId === approval.id && (
                  <pre className="mt-3 p-3 bg-slate-900 text-slate-100 rounded-lg text-xs overflow-x-auto font-mono">
                    {JSON.stringify(approval.payload, null, 2)}
                  </pre>
                )}
              </div>

              {approval.status === 'pending' && (
                <div className="flex gap-2 shrink-0">
                  <button className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-medium hover:bg-emerald-700 transition-colors">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    Approve
                  </button>
                  <button className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-600 text-white text-xs font-medium hover:bg-red-700 transition-colors">
                    <ShieldX className="w-3.5 h-3.5" />
                    Reject
                  </button>
                </div>
              )}

              {approval.status !== 'pending' && (
                <span
                  className={clsx(
                    'text-xs font-medium px-2.5 py-1 rounded-full capitalize shrink-0',
                    approval.status === 'approved'
                      ? 'bg-emerald-100 text-emerald-700'
                      : 'bg-red-100 text-red-700',
                  )}
                >
                  {approval.status}
                </span>
              )}
            </div>
          </div>
        ))}

        {filtered.length === 0 && (
          <div className="text-center py-12 bg-white rounded-xl border border-slate-200">
            <p className="text-sm text-slate-500">No approvals found</p>
          </div>
        )}
      </div>
    </div>
  );
}
