import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Users, Edit, RefreshCw } from 'lucide-react';
import clsx from 'clsx';

const mockAudience = {
  id: '1',
  name: 'High-Value Shoppers',
  description:
    'Customers who have made 3+ purchases with an average order value above $150 in the last 90 days.',
  type: 'dynamic',
  size: 12450,
  status: 'active',
  createdAt: '2026-04-10',
  lastRefreshed: '2026-04-16 09:30',
  rules: [
    { field: 'total_orders', operator: '>=', value: '3' },
    { field: 'avg_order_value', operator: '>', value: '150' },
    { field: 'last_purchase_date', operator: 'within', value: '90 days' },
  ],
};

export function AudienceDetailPage() {
  const { id } = useParams();

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Link
          to="/audiences"
          className="p-2 rounded-lg hover:bg-slate-100 text-slate-600 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div className="flex-1">
          <h1 className="text-2xl font-bold text-slate-900">
            {mockAudience.name}
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Audience ID: {id}
          </p>
        </div>
        <button className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-slate-200 text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors">
          <RefreshCw className="w-4 h-4" />
          Refresh
        </button>
        <button className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-brand-600 text-white text-sm font-medium hover:bg-brand-700 transition-colors">
          <Edit className="w-4 h-4" />
          Edit Rules
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Details */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-xl border border-slate-200 p-6">
            <h2 className="text-lg font-semibold text-slate-900 mb-3">
              Description
            </h2>
            <p className="text-sm text-slate-600 leading-relaxed">
              {mockAudience.description}
            </p>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 p-6">
            <h2 className="text-lg font-semibold text-slate-900 mb-4">
              Segment Rules
            </h2>
            <div className="space-y-3">
              {mockAudience.rules.map((rule, i) => (
                <div
                  key={i}
                  className="flex items-center gap-2 p-3 bg-slate-50 rounded-lg"
                >
                  {i > 0 && (
                    <span className="text-xs font-medium text-brand-600 bg-brand-50 px-2 py-0.5 rounded">
                      AND
                    </span>
                  )}
                  <span className="text-sm font-mono text-slate-700">
                    {rule.field}
                  </span>
                  <span className="text-sm font-medium text-brand-600">
                    {rule.operator}
                  </span>
                  <span className="text-sm font-mono text-slate-900 font-medium">
                    {rule.value}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar stats */}
        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-slate-200 p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2.5 rounded-lg bg-brand-50 text-brand-600">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <p className="text-2xl font-bold text-slate-900">
                  {mockAudience.size.toLocaleString()}
                </p>
                <p className="text-sm text-slate-500">Members</p>
              </div>
            </div>
            <div className="space-y-3 pt-4 border-t border-slate-100">
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Status</span>
                <span
                  className={clsx(
                    'px-2 py-0.5 rounded-full text-xs font-medium capitalize',
                    mockAudience.status === 'active'
                      ? 'bg-emerald-100 text-emerald-700'
                      : 'bg-slate-100 text-slate-600',
                  )}
                >
                  {mockAudience.status}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Type</span>
                <span className="text-slate-700 capitalize">
                  {mockAudience.type}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Created</span>
                <span className="text-slate-700">
                  {mockAudience.createdAt}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Last refreshed</span>
                <span className="text-slate-700">
                  {mockAudience.lastRefreshed}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
