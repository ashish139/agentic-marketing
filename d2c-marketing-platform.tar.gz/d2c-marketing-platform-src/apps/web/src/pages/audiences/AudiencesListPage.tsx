import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Plus, Users } from 'lucide-react';
import clsx from 'clsx';

interface Audience {
  id: string;
  name: string;
  type: 'dynamic' | 'static' | 'predictive';
  size: number;
  status: 'active' | 'building' | 'draft';
  createdAt: string;
}

const mockAudiences: Audience[] = [
  {
    id: '1',
    name: 'High-Value Shoppers',
    type: 'dynamic',
    size: 12450,
    status: 'active',
    createdAt: '2026-04-10',
  },
  {
    id: '2',
    name: 'Cart Abandoners - 7 days',
    type: 'dynamic',
    size: 2340,
    status: 'active',
    createdAt: '2026-04-08',
  },
  {
    id: '3',
    name: 'Churn Risk - High',
    type: 'predictive',
    size: 890,
    status: 'active',
    createdAt: '2026-04-05',
  },
  {
    id: '4',
    name: 'Newsletter Subscribers',
    type: 'static',
    size: 34200,
    status: 'active',
    createdAt: '2026-03-28',
  },
  {
    id: '5',
    name: 'Repeat Buyers (3+ orders)',
    type: 'dynamic',
    size: 5670,
    status: 'building',
    createdAt: '2026-04-14',
  },
  {
    id: '6',
    name: 'VIP Customers Draft',
    type: 'dynamic',
    size: 0,
    status: 'draft',
    createdAt: '2026-04-15',
  },
];

const statusStyles: Record<string, string> = {
  active: 'bg-emerald-100 text-emerald-700',
  building: 'bg-amber-100 text-amber-700',
  draft: 'bg-slate-100 text-slate-600',
};

const typeStyles: Record<string, string> = {
  dynamic: 'bg-blue-100 text-blue-700',
  static: 'bg-slate-100 text-slate-600',
  predictive: 'bg-purple-100 text-purple-700',
};

export function AudiencesListPage() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const filtered = mockAudiences.filter((a) => {
    const matchesSearch = a.name
      .toLowerCase()
      .includes(search.toLowerCase());
    const matchesStatus =
      statusFilter === 'all' || a.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Audiences</h1>
          <p className="text-slate-500 mt-1">
            Manage your customer segments
          </p>
        </div>
        <Link
          to="/chat"
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-brand-600 text-white text-sm font-medium hover:bg-brand-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          New Audience
        </Link>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search audiences..."
            className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none bg-white"
        >
          <option value="all">All statuses</option>
          <option value="active">Active</option>
          <option value="building">Building</option>
          <option value="draft">Draft</option>
        </select>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50">
              <th className="text-left text-xs font-medium text-slate-500 uppercase tracking-wider px-6 py-3">
                Name
              </th>
              <th className="text-left text-xs font-medium text-slate-500 uppercase tracking-wider px-6 py-3">
                Type
              </th>
              <th className="text-left text-xs font-medium text-slate-500 uppercase tracking-wider px-6 py-3">
                Size
              </th>
              <th className="text-left text-xs font-medium text-slate-500 uppercase tracking-wider px-6 py-3">
                Status
              </th>
              <th className="text-left text-xs font-medium text-slate-500 uppercase tracking-wider px-6 py-3">
                Created
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filtered.map((audience) => (
              <tr
                key={audience.id}
                className="hover:bg-slate-50 transition-colors"
              >
                <td className="px-6 py-4">
                  <Link
                    to={`/audiences/${audience.id}`}
                    className="flex items-center gap-3"
                  >
                    <div className="p-2 rounded-lg bg-brand-50 text-brand-600">
                      <Users className="w-4 h-4" />
                    </div>
                    <span className="text-sm font-medium text-slate-900 hover:text-brand-600 transition-colors">
                      {audience.name}
                    </span>
                  </Link>
                </td>
                <td className="px-6 py-4">
                  <span
                    className={clsx(
                      'inline-flex px-2 py-0.5 rounded-full text-xs font-medium capitalize',
                      typeStyles[audience.type],
                    )}
                  >
                    {audience.type}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm text-slate-600">
                  {audience.size.toLocaleString()}
                </td>
                <td className="px-6 py-4">
                  <span
                    className={clsx(
                      'inline-flex px-2 py-0.5 rounded-full text-xs font-medium capitalize',
                      statusStyles[audience.status],
                    )}
                  >
                    {audience.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm text-slate-500">
                  {audience.createdAt}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <div className="text-center py-12 text-sm text-slate-500">
            No audiences found
          </div>
        )}
      </div>
    </div>
  );
}
