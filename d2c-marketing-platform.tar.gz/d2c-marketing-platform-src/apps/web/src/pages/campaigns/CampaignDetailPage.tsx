import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Pause, Play, DollarSign, Eye, MousePointerClick, ShoppingCart } from 'lucide-react';
import { PerformanceChart } from '@/components/campaigns/PerformanceChart';

const mockCampaign = {
  id: '1',
  name: 'Spring Sale 2026',
  type: 'conversion',
  platform: 'Google Ads',
  status: 'active',
  budget: 5000,
  spent: 3200,
  roas: 4.2,
  impressions: 124500,
  clicks: 8715,
  conversions: 464,
  ctr: 7.0,
  cpc: 0.37,
  startDate: '2026-04-01',
  endDate: '2026-04-30',
  creatives: [
    { id: 'c1', name: 'Spring Banner - Desktop', type: 'image', status: 'active' },
    { id: 'c2', name: 'Spring Banner - Mobile', type: 'image', status: 'active' },
    { id: 'c3', name: 'Spring Video Ad', type: 'video', status: 'paused' },
  ],
};

export function CampaignDetailPage() {
  const { id } = useParams();

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Link
          to="/campaigns"
          className="p-2 rounded-lg hover:bg-slate-100 text-slate-600 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div className="flex-1">
          <h1 className="text-2xl font-bold text-slate-900">
            {mockCampaign.name}
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            {mockCampaign.platform} &middot; {mockCampaign.type} &middot;
            Campaign ID: {id}
          </p>
        </div>
        <button className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-slate-200 text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors">
          {mockCampaign.status === 'active' ? (
            <>
              <Pause className="w-4 h-4" /> Pause
            </>
          ) : (
            <>
              <Play className="w-4 h-4" /> Resume
            </>
          )}
        </button>
      </div>

      {/* KPI row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          {
            label: 'Impressions',
            value: mockCampaign.impressions.toLocaleString(),
            icon: <Eye className="w-5 h-5" />,
          },
          {
            label: 'Clicks',
            value: mockCampaign.clicks.toLocaleString(),
            icon: <MousePointerClick className="w-5 h-5" />,
          },
          {
            label: 'Conversions',
            value: mockCampaign.conversions.toLocaleString(),
            icon: <ShoppingCart className="w-5 h-5" />,
          },
          {
            label: 'ROAS',
            value: `${mockCampaign.roas}x`,
            icon: <DollarSign className="w-5 h-5" />,
          },
        ].map((stat) => (
          <div
            key={stat.label}
            className="bg-white rounded-xl border border-slate-200 p-5"
          >
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-brand-50 text-brand-600">
                {stat.icon}
              </div>
              <div>
                <p className="text-2xl font-bold text-slate-900">
                  {stat.value}
                </p>
                <p className="text-sm text-slate-500">{stat.label}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Performance chart */}
      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <h2 className="text-lg font-semibold text-slate-900 mb-4">
          Performance Over Time
        </h2>
        <PerformanceChart />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Budget info */}
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <h2 className="text-lg font-semibold text-slate-900 mb-4">
            Budget
          </h2>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-slate-500">
                  Spent: ${mockCampaign.spent.toLocaleString()}
                </span>
                <span className="text-slate-500">
                  Budget: ${mockCampaign.budget.toLocaleString()}
                </span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2.5">
                <div
                  className="bg-brand-600 h-2.5 rounded-full"
                  style={{
                    width: `${(mockCampaign.spent / mockCampaign.budget) * 100}%`,
                  }}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 pt-2">
              <div>
                <p className="text-sm text-slate-500">CTR</p>
                <p className="text-lg font-semibold text-slate-900">
                  {mockCampaign.ctr}%
                </p>
              </div>
              <div>
                <p className="text-sm text-slate-500">CPC</p>
                <p className="text-lg font-semibold text-slate-900">
                  ${mockCampaign.cpc}
                </p>
              </div>
              <div>
                <p className="text-sm text-slate-500">Start Date</p>
                <p className="text-sm font-medium text-slate-700">
                  {mockCampaign.startDate}
                </p>
              </div>
              <div>
                <p className="text-sm text-slate-500">End Date</p>
                <p className="text-sm font-medium text-slate-700">
                  {mockCampaign.endDate}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Creatives */}
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <h2 className="text-lg font-semibold text-slate-900 mb-4">
            Ad Creatives
          </h2>
          <div className="space-y-3">
            {mockCampaign.creatives.map((creative) => (
              <div
                key={creative.id}
                className="flex items-center justify-between p-3 rounded-lg border border-slate-100 hover:bg-slate-50 transition-colors"
              >
                <div>
                  <p className="text-sm font-medium text-slate-700">
                    {creative.name}
                  </p>
                  <p className="text-xs text-slate-400 capitalize">
                    {creative.type}
                  </p>
                </div>
                <span
                  className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                    creative.status === 'active'
                      ? 'bg-emerald-100 text-emerald-700'
                      : 'bg-amber-100 text-amber-700'
                  }`}
                >
                  {creative.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
