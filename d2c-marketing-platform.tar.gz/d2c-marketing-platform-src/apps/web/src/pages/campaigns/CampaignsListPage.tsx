import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Plus, Megaphone } from 'lucide-react';
import clsx from 'clsx';

interface Campaign {
  id: string;
  name: string;
  type: 'awareness' | 'conversion' | 'retargeting';
  platform: 'google_ads' | 'facebook_ads' | 'email';
  status: 'active' | 'paused' | 'draft' | 'completed';
  budget: number;
  spent: number;
  roas: number;
}

const mockCampaigns: Campaign[] = [
  {
    id: '1',
    name: 'Spring Sale 2026',
    type: 'conversion',
    platform: 'google_ads',
    status: 'active',
    budget: 5000,
    spent: 3200,
    roas: 4.2,
  },
  {
    id: '2',
    name: 'Brand Awareness - April',
    type: 'awareness',
    platform: 'facebook_ads',
    status: 'active',
    budget: 3000,
    spent: 1800,
    roas: 2.1,
  },
  {
    id: '3',
    name: 'Cart Abandonment Retargeting',
    type: 'retargeting',
    platform: 'google_ads',
    status: 'active',
    budget: 2000,
    spent: 1450,
    roas: 6.8,
  },
  {
    id: '4',
    name: 'New Product Launch',
    type: 'awareness',
    platform: 'facebook_ads',
    status: 'paused',
    budget: 4000,
    spent: 2100,
    roas: 1.5,
  },
  {
    id: '5',
    name: 'Holiday Season Prep',
    type: 'conversion',
    platform: 'google_ads',
    status: 'draft',
    budget: 10000,
    spent: 0,
    roas: 0,
  },
  {
    id: '6',
    name: 'Winter Clearance',
    type: 'conversion',
    platform: 'email',
    status: 'completed',
    budget: 1500,
    spent: 1500,
    roas: 5.3,
  },
];

const statusStyles: Record<string, string> = {
  active: 'bg-emerald-100 text-emerald-700',
  paused: 'bg-amber-100 text-amber-700',
  draft: 'bg-slate-100 text-slate-600',
  completed: 'bg-blue-100 text-blue-700',
};

const platformLabels: Record<string, string> = {
  google_ads: 'Google Ads',
  facebook_ads: 'Facebook Ads',
  email: 'Email',
};

export function CampaignsListPage() {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [platformFilter, setPlatformFilter] = useState('all');

  const filtered = mockCampaigns.filter((c) => {
    const matchesSearch = c.name
      .toLowerCase()
      .includes(search.toLowerCase());
    const matchesStatus =
      statusFilter === 'all' || c.status === statusFilter;
    const matchesPlatform =
      platformFilter === 'all' || c.platform === platformFilter;
    return matchesSearch && matchesStatus && matchesPlatform;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Campaigns</h1>
          <p className="text-slate-500 mt-1">
            Manage and monitor your ad campaigns
          </p>
        </div>
        <Link
          to="/chat"
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-brand-600 text-white text-sm font-medium hover:bg-brand-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          New Campaign
        </Link>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search campaigns..."
            className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none bg-white"
        >
          <option value="all">All statuses</option>
          <option value="active">Active</option>
          <option value="paused">Paused</option>
          <option value="draft">Draft</option>
          <option value="completed">Completed</option>
        </select>
        <select
          value={platformFilter}
          onChange={(e) => setPlatformFilter(e.target.value)}
          className="px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none bg-white"
        >
          <option value="all">All platforms</option>
          <option value="google_ads">Google Ads</option>
          <option value="facebook_ads">Facebook Ads</option>
          <option value="email">Email</option>
        </select>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50">
              <th className="text-left text-xs font-medium text-slate-500 uppercase tracking-wider px-6 py-3">
                Name
              </th>
              <th className="text-left text-xs font-medium text-slate-500 uppercase tracking-wider px-6 py-3">
                Type
              </th>
              <th className="text-left text-xs font-medium text-slate-500 uppercase tracking-wider px-6 py-3">
                Platform
              </th>
              <th className="text-left text-xs font-medium text-slate-500 uppercase tracking-wider px-6 py-3">
                Status
              </th>
              <th className="text-right text-xs font-medium text-slate-500 uppercase tracking-wider px-6 py-3">
                Budget
              </th>
              <th className="text-right text-xs font-medium text-slate-500 uppercase tracking-wider px-6 py-3">
                ROAS
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filtered.map((campaign) => (
              <tr
                key={campaign.id}
                className="hover:bg-slate-50 transition-colors"
              >
                <td className="px-6 py-4">
                  <Link
                    to={`/campaigns/${campaign.id}`}
                    className="flex items-center gap-3"
                  >
                    <div className="p-2 rounded-lg bg-brand-50 text-brand-600">
                      <Megaphone className="w-4 h-4" />
                    </div>
                    <span className="text-sm font-medium text-slate-900 hover:text-brand-600 transition-colors">
                      {campaign.name}
                    </span>
                  </Link>
                </td>
                <td className="px-6 py-4 text-sm text-slate-600 capitalize">
                  {campaign.type}
                </td>
                <td className="px-6 py-4 text-sm text-slate-600">
                  {platformLabels[campaign.platform]}
                </td>
                <td className="px-6 py-4">
                  <span
                    className={clsx(
                      'inline-flex px-2 py-0.5 rounded-full text-xs font-medium capitalize',
                      statusStyles[campaign.status],
                    )}
                  >
                    {campaign.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm text-slate-600 text-right">
                  ${campaign.budget.toLocaleString()}
                </td>
                <td className="px-6 py-4 text-right">
                  <span
                    className={clsx(
                      'text-sm font-medium',
                      campaign.roas >= 3
                        ? 'text-emerald-600'
                        : campaign.roas >= 1
                          ? 'text-amber-600'
                          : 'text-slate-400',
                    )}
                  >
                    {campaign.roas > 0 ? `${campaign.roas}x` : '-'}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <div className="text-center py-12 text-sm text-slate-500">
            No campaigns found
          </div>
        )}
      </div>
    </div>
  );
}
