import { useState } from 'react';
import { useParams } from 'react-router-dom';
import { useAgent } from '@/hooks/useAgent';
import { ChatWindow } from '@/components/chat/ChatWindow';
import { ChatInput } from '@/components/chat/ChatInput';
import { MessageSquare, Plus } from 'lucide-react';
import clsx from 'clsx';

interface Session {
  id: string;
  title: string;
  updatedAt: string;
}

const mockSessions: Session[] = [
  {
    id: 's1',
    title: 'Create high-value audience segment',
    updatedAt: '2 hours ago',
  },
  {
    id: 's2',
    title: 'Spring sale campaign setup',
    updatedAt: '5 hours ago',
  },
  {
    id: 's3',
    title: 'Welcome journey optimization',
    updatedAt: '1 day ago',
  },
  {
    id: 's4',
    title: 'Analytics deep dive - Q1',
    updatedAt: '2 days ago',
  },
];

export function ChatPage() {
  const { sessionId } = useParams();
  const [activeSession, setActiveSession] = useState<string | null>(
    sessionId ?? null,
  );
  const {
    messages,
    isStreaming,
    activeAgent,
    sendMessage,
    approveAction,
    rejectAction,
    stopStreaming,
  } = useAgent(activeSession);

  return (
    <div className="h-[calc(100vh-8rem)] flex gap-4">
      {/* Session list */}
      <div className="w-72 bg-white rounded-xl border border-slate-200 flex flex-col shrink-0">
        <div className="p-4 border-b border-slate-200">
          <button className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-brand-600 text-white text-sm font-medium hover:bg-brand-700 transition-colors">
            <Plus className="w-4 h-4" />
            New Chat
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {mockSessions.map((session) => (
            <button
              key={session.id}
              onClick={() => setActiveSession(session.id)}
              className={clsx(
                'w-full text-left px-3 py-2.5 rounded-lg transition-colors',
                activeSession === session.id
                  ? 'bg-brand-50 text-brand-700'
                  : 'text-slate-600 hover:bg-slate-50',
              )}
            >
              <div className="flex items-start gap-2">
                <MessageSquare className="w-4 h-4 mt-0.5 shrink-0 opacity-50" />
                <div className="min-w-0">
                  <p className="text-sm font-medium truncate">
                    {session.title}
                  </p>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {session.updatedAt}
                  </p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Chat area */}
      <div className="flex-1 bg-white rounded-xl border border-slate-200 flex flex-col min-w-0">
        {activeAgent && (
          <div className="px-4 py-2 border-b border-slate-100 bg-slate-50 rounded-t-xl">
            <span className="text-xs text-slate-500">Active agent: </span>
            <span className="text-xs font-medium text-brand-600">
              {activeAgent}
            </span>
          </div>
        )}
        <ChatWindow
          messages={messages}
          isStreaming={isStreaming}
          onApprove={approveAction}
          onReject={rejectAction}
        />
        <ChatInput
          onSend={sendMessage}
          isStreaming={isStreaming}
          onStop={stopStreaming}
        />
      </div>
    </div>
  );
}
