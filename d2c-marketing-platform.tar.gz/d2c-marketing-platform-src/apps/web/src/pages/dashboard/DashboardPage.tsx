import { Link } from 'react-router-dom';
import {
  Users,
  Megaphone,
  Target,
  CheckCircle,
  TrendingUp,
  TrendingDown,
  MessageSquare,
  GitBranch,
} from 'lucide-react';

interface MetricCardProps {
  label: string;
  value: string;
  change: number;
  icon: React.ReactNode;
}

function MetricCard({ label, value, change, icon }: MetricCardProps) {
  const isPositive = change >= 0;
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-6 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-slate-500">{label}</p>
          <p className="text-2xl font-bold text-slate-900 mt-1">{value}</p>
        </div>
        <div className="p-2.5 rounded-lg bg-brand-50 text-brand-600">
          {icon}
        </div>
      </div>
      <div className="mt-3 flex items-center gap-1.5">
        {isPositive ? (
          <TrendingUp className="w-4 h-4 text-emerald-500" />
        ) : (
          <TrendingDown className="w-4 h-4 text-red-500" />
        )}
        <span
          className={`text-sm font-medium ${isPositive ? 'text-emerald-600' : 'text-red-600'}`}
        >
          {isPositive ? '+' : ''}
          {change}%
        </span>
        <span className="text-sm text-slate-400">vs last month</span>
      </div>
    </div>
  );
}

const recentActivity = [
  {
    id: '1',
    action: 'Audience "High-Value Shoppers" created',
    agent: 'Audience Agent',
    time: '2 hours ago',
  },
  {
    id: '2',
    action: 'Campaign "Spring Sale" launched on Google Ads',
    agent: 'Campaign Agent',
    time: '5 hours ago',
  },
  {
    id: '3',
    action: 'Journey "Welcome Flow" activated',
    agent: 'Journey Agent',
    time: '1 day ago',
  },
  {
    id: '4',
    action: 'Budget increased for "Brand Awareness" campaign',
    agent: 'Campaign Agent',
    time: '1 day ago',
  },
  {
    id: '5',
    action: 'Audience "Cart Abandoners" refreshed - 2,340 users',
    agent: 'Audience Agent',
    time: '2 days ago',
  },
];

export function DashboardPage() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Dashboard</h1>
        <p className="text-slate-500 mt-1">
          Overview of your marketing operations
        </p>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          label="Total Customers"
          value="24,521"
          change={12.5}
          icon={<Users className="w-5 h-5" />}
        />
        <MetricCard
          label="Active Campaigns"
          value="8"
          change={33.3}
          icon={<Megaphone className="w-5 h-5" />}
        />
        <MetricCard
          label="Active Audiences"
          value="15"
          change={7.1}
          icon={<Target className="w-5 h-5" />}
        />
        <MetricCard
          label="Pending Approvals"
          value="3"
          change={-25}
          icon={<CheckCircle className="w-5 h-5" />}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent activity */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-6">
          <h2 className="text-lg font-semibold text-slate-900 mb-4">
            Recent Activity
          </h2>
          <div className="space-y-4">
            {recentActivity.map((item) => (
              <div key={item.id} className="flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-brand-500 mt-2 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-slate-700">{item.action}</p>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {item.agent} &middot; {item.time}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick actions */}
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <h2 className="text-lg font-semibold text-slate-900 mb-4">
            Quick Actions
          </h2>
          <div className="space-y-3">
            <Link
              to="/chat"
              className="flex items-center gap-3 p-3 rounded-lg border border-slate-200 hover:bg-brand-50 hover:border-brand-200 transition-colors group"
            >
              <div className="p-2 rounded-lg bg-purple-100 text-purple-600 group-hover:bg-purple-200 transition-colors">
                <Users className="w-4 h-4" />
              </div>
              <div>
                <p className="text-sm font-medium text-slate-700">
                  Create Audience
                </p>
                <p className="text-xs text-slate-400">
                  Use AI to build segments
                </p>
              </div>
            </Link>
            <Link
              to="/chat"
              className="flex items-center gap-3 p-3 rounded-lg border border-slate-200 hover:bg-brand-50 hover:border-brand-200 transition-colors group"
            >
              <div className="p-2 rounded-lg bg-blue-100 text-blue-600 group-hover:bg-blue-200 transition-colors">
                <Megaphone className="w-4 h-4" />
              </div>
              <div>
                <p className="text-sm font-medium text-slate-700">
                  Launch Campaign
                </p>
                <p className="text-xs text-slate-400">
                  AI-powered campaign setup
                </p>
              </div>
            </Link>
            <Link
              to="/chat"
              className="flex items-center gap-3 p-3 rounded-lg border border-slate-200 hover:bg-brand-50 hover:border-brand-200 transition-colors group"
            >
              <div className="p-2 rounded-lg bg-emerald-100 text-emerald-600 group-hover:bg-emerald-200 transition-colors">
                <GitBranch className="w-4 h-4" />
              </div>
              <div>
                <p className="text-sm font-medium text-slate-700">
                  Build Journey
                </p>
                <p className="text-xs text-slate-400">
                  Design customer journeys
                </p>
              </div>
            </Link>
            <Link
              to="/chat"
              className="flex items-center gap-3 p-3 rounded-lg border border-slate-200 hover:bg-brand-50 hover:border-brand-200 transition-colors group"
            >
              <div className="p-2 rounded-lg bg-amber-100 text-amber-600 group-hover:bg-amber-200 transition-colors">
                <MessageSquare className="w-4 h-4" />
              </div>
              <div>
                <p className="text-sm font-medium text-slate-700">
                  Ask AI Anything
                </p>
                <p className="text-xs text-slate-400">
                  Chat with your marketing AI
                </p>
              </div>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
