import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Save, Play, Pause } from 'lucide-react';
import { JourneyCanvas } from '@/components/journeys/JourneyCanvas';
import type { Node, Edge } from '@xyflow/react';

const initialNodes: Node[] = [
  {
    id: '1',
    type: 'email',
    position: { x: 250, y: 0 },
    data: { label: 'Welcome Email', subject: 'Welcome to our store!' },
  },
  {
    id: '2',
    type: 'wait',
    position: { x: 250, y: 130 },
    data: { label: 'Wait 2 days', duration: '48 hours' },
  },
  {
    id: '3',
    type: 'condition',
    position: { x: 250, y: 260 },
    data: { label: 'Opened email?', condition: 'email_opened = true' },
  },
  {
    id: '4',
    type: 'email',
    position: { x: 80, y: 420 },
    data: { label: 'Product Recommendations', subject: 'Picked just for you' },
  },
  {
    id: '5',
    type: 'sms',
    position: { x: 420, y: 420 },
    data: { label: 'Reminder SMS' },
  },
  {
    id: '6',
    type: 'wait',
    position: { x: 250, y: 560 },
    data: { label: 'Wait 3 days', duration: '72 hours' },
  },
];

const initialEdges: Edge[] = [
  { id: 'e1-2', source: '1', target: '2', animated: true },
  { id: 'e2-3', source: '2', target: '3', animated: true },
  { id: 'e3-4', source: '3', sourceHandle: 'yes', target: '4', label: 'Yes' },
  { id: 'e3-5', source: '3', sourceHandle: 'no', target: '5', label: 'No' },
  { id: 'e4-6', source: '4', target: '6' },
  { id: 'e5-6', source: '5', target: '6' },
];

export function JourneyBuilderPage() {
  const { id } = useParams();
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);

  return (
    <div className="h-[calc(100vh-8rem)] flex flex-col">
      {/* Header */}
      <div className="flex items-center gap-3 mb-4">
        <Link
          to="/journeys"
          className="p-2 rounded-lg hover:bg-slate-100 text-slate-600 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div className="flex-1">
          <h1 className="text-xl font-bold text-slate-900">
            Welcome Onboarding Flow
          </h1>
          <p className="text-sm text-slate-500">Journey ID: {id}</p>
        </div>
        <button className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-slate-200 text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors">
          <Save className="w-4 h-4" />
          Save
        </button>
        <button className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-emerald-600 text-white text-sm font-medium hover:bg-emerald-700 transition-colors">
          <Play className="w-4 h-4" />
          Activate
        </button>
      </div>

      {/* Canvas + side panel */}
      <div className="flex-1 flex gap-4 min-h-0">
        <div className="flex-1 bg-white rounded-xl border border-slate-200 overflow-hidden">
          <JourneyCanvas
            initialNodes={initialNodes}
            initialEdges={initialEdges}
            onNodeSelect={setSelectedNode}
          />
        </div>

        {/* Side panel for selected node */}
        {selectedNode && (
          <div className="w-80 bg-white rounded-xl border border-slate-200 p-5 overflow-y-auto shrink-0">
            <h3 className="text-sm font-semibold text-slate-900 mb-4">
              Node Configuration
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">
                  Type
                </label>
                <p className="text-sm text-slate-700 capitalize">
                  {selectedNode.type}
                </p>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">
                  Label
                </label>
                <input
                  type="text"
                  defaultValue={
                    (selectedNode.data as Record<string, string>).label
                  }
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none"
                />
              </div>
              {(selectedNode.data as Record<string, string>).subject && (
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">
                    Subject
                  </label>
                  <input
                    type="text"
                    defaultValue={
                      (selectedNode.data as Record<string, string>).subject
                    }
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none"
                  />
                </div>
              )}
              {(selectedNode.data as Record<string, string>).duration && (
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">
                    Duration
                  </label>
                  <input
                    type="text"
                    defaultValue={
                      (selectedNode.data as Record<string, string>).duration
                    }
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none"
                  />
                </div>
              )}
              {(selectedNode.data as Record<string, string>).condition && (
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">
                    Condition
                  </label>
                  <input
                    type="text"
                    defaultValue={
                      (selectedNode.data as Record<string, string>).condition
                    }
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none"
                  />
                </div>
              )}
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1">
                  Node ID
                </label>
                <p className="text-xs font-mono text-slate-400">
                  {selectedNode.id}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
