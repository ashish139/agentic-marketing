import { Link } from 'react-router-dom';
import { Plus, GitBranch } from 'lucide-react';
import clsx from 'clsx';

interface Journey {
  id: string;
  name: string;
  status: 'active' | 'draft' | 'paused';
  stepsCount: number;
  createdAt: string;
  entered: number;
}

const mockJourneys: Journey[] = [
  {
    id: '1',
    name: 'Welcome Onboarding Flow',
    status: 'active',
    stepsCount: 6,
    createdAt: '2026-03-15',
    entered: 8450,
  },
  {
    id: '2',
    name: 'Cart Abandonment Recovery',
    status: 'active',
    stepsCount: 4,
    createdAt: '2026-03-20',
    entered: 2340,
  },
  {
    id: '3',
    name: 'Post-Purchase Upsell',
    status: 'active',
    stepsCount: 5,
    createdAt: '2026-04-01',
    entered: 5120,
  },
  {
    id: '4',
    name: 'Win-Back Campaign',
    status: 'paused',
    stepsCount: 3,
    createdAt: '2026-04-05',
    entered: 1200,
  },
  {
    id: '5',
    name: 'VIP Loyalty Rewards',
    status: 'draft',
    stepsCount: 7,
    createdAt: '2026-04-14',
    entered: 0,
  },
];

const statusStyles: Record<string, string> = {
  active: 'bg-emerald-100 text-emerald-700',
  draft: 'bg-slate-100 text-slate-600',
  paused: 'bg-amber-100 text-amber-700',
};

export function JourneysListPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Journeys</h1>
          <p className="text-slate-500 mt-1">
            Design and manage customer journeys
          </p>
        </div>
        <Link
          to="/chat"
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-brand-600 text-white text-sm font-medium hover:bg-brand-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          New Journey
        </Link>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50">
              <th className="text-left text-xs font-medium text-slate-500 uppercase tracking-wider px-6 py-3">
                Name
              </th>
              <th className="text-left text-xs font-medium text-slate-500 uppercase tracking-wider px-6 py-3">
                Status
              </th>
              <th className="text-left text-xs font-medium text-slate-500 uppercase tracking-wider px-6 py-3">
                Steps
              </th>
              <th className="text-right text-xs font-medium text-slate-500 uppercase tracking-wider px-6 py-3">
                Users Entered
              </th>
              <th className="text-left text-xs font-medium text-slate-500 uppercase tracking-wider px-6 py-3">
                Created
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {mockJourneys.map((journey) => (
              <tr
                key={journey.id}
                className="hover:bg-slate-50 transition-colors"
              >
                <td className="px-6 py-4">
                  <Link
                    to={`/journeys/${journey.id}`}
                    className="flex items-center gap-3"
                  >
                    <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600">
                      <GitBranch className="w-4 h-4" />
                    </div>
                    <span className="text-sm font-medium text-slate-900 hover:text-brand-600 transition-colors">
                      {journey.name}
                    </span>
                  </Link>
                </td>
                <td className="px-6 py-4">
                  <span
                    className={clsx(
                      'inline-flex px-2 py-0.5 rounded-full text-xs font-medium capitalize',
                      statusStyles[journey.status],
                    )}
                  >
                    {journey.status}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm text-slate-600">
                  {journey.stepsCount}
                </td>
                <td className="px-6 py-4 text-sm text-slate-600 text-right">
                  {journey.entered.toLocaleString()}
                </td>
                <td className="px-6 py-4 text-sm text-slate-500">
                  {journey.createdAt}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
