import { useState } from 'react';
import {
  Plug,
  CheckCircle,
  XCircle,
  RefreshCw,
  Plus,
  ToggleLeft,
  ToggleRight,
} from 'lucide-react';
import clsx from 'clsx';

interface Connector {
  id: string;
  name: string;
  platform: string;
  status: 'connected' | 'disconnected';
  mockMode: boolean;
  lastSync: string | null;
}

const initialConnectors: Connector[] = [
  {
    id: 'c1',
    name: 'Google Ads Production',
    platform: 'google_ads',
    status: 'connected',
    mockMode: false,
    lastSync: '2026-04-16 10:00',
  },
  {
    id: 'c2',
    name: 'Facebook Ads Production',
    platform: 'facebook_ads',
    status: 'connected',
    mockMode: true,
    lastSync: '2026-04-15 18:30',
  },
];

const platformLogos: Record<string, { bg: string; label: string }> = {
  google_ads: { bg: 'bg-blue-100 text-blue-700', label: 'Google Ads' },
  facebook_ads: { bg: 'bg-indigo-100 text-indigo-700', label: 'Facebook Ads' },
};

export function ConnectorsPage() {
  const [connectors, setConnectors] = useState(initialConnectors);
  const [showAddForm, setShowAddForm] = useState(false);
  const [testingId, setTestingId] = useState<string | null>(null);
  const [newName, setNewName] = useState('');
  const [newPlatform, setNewPlatform] = useState('google_ads');

  function toggleMockMode(id: string) {
    setConnectors((prev) =>
      prev.map((c) =>
        c.id === id ? { ...c, mockMode: !c.mockMode } : c,
      ),
    );
  }

  function testConnection(id: string) {
    setTestingId(id);
    setTimeout(() => setTestingId(null), 2000);
  }

  function addConnector() {
    if (!newName.trim()) return;
    const connector: Connector = {
      id: `c${Date.now()}`,
      name: newName.trim(),
      platform: newPlatform,
      status: 'disconnected',
      mockMode: true,
      lastSync: null,
    };
    setConnectors((prev) => [...prev, connector]);
    setNewName('');
    setShowAddForm(false);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Connectors</h1>
          <p className="text-slate-500 mt-1">
            Manage your ad platform integrations
          </p>
        </div>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-brand-600 text-white text-sm font-medium hover:bg-brand-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Add Connector
        </button>
      </div>

      {/* Add form */}
      {showAddForm && (
        <div className="bg-white rounded-xl border border-slate-200 p-6">
          <h3 className="text-sm font-semibold text-slate-900 mb-4">
            New Connector
          </h3>
          <div className="flex items-end gap-4">
            <div className="flex-1">
              <label className="block text-xs font-medium text-slate-500 mb-1">
                Name
              </label>
              <input
                type="text"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="e.g., Google Ads - Staging"
                className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none"
              />
            </div>
            <div className="w-48">
              <label className="block text-xs font-medium text-slate-500 mb-1">
                Platform
              </label>
              <select
                value={newPlatform}
                onChange={(e) => setNewPlatform(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 text-sm focus:ring-2 focus:ring-brand-500 focus:border-brand-500 outline-none bg-white"
              >
                <option value="google_ads">Google Ads</option>
                <option value="facebook_ads">Facebook Ads</option>
              </select>
            </div>
            <button
              onClick={addConnector}
              className="px-4 py-2 rounded-lg bg-brand-600 text-white text-sm font-medium hover:bg-brand-700 transition-colors"
            >
              Add
            </button>
            <button
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 rounded-lg border border-slate-200 text-sm font-medium text-slate-600 hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Connector cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {connectors.map((connector) => {
          const platform = platformLogos[connector.platform] ?? {
            bg: 'bg-slate-100 text-slate-600',
            label: connector.platform,
          };

          return (
            <div
              key={connector.id}
              className="bg-white rounded-xl border border-slate-200 p-6 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div
                    className={clsx(
                      'p-2.5 rounded-lg font-bold text-sm',
                      platform.bg,
                    )}
                  >
                    <Plug className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-slate-900">
                      {connector.name}
                    </h3>
                    <p className="text-xs text-slate-500">{platform.label}</p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  {connector.status === 'connected' ? (
                    <>
                      <CheckCircle className="w-4 h-4 text-emerald-500" />
                      <span className="text-xs font-medium text-emerald-600">
                        Connected
                      </span>
                    </>
                  ) : (
                    <>
                      <XCircle className="w-4 h-4 text-red-500" />
                      <span className="text-xs font-medium text-red-600">
                        Disconnected
                      </span>
                    </>
                  )}
                </div>
              </div>

              <div className="space-y-3">
                {/* Mock mode toggle */}
                <div className="flex items-center justify-between py-2 px-3 bg-slate-50 rounded-lg">
                  <div>
                    <p className="text-sm font-medium text-slate-700">
                      Mock Mode
                    </p>
                    <p className="text-xs text-slate-400">
                      {connector.mockMode
                        ? 'Using simulated data'
                        : 'Using live API'}
                    </p>
                  </div>
                  <button
                    onClick={() => toggleMockMode(connector.id)}
                    className="text-brand-600"
                  >
                    {connector.mockMode ? (
                      <ToggleRight className="w-8 h-8" />
                    ) : (
                      <ToggleLeft className="w-8 h-8 text-slate-400" />
                    )}
                  </button>
                </div>

                {connector.lastSync && (
                  <p className="text-xs text-slate-400">
                    Last synced: {connector.lastSync}
                  </p>
                )}

                {/* Actions */}
                <div className="flex gap-2 pt-2">
                  <button
                    onClick={() => testConnection(connector.id)}
                    disabled={testingId === connector.id}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-medium text-slate-600 hover:bg-slate-50 transition-colors disabled:opacity-50"
                  >
                    <RefreshCw
                      className={clsx(
                        'w-3.5 h-3.5',
                        testingId === connector.id && 'animate-spin',
                      )}
                    />
                    {testingId === connector.id
                      ? 'Testing...'
                      : 'Test Connection'}
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {connectors.length === 0 && (
        <div className="text-center py-16 bg-white rounded-xl border border-slate-200">
          <Plug className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <p className="text-sm text-slate-500">No connectors configured</p>
          <p className="text-xs text-slate-400 mt-1">
            Add a connector to get started
          </p>
        </div>
      )}
    </div>
  );
}
