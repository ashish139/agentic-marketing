import { createBrowserRouter } from 'react-router-dom';
import { AuthLayout } from './layouts/AuthLayout';
import { RootLayout } from './layouts/RootLayout';
import { LoginPage } from './pages/auth/LoginPage';
import { SignupPage } from './pages/auth/SignupPage';
import { DashboardPage } from './pages/dashboard/DashboardPage';
import { ChatPage } from './pages/chat/ChatPage';
import { AudiencesListPage } from './pages/audiences/AudiencesListPage';
import { AudienceDetailPage } from './pages/audiences/AudienceDetailPage';
import { CampaignsListPage } from './pages/campaigns/CampaignsListPage';
import { CampaignDetailPage } from './pages/campaigns/CampaignDetailPage';
import { JourneysListPage } from './pages/journeys/JourneysListPage';
import { JourneyBuilderPage } from './pages/journeys/JourneyBuilderPage';
import { AnalyticsPage } from './pages/analytics/AnalyticsPage';
import { ApprovalsPage } from './pages/approvals/ApprovalsPage';
import { ConnectorsPage } from './pages/settings/ConnectorsPage';

export const router = createBrowserRouter([
  {
    element: <AuthLayout />,
    children: [
      { path: '/login', element: <LoginPage /> },
      { path: '/signup', element: <SignupPage /> },
    ],
  },
  {
    path: '/',
    element: <RootLayout />,
    children: [
      { index: true, element: <DashboardPage /> },
      { path: 'chat', element: <ChatPage /> },
      { path: 'chat/:sessionId', element: <ChatPage /> },
      { path: 'audiences', element: <AudiencesListPage /> },
      { path: 'audiences/:id', element: <AudienceDetailPage /> },
      { path: 'campaigns', element: <CampaignsListPage /> },
      { path: 'campaigns/:id', element: <CampaignDetailPage /> },
      { path: 'journeys', element: <JourneysListPage /> },
      { path: 'journeys/:id', element: <JourneyBuilderPage /> },
      { path: 'analytics', element: <AnalyticsPage /> },
      { path: 'approvals', element: <ApprovalsPage /> },
      { path: 'settings/connectors', element: <ConnectorsPage /> },
    ],
  },
]);
