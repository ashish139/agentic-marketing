import type { StateCreator } from 'zustand';

export interface AuthSlice {
  user: { id: string; email: string; name: string } | null;
  orgId: string | null;
  role: string | null;
  setUser: (user: AuthSlice['user']) => void;
  setOrg: (orgId: string, role: string) => void;
  clearAuth: () => void;
}

export const createAuthSlice: StateCreator<AuthSlice> = (set) => ({
  user: null,
  orgId: null,
  role: null,
  setUser: (user) => set({ user }),
  setOrg: (orgId, role) => set({ orgId, role }),
  clearAuth: () => set({ user: null, orgId: null, role: null }),
});
