import { create } from 'zustand';
import { createAuthSlice, type AuthSlice } from './authSlice';
import { createUiSlice, type UiSlice } from './uiSlice';

type StoreState = AuthSlice & UiSlice;

export const useStore = create<StoreState>()((...a) => ({
  ...createAuthSlice(...a),
  ...createUiSlice(...a),
}));
