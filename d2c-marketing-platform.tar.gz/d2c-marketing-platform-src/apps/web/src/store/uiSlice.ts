import type { StateCreator } from 'zustand';

export interface UiSlice {
  sidebarOpen: boolean;
  currentPage: string;
  setSidebarOpen: (open: boolean) => void;
  toggleSidebar: () => void;
  setCurrentPage: (page: string) => void;
}

export const createUiSlice: StateCreator<UiSlice> = (set) => ({
  sidebarOpen: true,
  currentPage: 'dashboard',
  setSidebarOpen: (sidebarOpen) => set({ sidebarOpen }),
  toggleSidebar: () => set((s) => ({ sidebarOpen: !s.sidebarOpen })),
  setCurrentPage: (currentPage) => set({ currentPage }),
});
