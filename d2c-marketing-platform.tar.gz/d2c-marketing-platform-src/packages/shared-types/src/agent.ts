export type AgentName =
  | 'orchestrator'
  | 'campaign_manager'
  | 'audience_builder'
  | 'content_creator'
  | 'analytics_analyst'
  | 'journey_designer';

export type MessageRole = 'user' | 'assistant' | 'system' | 'tool';

export type SSEEventType =
  | 'message'
  | 'tool_call'
  | 'tool_result'
  | 'agent_handoff'
  | 'thinking'
  | 'error'
  | 'done';

export interface AgentSession {
  id: string;
  org_id: string;
  user_id: string;
  title?: string;
  active_agent: AgentName;
  context?: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

export interface AgentMessage {
  id: string;
  session_id: string;
  role: MessageRole;
  content: string;
  agent_name?: AgentName;
  tool_name?: string;
  tool_args?: Record<string, unknown>;
  tool_result?: unknown;
  metadata?: Record<string, unknown>;
  created_at: string;
}

export interface ChatRequest {
  session_id?: string;
  message: string;
  org_id: string;
  user_id: string;
  context?: Record<string, unknown>;
}

export interface SSEEvent {
  event: SSEEventType;
  data: {
    content?: string;
    agent_name?: AgentName;
    tool_name?: string;
    tool_args?: Record<string, unknown>;
    tool_result?: unknown;
    target_agent?: AgentName;
    error?: string;
    session_id?: string;
    message_id?: string;
  };
}
