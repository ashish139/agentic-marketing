export type WidgetType =
  | 'line_chart'
  | 'bar_chart'
  | 'pie_chart'
  | 'metric_card'
  | 'table'
  | 'funnel'
  | 'cohort'
  | 'heatmap';

export interface Event {
  id: string;
  org_id: string;
  customer_id: string;
  event_name: string;
  event_properties?: Record<string, unknown>;
  source?: string;
  session_id?: string;
  timestamp: string;
  created_at: string;
}

export interface DashboardWidget {
  id: string;
  dashboard_id: string;
  name: string;
  widget_type: WidgetType;
  config: Record<string, unknown>;
  position_x: number;
  position_y: number;
  width: number;
  height: number;
  created_at: string;
  updated_at: string;
}

export interface Dashboard {
  id: string;
  org_id: string;
  name: string;
  description?: string;
  is_default: boolean;
  widgets?: DashboardWidget[];
  created_by?: string;
  created_at: string;
  updated_at: string;
}

export interface FunnelData {
  steps: {
    name: string;
    count: number;
    conversion_rate: number;
    drop_off_rate: number;
  }[];
  overall_conversion: number;
  total_entered: number;
  total_completed: number;
}

export interface CohortData {
  cohort_date: string;
  cohort_size: number;
  retention: number[];
}

export interface RetentionData {
  period: string;
  cohorts: CohortData[];
  average_retention: number[];
}
