export type ApprovalStatus = 'pending' | 'approved' | 'rejected' | 'expired';

export type ApprovalActionType =
  | 'campaign_launch'
  | 'campaign_update'
  | 'budget_change'
  | 'audience_sync'
  | 'journey_activate'
  | 'creative_publish'
  | 'connector_connect';

export interface Approval {
  id: string;
  org_id: string;
  action_type: ApprovalActionType;
  status: ApprovalStatus;
  resource_type: string;
  resource_id: string;
  requested_by: string;
  reviewed_by?: string;
  title: string;
  description?: string;
  payload: Record<string, unknown>;
  review_note?: string;
  expires_at?: string;
  reviewed_at?: string;
  created_at: string;
  updated_at: string;
}
