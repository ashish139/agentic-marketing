export type AudienceType = 'static' | 'dynamic' | 'lookalike';
export type AudienceStatus = 'draft' | 'active' | 'archived';

export interface AudienceRule {
  field: string;
  op: 'eq' | 'neq' | 'gt' | 'gte' | 'lt' | 'lte' | 'contains' | 'not_contains' | 'in' | 'not_in' | 'within';
  value: string | number | boolean | string[];
}

export interface Audience {
  id: string;
  org_id: string;
  name: string;
  description?: string;
  rules: AudienceRule[];
  audience_type: AudienceType;
  source_audience_id?: string;
  estimated_size?: number;
  status: AudienceStatus;
  created_by?: string;
  created_at: string;
  updated_at: string;
}

export interface AudienceMember {
  id: string;
  audience_id: string;
  customer_id: string;
  added_at: string;
  source: 'manual' | 'rule' | 'import' | 'lookalike';
}

export interface AudienceSizeEstimate {
  estimated_size: number;
  total_customers: number;
  percentage: number;
}
