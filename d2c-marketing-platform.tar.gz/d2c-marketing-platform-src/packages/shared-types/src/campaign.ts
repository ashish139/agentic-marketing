export type CampaignType = 'email' | 'sms' | 'push' | 'social' | 'search' | 'display';
export type CampaignStatus = 'draft' | 'scheduled' | 'active' | 'paused' | 'completed' | 'cancelled';
export type Platform = 'meta' | 'google' | 'tiktok' | 'email' | 'sms' | 'push';
export type CreativeType = 'image' | 'video' | 'carousel' | 'text' | 'html';

export interface Campaign {
  id: string;
  org_id: string;
  name: string;
  description?: string;
  campaign_type: CampaignType;
  status: CampaignStatus;
  platform: Platform;
  audience_id?: string;
  budget?: number;
  currency: string;
  start_date?: string;
  end_date?: string;
  schedule_cron?: string;
  metadata?: Record<string, unknown>;
  created_by?: string;
  created_at: string;
  updated_at: string;
}

export interface AdCreative {
  id: string;
  campaign_id: string;
  org_id: string;
  name: string;
  creative_type: CreativeType;
  headline?: string;
  body?: string;
  cta_text?: string;
  cta_url?: string;
  media_url?: string;
  thumbnail_url?: string;
  platform_specific?: Record<string, unknown>;
  is_active: boolean;
  created_by?: string;
  created_at: string;
  updated_at: string;
}

export interface CampaignMetrics {
  campaign_id: string;
  impressions: number;
  clicks: number;
  conversions: number;
  spend: number;
  revenue: number;
  ctr: number;
  cpc: number;
  cpa: number;
  roas: number;
}

export interface CampaignMetricsRow {
  id: string;
  campaign_id: string;
  date: string;
  impressions: number;
  clicks: number;
  conversions: number;
  spend: number;
  revenue: number;
  ctr: number;
  cpc: number;
  cpa: number;
  roas: number;
  platform_data?: Record<string, unknown>;
  created_at: string;
}
