export type ConnectorPlatform =
  | 'meta_ads'
  | 'google_ads'
  | 'tiktok_ads'
  | 'shopify'
  | 'stripe'
  | 'sendgrid'
  | 'twilio'
  | 'segment'
  | 'ga4'
  | 'hubspot'
  | 'klaviyo'
  | 'mailchimp';

export type ConnectorStatus = 'connected' | 'disconnected' | 'error' | 'pending';

export interface Connector {
  id: string;
  org_id: string;
  platform: ConnectorPlatform;
  status: ConnectorStatus;
  display_name: string;
  credentials_encrypted?: string;
  config?: Record<string, unknown>;
  last_sync_at?: string;
  error_message?: string;
  connected_by?: string;
  created_at: string;
  updated_at: string;
}
