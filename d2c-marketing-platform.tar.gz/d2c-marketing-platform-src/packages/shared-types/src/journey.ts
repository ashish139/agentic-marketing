export type JourneyStatus = 'draft' | 'active' | 'paused' | 'completed' | 'archived';
export type StepType =
  | 'trigger'
  | 'email'
  | 'sms'
  | 'push'
  | 'wait'
  | 'condition'
  | 'split'
  | 'webhook'
  | 'update_attribute'
  | 'add_to_audience'
  | 'remove_from_audience';

export interface JourneyStep {
  id: string;
  journey_id: string;
  name: string;
  step_type: StepType;
  config: Record<string, unknown>;
  position_x: number;
  position_y: number;
  created_at: string;
  updated_at: string;
}

export interface JourneyEdge {
  id: string;
  journey_id: string;
  source_step_id: string;
  target_step_id: string;
  condition?: Record<string, unknown>;
  label?: string;
  created_at: string;
}

export interface Journey {
  id: string;
  org_id: string;
  name: string;
  description?: string;
  status: JourneyStatus;
  trigger_config?: Record<string, unknown>;
  steps?: JourneyStep[];
  edges?: JourneyEdge[];
  entry_count: number;
  exit_count: number;
  created_by?: string;
  created_at: string;
  updated_at: string;
}
