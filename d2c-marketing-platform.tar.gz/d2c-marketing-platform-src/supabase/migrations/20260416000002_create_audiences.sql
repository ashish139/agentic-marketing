CREATE TABLE public.audiences (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT,
    rules JSONB NOT NULL DEFAULT '[]',
    audience_type TEXT NOT NULL CHECK (audience_type IN ('static', 'dynamic', 'lookalike')),
    source_audience_id UUID REFERENCES public.audiences(id),
    estimated_size INTEGER,
    status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'archived')),
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE public.audience_members (
    audience_id UUID NOT NULL REFERENCES public.audiences(id) ON DELETE CASCADE,
    customer_id UUID NOT NULL REFERENCES public.customers(id) ON DELETE CASCADE,
    added_at TIMESTAMPTZ DEFAULT now(),
    PRIMARY KEY (audience_id, customer_id)
);

CREATE INDEX idx_audiences_org ON public.audiences(org_id);
