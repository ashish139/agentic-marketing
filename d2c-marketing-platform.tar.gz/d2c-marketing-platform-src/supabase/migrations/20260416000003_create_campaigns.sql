CREATE TABLE public.campaigns (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT,
    campaign_type TEXT NOT NULL CHECK (campaign_type IN ('search','display','social','email','retargeting')),
    platform TEXT CHECK (platform IN ('google_ads','facebook_ads','email','multi')),
    audience_id UUID REFERENCES public.audiences(id),
    status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','pending_approval','approved','active','paused','completed','archived')),
    budget_daily NUMERIC(12,2),
    budget_total NUMERIC(12,2),
    currency TEXT DEFAULT 'USD',
    start_date DATE,
    end_date DATE,
    platform_campaign_id TEXT,
    settings JSONB DEFAULT '{}',
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE public.ad_creatives (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    campaign_id UUID NOT NULL REFERENCES public.campaigns(id) ON DELETE CASCADE,
    org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    creative_type TEXT NOT NULL CHECK (creative_type IN ('image','video','text','html','email_template')),
    headline TEXT,
    body_text TEXT,
    cta_text TEXT,
    image_url TEXT,
    template_html TEXT,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE public.campaign_metrics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    campaign_id UUID NOT NULL REFERENCES public.campaigns(id) ON DELETE CASCADE,
    org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    impressions BIGINT DEFAULT 0,
    clicks BIGINT DEFAULT 0,
    conversions BIGINT DEFAULT 0,
    spend NUMERIC(12,2) DEFAULT 0,
    revenue NUMERIC(12,2) DEFAULT 0,
    ctr NUMERIC(8,4),
    cpc NUMERIC(8,4),
    cpa NUMERIC(8,4),
    roas NUMERIC(8,4),
    platform_data JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT now(),
    UNIQUE (campaign_id, date)
);

CREATE INDEX idx_campaigns_org ON public.campaigns(org_id);
CREATE INDEX idx_campaign_metrics_date ON public.campaign_metrics(campaign_id, date);
