CREATE TABLE public.journeys (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','pending_approval','active','paused','completed','archived')),
    entry_conditions JSONB NOT NULL DEFAULT '{}',
    exit_conditions JSONB DEFAULT '{}',
    goal JSONB DEFAULT '{}',
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE public.journey_steps (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    journey_id UUID NOT NULL REFERENCES public.journeys(id) ON DELETE CASCADE,
    step_type TEXT NOT NULL CHECK (step_type IN ('email','sms','push','wait','condition','split','webhook','retarget_ad')),
    title TEXT,
    position_x INTEGER DEFAULT 0,
    position_y INTEGER DEFAULT 0,
    config JSONB NOT NULL DEFAULT '{}',
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE public.journey_edges (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    journey_id UUID NOT NULL REFERENCES public.journeys(id) ON DELETE CASCADE,
    from_step_id UUID NOT NULL REFERENCES public.journey_steps(id) ON DELETE CASCADE,
    to_step_id UUID NOT NULL REFERENCES public.journey_steps(id) ON DELETE CASCADE,
    condition_label TEXT,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_journeys_org ON public.journeys(org_id);
CREATE INDEX idx_journey_steps_journey ON public.journey_steps(journey_id);
