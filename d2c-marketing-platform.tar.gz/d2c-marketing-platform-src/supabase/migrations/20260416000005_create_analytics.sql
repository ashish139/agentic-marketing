CREATE TABLE public.events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    customer_id UUID REFERENCES public.customers(id),
    event_name TEXT NOT NULL,
    properties JSONB DEFAULT '{}',
    timestamp TIMESTAMPTZ NOT NULL DEFAULT now(),
    source TEXT
);

CREATE TABLE public.dashboards (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT,
    layout JSONB NOT NULL DEFAULT '[]',
    created_by UUID REFERENCES auth.users(id),
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE public.dashboard_widgets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    dashboard_id UUID NOT NULL REFERENCES public.dashboards(id) ON DELETE CASCADE,
    widget_type TEXT NOT NULL CHECK (widget_type IN ('metric','line_chart','bar_chart','pie_chart','funnel','cohort_table','retention_heatmap','table')),
    title TEXT NOT NULL,
    query_config JSONB NOT NULL DEFAULT '{}',
    position JSONB DEFAULT '{"x":0,"y":0,"w":6,"h":4}',
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_events_org_timestamp ON public.events(org_id, timestamp DESC);
CREATE INDEX idx_events_customer ON public.events(customer_id, timestamp DESC);
CREATE INDEX idx_events_name ON public.events(org_id, event_name);
