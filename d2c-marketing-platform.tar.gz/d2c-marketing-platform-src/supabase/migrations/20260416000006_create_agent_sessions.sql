CREATE TABLE public.agent_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES auth.users(id),
    title TEXT,
    active_agent TEXT,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE public.agent_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id UUID NOT NULL REFERENCES public.agent_sessions(id) ON DELETE CASCADE,
    role TEXT NOT NULL CHECK (role IN ('user','assistant','system','tool')),
    agent_name TEXT,
    content TEXT NOT NULL,
    structured_output JSONB,
    tool_calls JSONB,
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_agent_sessions_user ON public.agent_sessions(user_id, created_at DESC);
CREATE INDEX idx_agent_messages_session ON public.agent_messages(session_id, created_at ASC);
