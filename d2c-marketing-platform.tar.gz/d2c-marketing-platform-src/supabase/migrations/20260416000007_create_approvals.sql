CREATE TABLE public.approvals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id UUID NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
    session_id UUID REFERENCES public.agent_sessions(id),
    agent_name TEXT NOT NULL,
    action_type TEXT NOT NULL CHECK (action_type IN (
        'create_audience','update_audience','activate_audience',
        'create_campaign','launch_campaign','update_budget',
        'activate_journey','update_journey',
        'publish_creative','execute_query'
    )),
    title TEXT NOT NULL,
    description TEXT,
    payload JSONB NOT NULL,
    diff JSONB,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','expired')),
    reviewed_by UUID REFERENCES auth.users(id),
    reviewed_at TIMESTAMPTZ,
    review_note TEXT,
    expires_at TIMESTAMPTZ DEFAULT (now() + interval '7 days'),
    created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_approvals_org_status ON public.approvals(org_id, status);
