-- ============================================================
-- Enable Row Level Security on ALL tables
-- ============================================================
ALTER TABLE public.organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.org_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audiences ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audience_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ad_creatives ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.campaign_metrics ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.journeys ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.journey_steps ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.journey_edges ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dashboards ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dashboard_widgets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.agent_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.agent_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.approvals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.connectors ENABLE ROW LEVEL SECURITY;

-- ============================================================
-- Helper function: returns all org_ids the current user belongs to
-- ============================================================
CREATE OR REPLACE FUNCTION public.user_org_ids()
RETURNS SETOF UUID AS $$
  SELECT org_id FROM public.org_members WHERE user_id = auth.uid()
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- Helper function: check if user has admin+ role in a given org
CREATE OR REPLACE FUNCTION public.user_is_admin(check_org_id UUID)
RETURNS BOOLEAN AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.org_members
    WHERE user_id = auth.uid()
      AND org_id = check_org_id
      AND role IN ('owner', 'admin')
  )
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- Helper function: check if user has write role (marketer+) in a given org
CREATE OR REPLACE FUNCTION public.user_can_write(check_org_id UUID)
RETURNS BOOLEAN AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.org_members
    WHERE user_id = auth.uid()
      AND org_id = check_org_id
      AND role IN ('owner', 'admin', 'marketer')
  )
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- ============================================================
-- Organizations
-- ============================================================
CREATE POLICY "org_select" ON public.organizations
    FOR SELECT USING (id IN (SELECT public.user_org_ids()));

CREATE POLICY "org_insert" ON public.organizations
    FOR INSERT WITH CHECK (TRUE);

CREATE POLICY "org_update" ON public.organizations
    FOR UPDATE USING (public.user_is_admin(id));

CREATE POLICY "org_delete" ON public.organizations
    FOR DELETE USING (
        id IN (SELECT org_id FROM public.org_members WHERE user_id = auth.uid() AND role = 'owner')
    );

-- ============================================================
-- Org Members
-- ============================================================
CREATE POLICY "org_members_select" ON public.org_members
    FOR SELECT USING (org_id IN (SELECT public.user_org_ids()));

CREATE POLICY "org_members_insert" ON public.org_members
    FOR INSERT WITH CHECK (public.user_is_admin(org_id));

CREATE POLICY "org_members_update" ON public.org_members
    FOR UPDATE USING (public.user_is_admin(org_id));

CREATE POLICY "org_members_delete" ON public.org_members
    FOR DELETE USING (public.user_is_admin(org_id));

-- ============================================================
-- Customers
-- ============================================================
CREATE POLICY "customers_select" ON public.customers
    FOR SELECT USING (org_id IN (SELECT public.user_org_ids()));

CREATE POLICY "customers_insert" ON public.customers
    FOR INSERT WITH CHECK (public.user_can_write(org_id));

CREATE POLICY "customers_update" ON public.customers
    FOR UPDATE USING (public.user_can_write(org_id));

CREATE POLICY "customers_delete" ON public.customers
    FOR DELETE USING (public.user_is_admin(org_id));

-- ============================================================
-- Audiences
-- ============================================================
CREATE POLICY "audiences_select" ON public.audiences
    FOR SELECT USING (org_id IN (SELECT public.user_org_ids()));

CREATE POLICY "audiences_insert" ON public.audiences
    FOR INSERT WITH CHECK (public.user_can_write(org_id));

CREATE POLICY "audiences_update" ON public.audiences
    FOR UPDATE USING (public.user_can_write(org_id));

CREATE POLICY "audiences_delete" ON public.audiences
    FOR DELETE USING (public.user_is_admin(org_id));

-- ============================================================
-- Audience Members
-- ============================================================
CREATE POLICY "audience_members_select" ON public.audience_members
    FOR SELECT USING (
        audience_id IN (SELECT id FROM public.audiences WHERE org_id IN (SELECT public.user_org_ids()))
    );

CREATE POLICY "audience_members_insert" ON public.audience_members
    FOR INSERT WITH CHECK (
        audience_id IN (SELECT id FROM public.audiences WHERE public.user_can_write(org_id))
    );

CREATE POLICY "audience_members_delete" ON public.audience_members
    FOR DELETE USING (
        audience_id IN (SELECT id FROM public.audiences WHERE public.user_can_write(org_id))
    );

-- ============================================================
-- Campaigns
-- ============================================================
CREATE POLICY "campaigns_select" ON public.campaigns
    FOR SELECT USING (org_id IN (SELECT public.user_org_ids()));

CREATE POLICY "campaigns_insert" ON public.campaigns
    FOR INSERT WITH CHECK (public.user_can_write(org_id));

CREATE POLICY "campaigns_update" ON public.campaigns
    FOR UPDATE USING (public.user_can_write(org_id));

CREATE POLICY "campaigns_delete" ON public.campaigns
    FOR DELETE USING (public.user_is_admin(org_id));

-- ============================================================
-- Ad Creatives
-- ============================================================
CREATE POLICY "ad_creatives_select" ON public.ad_creatives
    FOR SELECT USING (org_id IN (SELECT public.user_org_ids()));

CREATE POLICY "ad_creatives_insert" ON public.ad_creatives
    FOR INSERT WITH CHECK (public.user_can_write(org_id));

CREATE POLICY "ad_creatives_update" ON public.ad_creatives
    FOR UPDATE USING (public.user_can_write(org_id));

CREATE POLICY "ad_creatives_delete" ON public.ad_creatives
    FOR DELETE USING (public.user_is_admin(org_id));

-- ============================================================
-- Campaign Metrics
-- ============================================================
CREATE POLICY "campaign_metrics_select" ON public.campaign_metrics
    FOR SELECT USING (org_id IN (SELECT public.user_org_ids()));

CREATE POLICY "campaign_metrics_insert" ON public.campaign_metrics
    FOR INSERT WITH CHECK (public.user_can_write(org_id));

CREATE POLICY "campaign_metrics_update" ON public.campaign_metrics
    FOR UPDATE USING (public.user_is_admin(org_id));

CREATE POLICY "campaign_metrics_delete" ON public.campaign_metrics
    FOR DELETE USING (public.user_is_admin(org_id));

-- ============================================================
-- Journeys
-- ============================================================
CREATE POLICY "journeys_select" ON public.journeys
    FOR SELECT USING (org_id IN (SELECT public.user_org_ids()));

CREATE POLICY "journeys_insert" ON public.journeys
    FOR INSERT WITH CHECK (public.user_can_write(org_id));

CREATE POLICY "journeys_update" ON public.journeys
    FOR UPDATE USING (public.user_can_write(org_id));

CREATE POLICY "journeys_delete" ON public.journeys
    FOR DELETE USING (public.user_is_admin(org_id));

-- ============================================================
-- Journey Steps
-- ============================================================
CREATE POLICY "journey_steps_select" ON public.journey_steps
    FOR SELECT USING (
        journey_id IN (SELECT id FROM public.journeys WHERE org_id IN (SELECT public.user_org_ids()))
    );

CREATE POLICY "journey_steps_insert" ON public.journey_steps
    FOR INSERT WITH CHECK (
        journey_id IN (SELECT id FROM public.journeys WHERE public.user_can_write(org_id))
    );

CREATE POLICY "journey_steps_update" ON public.journey_steps
    FOR UPDATE USING (
        journey_id IN (SELECT id FROM public.journeys WHERE public.user_can_write(org_id))
    );

CREATE POLICY "journey_steps_delete" ON public.journey_steps
    FOR DELETE USING (
        journey_id IN (SELECT id FROM public.journeys WHERE public.user_is_admin(org_id))
    );

-- ============================================================
-- Journey Edges
-- ============================================================
CREATE POLICY "journey_edges_select" ON public.journey_edges
    FOR SELECT USING (
        journey_id IN (SELECT id FROM public.journeys WHERE org_id IN (SELECT public.user_org_ids()))
    );

CREATE POLICY "journey_edges_insert" ON public.journey_edges
    FOR INSERT WITH CHECK (
        journey_id IN (SELECT id FROM public.journeys WHERE public.user_can_write(org_id))
    );

CREATE POLICY "journey_edges_delete" ON public.journey_edges
    FOR DELETE USING (
        journey_id IN (SELECT id FROM public.journeys WHERE public.user_can_write(org_id))
    );

-- ============================================================
-- Events
-- ============================================================
CREATE POLICY "events_select" ON public.events
    FOR SELECT USING (org_id IN (SELECT public.user_org_ids()));

CREATE POLICY "events_insert" ON public.events
    FOR INSERT WITH CHECK (public.user_can_write(org_id));

CREATE POLICY "events_delete" ON public.events
    FOR DELETE USING (public.user_is_admin(org_id));

-- ============================================================
-- Dashboards
-- ============================================================
CREATE POLICY "dashboards_select" ON public.dashboards
    FOR SELECT USING (org_id IN (SELECT public.user_org_ids()));

CREATE POLICY "dashboards_insert" ON public.dashboards
    FOR INSERT WITH CHECK (public.user_can_write(org_id));

CREATE POLICY "dashboards_update" ON public.dashboards
    FOR UPDATE USING (public.user_can_write(org_id));

CREATE POLICY "dashboards_delete" ON public.dashboards
    FOR DELETE USING (public.user_is_admin(org_id));

-- ============================================================
-- Dashboard Widgets
-- ============================================================
CREATE POLICY "dashboard_widgets_select" ON public.dashboard_widgets
    FOR SELECT USING (
        dashboard_id IN (SELECT id FROM public.dashboards WHERE org_id IN (SELECT public.user_org_ids()))
    );

CREATE POLICY "dashboard_widgets_insert" ON public.dashboard_widgets
    FOR INSERT WITH CHECK (
        dashboard_id IN (SELECT id FROM public.dashboards WHERE public.user_can_write(org_id))
    );

CREATE POLICY "dashboard_widgets_update" ON public.dashboard_widgets
    FOR UPDATE USING (
        dashboard_id IN (SELECT id FROM public.dashboards WHERE public.user_can_write(org_id))
    );

CREATE POLICY "dashboard_widgets_delete" ON public.dashboard_widgets
    FOR DELETE USING (
        dashboard_id IN (SELECT id FROM public.dashboards WHERE public.user_is_admin(org_id))
    );

-- ============================================================
-- Agent Sessions
-- ============================================================
CREATE POLICY "agent_sessions_select" ON public.agent_sessions
    FOR SELECT USING (org_id IN (SELECT public.user_org_ids()));

CREATE POLICY "agent_sessions_insert" ON public.agent_sessions
    FOR INSERT WITH CHECK (
        org_id IN (SELECT public.user_org_ids()) AND user_id = auth.uid()
    );

CREATE POLICY "agent_sessions_update" ON public.agent_sessions
    FOR UPDATE USING (user_id = auth.uid());

CREATE POLICY "agent_sessions_delete" ON public.agent_sessions
    FOR DELETE USING (user_id = auth.uid());

-- ============================================================
-- Agent Messages
-- ============================================================
CREATE POLICY "agent_messages_select" ON public.agent_messages
    FOR SELECT USING (
        session_id IN (SELECT id FROM public.agent_sessions WHERE org_id IN (SELECT public.user_org_ids()))
    );

CREATE POLICY "agent_messages_insert" ON public.agent_messages
    FOR INSERT WITH CHECK (
        session_id IN (SELECT id FROM public.agent_sessions WHERE user_id = auth.uid())
    );

-- ============================================================
-- Approvals
-- ============================================================
CREATE POLICY "approvals_select" ON public.approvals
    FOR SELECT USING (org_id IN (SELECT public.user_org_ids()));

CREATE POLICY "approvals_insert" ON public.approvals
    FOR INSERT WITH CHECK (public.user_can_write(org_id));

CREATE POLICY "approvals_update" ON public.approvals
    FOR UPDATE USING (public.user_is_admin(org_id));

-- ============================================================
-- Connectors
-- ============================================================
CREATE POLICY "connectors_select" ON public.connectors
    FOR SELECT USING (org_id IN (SELECT public.user_org_ids()));

CREATE POLICY "connectors_insert" ON public.connectors
    FOR INSERT WITH CHECK (public.user_is_admin(org_id));

CREATE POLICY "connectors_update" ON public.connectors
    FOR UPDATE USING (public.user_is_admin(org_id));

CREATE POLICY "connectors_delete" ON public.connectors
    FOR DELETE USING (public.user_is_admin(org_id));
