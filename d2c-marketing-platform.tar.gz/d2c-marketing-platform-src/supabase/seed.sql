-- ============================================================
-- Seed data for D2C Marketing AI Agent Platform
-- Demo brand: Acme D2C Brand (lifestyle clothing)
-- ============================================================

-- Organization
INSERT INTO public.organizations (id, name, slug, brand_guidelines, customer_schema) VALUES (
    '11111111-1111-1111-1111-111111111111',
    'Acme D2C Brand',
    'acme-d2c',
    '{
        "colors": {
            "primary": "#1A1A2E",
            "secondary": "#E94560",
            "accent": "#0F3460",
            "background": "#F5F5F5",
            "text": "#16213E"
        },
        "fonts": {
            "heading": "Playfair Display",
            "body": "Inter",
            "accent": "DM Sans"
        },
        "tone": "Warm, confident, and aspirational. We speak to our customers as a trusted friend who understands modern style. Avoid corporate jargon. Use active voice and short sentences.",
        "logo_url": "https://cdn.acme-d2c.com/logo.svg",
        "tagline": "Everyday essentials, elevated."
    }',
    '{
        "ltv": {"type": "number", "label": "Lifetime Value"},
        "segment": {"type": "enum", "label": "Segment", "values": ["vip", "loyal", "active", "at_risk", "new", "dormant"]},
        "last_purchase": {"type": "date", "label": "Last Purchase Date"},
        "signup_date": {"type": "date", "label": "Signup Date"},
        "total_orders": {"type": "number", "label": "Total Orders"},
        "preferred_channel": {"type": "enum", "label": "Preferred Channel", "values": ["email", "sms", "push", "social"]}
    }'
);

-- 20 Sample Customers
INSERT INTO public.customers (id, org_id, external_id, email, phone, first_name, last_name, properties, first_seen_at, last_seen_at) VALUES
-- VIP / High-LTV customers
('c0000001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', 'CUST-001', 'olivia.chen@email.com', '+14155550101', 'Olivia', 'Chen',
 '{"ltv": 4250.00, "segment": "vip", "last_purchase": "2026-04-10", "signup_date": "2024-03-15", "total_orders": 38, "preferred_channel": "email"}',
 '2024-03-15', '2026-04-10'),
('c0000001-0000-0000-0000-000000000002', '11111111-1111-1111-1111-111111111111', 'CUST-002', 'marcus.johnson@email.com', '+14155550102', 'Marcus', 'Johnson',
 '{"ltv": 3800.00, "segment": "vip", "last_purchase": "2026-04-08", "signup_date": "2024-01-20", "total_orders": 31, "preferred_channel": "sms"}',
 '2024-01-20', '2026-04-08'),
('c0000001-0000-0000-0000-000000000003', '11111111-1111-1111-1111-111111111111', 'CUST-003', 'sophia.martinez@email.com', '+14155550103', 'Sophia', 'Martinez',
 '{"ltv": 3200.00, "segment": "vip", "last_purchase": "2026-04-12", "signup_date": "2024-06-01", "total_orders": 27, "preferred_channel": "email"}',
 '2024-06-01', '2026-04-12'),

-- Loyal customers
('c0000001-0000-0000-0000-000000000004', '11111111-1111-1111-1111-111111111111', 'CUST-004', 'ethan.williams@email.com', '+14155550104', 'Ethan', 'Williams',
 '{"ltv": 1850.00, "segment": "loyal", "last_purchase": "2026-03-28", "signup_date": "2024-09-10", "total_orders": 15, "preferred_channel": "email"}',
 '2024-09-10', '2026-03-28'),
('c0000001-0000-0000-0000-000000000005', '11111111-1111-1111-1111-111111111111', 'CUST-005', 'ava.thompson@email.com', '+14155550105', 'Ava', 'Thompson',
 '{"ltv": 1620.00, "segment": "loyal", "last_purchase": "2026-04-01", "signup_date": "2024-11-05", "total_orders": 13, "preferred_channel": "push"}',
 '2024-11-05', '2026-04-01'),
('c0000001-0000-0000-0000-000000000006', '11111111-1111-1111-1111-111111111111', 'CUST-006', 'liam.davis@email.com', '+14155550106', 'Liam', 'Davis',
 '{"ltv": 1480.00, "segment": "loyal", "last_purchase": "2026-03-20", "signup_date": "2025-01-15", "total_orders": 11, "preferred_channel": "email"}',
 '2025-01-15', '2026-03-20'),
('c0000001-0000-0000-0000-000000000007', '11111111-1111-1111-1111-111111111111', 'CUST-007', 'isabella.garcia@email.com', '+14155550107', 'Isabella', 'Garcia',
 '{"ltv": 1350.00, "segment": "loyal", "last_purchase": "2026-04-05", "signup_date": "2025-02-20", "total_orders": 10, "preferred_channel": "sms"}',
 '2025-02-20', '2026-04-05'),

-- Active customers
('c0000001-0000-0000-0000-000000000008', '11111111-1111-1111-1111-111111111111', 'CUST-008', 'noah.brown@email.com', '+14155550108', 'Noah', 'Brown',
 '{"ltv": 720.00, "segment": "active", "last_purchase": "2026-03-15", "signup_date": "2025-06-10", "total_orders": 6, "preferred_channel": "email"}',
 '2025-06-10', '2026-03-15'),
('c0000001-0000-0000-0000-000000000009', '11111111-1111-1111-1111-111111111111', 'CUST-009', 'emma.wilson@email.com', '+14155550109', 'Emma', 'Wilson',
 '{"ltv": 650.00, "segment": "active", "last_purchase": "2026-03-22", "signup_date": "2025-07-01", "total_orders": 5, "preferred_channel": "social"}',
 '2025-07-01', '2026-03-22'),
('c0000001-0000-0000-0000-000000000010', '11111111-1111-1111-1111-111111111111', 'CUST-010', 'james.taylor@email.com', '+14155550110', 'James', 'Taylor',
 '{"ltv": 580.00, "segment": "active", "last_purchase": "2026-04-02", "signup_date": "2025-08-15", "total_orders": 5, "preferred_channel": "email"}',
 '2025-08-15', '2026-04-02'),
('c0000001-0000-0000-0000-000000000011', '11111111-1111-1111-1111-111111111111', 'CUST-011', 'mia.anderson@email.com', '+14155550111', 'Mia', 'Anderson',
 '{"ltv": 430.00, "segment": "active", "last_purchase": "2026-02-28", "signup_date": "2025-09-20", "total_orders": 4, "preferred_channel": "push"}',
 '2025-09-20', '2026-02-28'),

-- At-risk customers
('c0000001-0000-0000-0000-000000000012', '11111111-1111-1111-1111-111111111111', 'CUST-012', 'william.lee@email.com', '+14155550112', 'William', 'Lee',
 '{"ltv": 920.00, "segment": "at_risk", "last_purchase": "2025-12-10", "signup_date": "2024-08-01", "total_orders": 8, "preferred_channel": "email"}',
 '2024-08-01', '2025-12-10'),
('c0000001-0000-0000-0000-000000000013', '11111111-1111-1111-1111-111111111111', 'CUST-013', 'charlotte.harris@email.com', '+14155550113', 'Charlotte', 'Harris',
 '{"ltv": 780.00, "segment": "at_risk", "last_purchase": "2025-11-25", "signup_date": "2024-10-12", "total_orders": 7, "preferred_channel": "sms"}',
 '2024-10-12', '2025-11-25'),
('c0000001-0000-0000-0000-000000000014', '11111111-1111-1111-1111-111111111111', 'CUST-014', 'benjamin.clark@email.com', '+14155550114', 'Benjamin', 'Clark',
 '{"ltv": 540.00, "segment": "at_risk", "last_purchase": "2026-01-05", "signup_date": "2025-03-18", "total_orders": 5, "preferred_channel": "email"}',
 '2025-03-18', '2026-01-05'),

-- New customers
('c0000001-0000-0000-0000-000000000015', '11111111-1111-1111-1111-111111111111', 'CUST-015', 'amelia.wright@email.com', '+14155550115', 'Amelia', 'Wright',
 '{"ltv": 120.00, "segment": "new", "last_purchase": "2026-04-14", "signup_date": "2026-04-10", "total_orders": 1, "preferred_channel": "social"}',
 '2026-04-10', '2026-04-14'),
('c0000001-0000-0000-0000-000000000016', '11111111-1111-1111-1111-111111111111', 'CUST-016', 'henry.king@email.com', '+14155550116', 'Henry', 'King',
 '{"ltv": 95.00, "segment": "new", "last_purchase": "2026-04-12", "signup_date": "2026-04-08", "total_orders": 1, "preferred_channel": "email"}',
 '2026-04-08', '2026-04-12'),
('c0000001-0000-0000-0000-000000000017', '11111111-1111-1111-1111-111111111111', 'CUST-017', 'harper.scott@email.com', '+14155550117', 'Harper', 'Scott',
 '{"ltv": 180.00, "segment": "new", "last_purchase": "2026-04-15", "signup_date": "2026-04-01", "total_orders": 2, "preferred_channel": "email"}',
 '2026-04-01', '2026-04-15'),

-- Dormant customers
('c0000001-0000-0000-0000-000000000018', '11111111-1111-1111-1111-111111111111', 'CUST-018', 'daniel.green@email.com', '+14155550118', 'Daniel', 'Green',
 '{"ltv": 350.00, "segment": "dormant", "last_purchase": "2025-06-15", "signup_date": "2024-12-01", "total_orders": 3, "preferred_channel": "email"}',
 '2024-12-01', '2025-06-15'),
('c0000001-0000-0000-0000-000000000019', '11111111-1111-1111-1111-111111111111', 'CUST-019', 'evelyn.adams@email.com', '+14155550119', 'Evelyn', 'Adams',
 '{"ltv": 210.00, "segment": "dormant", "last_purchase": "2025-05-20", "signup_date": "2025-01-10", "total_orders": 2, "preferred_channel": "sms"}',
 '2025-01-10', '2025-05-20'),
('c0000001-0000-0000-0000-000000000020', '11111111-1111-1111-1111-111111111111', 'CUST-020', 'alexander.baker@email.com', '+14155550120', 'Alexander', 'Baker',
 '{"ltv": 150.00, "segment": "dormant", "last_purchase": "2025-04-08", "signup_date": "2025-02-14", "total_orders": 2, "preferred_channel": "push"}',
 '2025-02-14', '2025-04-08');

-- Connectors (mock mode)
INSERT INTO public.connectors (id, org_id, platform, name, status, config, use_mock, last_synced_at) VALUES
('cc000001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', 'google_ads', 'Acme Google Ads', 'connected',
 '{"account_id": "123-456-7890", "conversion_tracking": true}', TRUE, '2026-04-15 10:00:00+00'),
('cc000001-0000-0000-0000-000000000002', '11111111-1111-1111-1111-111111111111', 'facebook_ads', 'Acme Facebook Ads', 'connected',
 '{"ad_account_id": "act_987654321", "pixel_id": "px_112233"}', TRUE, '2026-04-15 10:05:00+00');

-- Audience: High Value Customers
INSERT INTO public.audiences (id, org_id, name, description, rules, audience_type, estimated_size, status) VALUES
('aa000001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111',
 'High Value Customers',
 'Customers with LTV above $1000 and at least 8 orders. Prime targets for loyalty programs and exclusive offers.',
 '[
    {"field": "properties.ltv", "operator": "gte", "value": 1000},
    {"field": "properties.total_orders", "operator": "gte", "value": 8}
 ]',
 'dynamic', 7, 'active');

-- Add qualifying customers to the audience
INSERT INTO public.audience_members (audience_id, customer_id) VALUES
('aa000001-0000-0000-0000-000000000001', 'c0000001-0000-0000-0000-000000000001'),
('aa000001-0000-0000-0000-000000000001', 'c0000001-0000-0000-0000-000000000002'),
('aa000001-0000-0000-0000-000000000001', 'c0000001-0000-0000-0000-000000000003'),
('aa000001-0000-0000-0000-000000000001', 'c0000001-0000-0000-0000-000000000004'),
('aa000001-0000-0000-0000-000000000001', 'c0000001-0000-0000-0000-000000000005'),
('aa000001-0000-0000-0000-000000000001', 'c0000001-0000-0000-0000-000000000006'),
('aa000001-0000-0000-0000-000000000001', 'c0000001-0000-0000-0000-000000000007');

-- Campaign: Spring Collection Launch
INSERT INTO public.campaigns (id, org_id, name, description, campaign_type, platform, audience_id, status, budget_daily, budget_total, currency, start_date, end_date, platform_campaign_id, settings) VALUES
('ca000001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111',
 'Spring Collection 2026 - Retargeting',
 'Retargeting campaign for high-value customers promoting the new Spring 2026 lifestyle collection. Focus on premium basics and elevated essentials.',
 'retargeting', 'google_ads',
 'aa000001-0000-0000-0000-000000000001',
 'active', 150.00, 4500.00, 'USD',
 '2026-04-01', '2026-04-30',
 'mock_gc_12345',
 '{"bid_strategy": "target_roas", "target_roas": 4.0, "ad_rotation": "optimize", "networks": ["search", "display"]}');

-- Ad Creative
INSERT INTO public.ad_creatives (id, campaign_id, org_id, name, creative_type, headline, body_text, cta_text, image_url, metadata) VALUES
('cr000001-0000-0000-0000-000000000001', 'ca000001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111',
 'Spring Essentials Hero',
 'image',
 'Your Spring Wardrobe, Elevated',
 'Discover our curated Spring 2026 collection. Premium fabrics, timeless cuts, and colors that define the season. Free shipping on orders over $75.',
 'Shop the Collection',
 'https://cdn.acme-d2c.com/creatives/spring-2026-hero.jpg',
 '{"dimensions": "1200x628", "format": "jpg", "variant": "A"}');

-- Campaign Metrics (15 days of data)
INSERT INTO public.campaign_metrics (campaign_id, org_id, date, impressions, clicks, conversions, spend, revenue, ctr, cpc, cpa, roas) VALUES
('ca000001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '2026-04-01', 12500, 375, 8, 148.50, 640.00, 3.0000, 0.3960, 18.5625, 4.3097),
('ca000001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '2026-04-02', 13200, 410, 11, 150.00, 935.00, 3.1061, 0.3659, 13.6364, 6.2333),
('ca000001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '2026-04-03', 11800, 342, 7, 145.20, 490.00, 2.8983, 0.4246, 20.7429, 3.3747),
('ca000001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '2026-04-04', 14100, 450, 12, 150.00, 1080.00, 3.1915, 0.3333, 12.5000, 7.2000),
('ca000001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '2026-04-05', 15300, 490, 14, 150.00, 1190.00, 3.2026, 0.3061, 10.7143, 7.9333),
('ca000001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '2026-04-06', 10200, 285, 6, 140.80, 420.00, 2.7941, 0.4942, 23.4667, 2.9830),
('ca000001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '2026-04-07', 9800, 270, 5, 138.00, 375.00, 2.7551, 0.5111, 27.6000, 2.7174),
('ca000001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '2026-04-08', 13800, 425, 10, 149.00, 850.00, 3.0797, 0.3506, 14.9000, 5.7047),
('ca000001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '2026-04-09', 14500, 465, 13, 150.00, 1105.00, 3.2069, 0.3226, 11.5385, 7.3667),
('ca000001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '2026-04-10', 15800, 520, 15, 150.00, 1275.00, 3.2911, 0.2885, 10.0000, 8.5000),
('ca000001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '2026-04-11', 14200, 440, 11, 149.50, 880.00, 3.0986, 0.3398, 13.5909, 5.8863),
('ca000001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '2026-04-12', 16100, 545, 16, 150.00, 1360.00, 3.3851, 0.2752, 9.3750, 9.0667),
('ca000001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '2026-04-13', 11500, 330, 7, 142.00, 525.00, 2.8696, 0.4303, 20.2857, 3.6972),
('ca000001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '2026-04-14', 15000, 480, 13, 150.00, 1040.00, 3.2000, 0.3125, 11.5385, 6.9333),
('ca000001-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', '2026-04-15', 16500, 560, 17, 150.00, 1445.00, 3.3939, 0.2679, 8.8235, 9.6333);

-- Sample Events
INSERT INTO public.events (org_id, customer_id, event_name, properties, timestamp, source) VALUES
('11111111-1111-1111-1111-111111111111', 'c0000001-0000-0000-0000-000000000001', 'page_view', '{"page": "/collections/spring-2026", "referrer": "google_ads"}', '2026-04-10 14:22:00+00', 'web'),
('11111111-1111-1111-1111-111111111111', 'c0000001-0000-0000-0000-000000000001', 'add_to_cart', '{"product_id": "SKU-1042", "product_name": "Linen Blend Blazer", "price": 189.00, "quantity": 1}', '2026-04-10 14:25:00+00', 'web'),
('11111111-1111-1111-1111-111111111111', 'c0000001-0000-0000-0000-000000000001', 'purchase', '{"order_id": "ORD-8834", "total": 189.00, "items": 1, "payment_method": "credit_card"}', '2026-04-10 14:30:00+00', 'web'),
('11111111-1111-1111-1111-111111111111', 'c0000001-0000-0000-0000-000000000002', 'email_open', '{"campaign": "spring_preview", "subject": "First look: Spring 2026"}', '2026-04-08 09:15:00+00', 'email'),
('11111111-1111-1111-1111-111111111111', 'c0000001-0000-0000-0000-000000000002', 'email_click', '{"campaign": "spring_preview", "link": "/collections/spring-2026"}', '2026-04-08 09:17:00+00', 'email'),
('11111111-1111-1111-1111-111111111111', 'c0000001-0000-0000-0000-000000000002', 'purchase', '{"order_id": "ORD-8790", "total": 245.00, "items": 2, "payment_method": "credit_card"}', '2026-04-08 09:35:00+00', 'web'),
('11111111-1111-1111-1111-111111111111', 'c0000001-0000-0000-0000-000000000015', 'page_view', '{"page": "/", "referrer": "instagram.com"}', '2026-04-10 18:00:00+00', 'web'),
('11111111-1111-1111-1111-111111111111', 'c0000001-0000-0000-0000-000000000015', 'signup', '{"source": "social_ad", "platform": "instagram"}', '2026-04-10 18:05:00+00', 'web'),
('11111111-1111-1111-1111-111111111111', 'c0000001-0000-0000-0000-000000000015', 'purchase', '{"order_id": "ORD-8901", "total": 120.00, "items": 1, "payment_method": "apple_pay"}', '2026-04-14 11:20:00+00', 'web'),
('11111111-1111-1111-1111-111111111111', 'c0000001-0000-0000-0000-000000000012', 'email_open', '{"campaign": "win_back_q1", "subject": "We miss you — here is 20% off"}', '2026-04-05 10:30:00+00', 'email'),
('11111111-1111-1111-1111-111111111111', 'c0000001-0000-0000-0000-000000000008', 'page_view', '{"page": "/products/organic-cotton-tee", "referrer": "google_organic"}', '2026-04-12 16:45:00+00', 'web'),
('11111111-1111-1111-1111-111111111111', 'c0000001-0000-0000-0000-000000000008', 'add_to_cart', '{"product_id": "SKU-2010", "product_name": "Organic Cotton Tee - Navy", "price": 45.00, "quantity": 2}', '2026-04-12 16:48:00+00', 'web'),
('11111111-1111-1111-1111-111111111111', 'c0000001-0000-0000-0000-000000000003', 'purchase', '{"order_id": "ORD-8920", "total": 312.00, "items": 3, "payment_method": "credit_card"}', '2026-04-12 20:15:00+00', 'web'),
('11111111-1111-1111-1111-111111111111', 'c0000001-0000-0000-0000-000000000005', 'page_view', '{"page": "/collections/new-arrivals", "referrer": "push_notification"}', '2026-04-01 12:00:00+00', 'web'),
('11111111-1111-1111-1111-111111111111', 'c0000001-0000-0000-0000-000000000005', 'purchase', '{"order_id": "ORD-8750", "total": 165.00, "items": 2, "payment_method": "credit_card"}', '2026-04-01 12:20:00+00', 'web');
